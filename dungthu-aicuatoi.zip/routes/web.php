<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\NewsletterController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\Admin\AdminController;
// use App\Http\Controllers\Admin\TiktokDealController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CardExchangeController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\ChatbotController;
use App\Http\Controllers\GuestChatController;
use App\Http\Controllers\CommunityPostController;
use App\Http\Controllers\CommunityCommentController;
use App\Http\Controllers\BuffServiceController;
use App\Http\Controllers\BuffOrderController;
use App\Http\Controllers\Admin\AdminBuffController;
use App\Http\Controllers\Admin\GoogleIndexingController;
use App\Http\Controllers\Admin\AdminAffiliateController;
use App\Http\Controllers\Admin\CustomerDurationController;
use App\Http\Controllers\Affiliate\AffiliateAuthController;
use App\Http\Controllers\Affiliate\AffiliateDashboardController;
use App\Http\Controllers\WebhookController;

Route::get('/change-language/{locale}', function ($locale) {
    if (in_array($locale, ['vi', 'en'])) {
        session(['locale' => $locale]);
    }
    return redirect()->back();
})->name('change-language');

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::view('/thiet-ke-website', 'pages.web-design')->name('web-design');
Route::view('/chinh-sach', 'pages.privacy')->name('policy');

// App Download Route (Android APK, iOS, Desktop EXE)
Route::get('/download/app/{platform}', function ($platform) {
    $platform = strtolower($platform);
    $files = [
        'android' => ['path' => public_path('downloads/dungthu-app.apk'), 'mime' => 'application/vnd.android.package-archive', 'name' => 'DungThu-AI.apk'],
        'desktop' => ['path' => public_path('downloads/dungthu-desktop-setup.exe'), 'mime' => 'application/x-msdownload', 'name' => 'DungThu-AI-Desktop-Setup.exe'],
        'ios'     => ['path' => public_path('downloads/dungthu-app.mobileconfig'), 'mime' => 'application/x-apple-aspen-config', 'name' => 'DungThu-AI.mobileconfig'],
    ];

    if (isset($files[$platform]) && file_exists($files[$platform]['path'])) {
        return response()->download(
            $files[$platform]['path'],
            $files[$platform]['name'],
            ['Content-Type' => $files[$platform]['mime']]
        );
    }

    if ($platform === 'ios') {
        return redirect('/')->with('info', __('Để thêm App vào iPhone, hãy mở Safari và chọn "Thêm vào màn hình chính" (Add to Home Screen).'));
    }

    return redirect('/')->with('info', __('File cài đặt ứng dụng cho :platform đang được chuẩn bị. Vui lòng thử lại sau!', ['platform' => strtoupper($platform)]));
})->whereIn('platform', ['android', 'ios', 'desktop'])->name('app.download');

// Guest AI chat (home only UI)
Route::post('/guest-chat', [GuestChatController::class, 'send'])->middleware('throttle:15,1')->name('guest-chat.send');

// Chatbot AI routes
Route::get('/chatbot', [ChatbotController::class, 'index'])->name('chatbot.index');
Route::post('/api/chatbot/send', [ChatbotController::class, 'sendMessage'])->middleware('throttle:15,1')->name('chatbot.send');
Route::post('/api/chatbot/session', [ChatbotController::class, 'createSession'])->name('chatbot.session.create');
Route::get('/api/chatbot/history', [ChatbotController::class, 'history'])->name('chatbot.history');
Route::post('/api/chatbot/feedback', [ChatbotController::class, 'feedback'])->name('chatbot.feedback');
Route::get('/api/chatbot/products', [ChatbotController::class, 'getProducts'])->name('chatbot.products');
Route::get('/api/chatbot/services', [ChatbotController::class, 'getBuffServices'])->name('chatbot.services');

// Random Products for Flash Sale Fallback
Route::get('/api/products/random', [HomeController::class, 'getRandomProducts'])->name('products.random');

// Online Users API
Route::get('/api/online-users/count', [\App\Http\Controllers\OnlineUserController::class, 'count'])->name('online-users.count');
Route::post('/api/online-users/ping', [\App\Http\Controllers\OnlineUserController::class, 'ping'])->name('online-users.ping');

// Telegram Webhook API
Route::post('/api/telegram/webhook', [\App\Http\Controllers\TelegramWebhookController::class, 'handle'])->name('telegram.webhook');

// Sitemap
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');

// Product routes
Route::get('/shop', [ProductController::class, 'index'])->name('shop');
Route::get('/tim-kiem/{keyword}', [ProductController::class, 'keyword'])->name('product.keyword');
Route::get('/product/{slug}', [ProductController::class, 'show'])->name('product.show');
Route::post('/product/{product}/comment', [ProductController::class, 'storeComment'])->name('product.comment')->middleware('auth');
Route::get('/product/{id}/download', [ProductController::class, 'download'])->name('product.download')->middleware('auth');

// Buff Service routes
Route::get('/dich-vu-buff', [BuffServiceController::class, 'index'])->name('buff.index');
Route::get('/dich-vu-buff/{buffService}', [BuffServiceController::class, 'show'])->name('buff.show');
Route::get('/api/buff/calculate-price', [BuffServiceController::class, 'calculatePrice'])->name('buff.calculate-price');

Route::middleware('auth')->group(function () {
    Route::get('/buff/create/{buffService}', [BuffOrderController::class, 'create'])->name('buff.create');
    Route::post('/buff/store', [BuffOrderController::class, 'store'])->name('buff.store');
    Route::get('/buff/payment/{buffOrder}', [BuffOrderController::class, 'payment'])->name('buff.payment');
    Route::post('/buff/{buffOrder}/confirm-payment', [BuffOrderController::class, 'confirmPayment'])->name('buff.confirm-payment');
    Route::get('/buff/history', [BuffOrderController::class, 'history'])->name('buff.history');
    Route::get('/buff/{buffOrder}', [BuffOrderController::class, 'detail'])->name('buff.detail');
});

// Buff routes (Legacy/Unused)
// Route::get('/buff', [BuffController::class, 'index'])->name('buff.index');
// Route::get('/buff/server/{id}', [BuffController::class, 'getServer'])->name('buff.server');
// Route::middleware('auth')->post('/buff/order', [BuffController::class, 'placeOrder'])->name('buff.order');

// VPN routes
Route::get('/vpn', [\App\Http\Controllers\VpnProxyController::class, 'index'])->name('vpn.index');
Route::get('/vpn-proxy', function() {
    return redirect()->route('vpn.index');
});
Route::get('/timkiem/{tab}', function() {
    return redirect()->route('vpn.index');
});

// Blog routes
Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/category/{category}', [BlogController::class, 'category'])->name('blog.category');
Route::get('/blog/chu-de/{topic}', [BlogController::class, 'topic'])->name('blog.topic');
Route::get('/blog/{slug}', [BlogController::class, 'show'])->name('blog.show');

// Community routes
Route::get('/community', [CommunityPostController::class, 'index'])->name('community.index');
Route::post('/community/{post:slug}/comments', [CommunityCommentController::class, 'store'])->name('community.comments.store');
Route::middleware('auth')->group(function () {
    Route::get('/community/create', [CommunityPostController::class, 'create'])->name('community.create');
    Route::post('/community', [CommunityPostController::class, 'store'])->name('community.store');
    Route::get('/community/{post:slug}/edit', [CommunityPostController::class, 'edit'])->name('community.edit');
    Route::put('/community/{post:slug}', [CommunityPostController::class, 'update'])->name('community.update');
    Route::delete('/community/{post:slug}', [CommunityPostController::class, 'destroy'])->name('community.delete');
    Route::post('/community/upload-image', [CommunityPostController::class, 'uploadImage'])->name('community.images.upload');

    Route::put('/community/comments/{comment}', [CommunityCommentController::class, 'update'])->name('community.comments.update');
    Route::delete('/community/comments/{comment}', [CommunityCommentController::class, 'destroy'])->name('community.comments.delete');
});
Route::get('/community/{post:slug}', [CommunityPostController::class, 'show'])->name('community.show');

// Auth routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login.post');
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:5,1')->name('register.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Password Reset Routes
Route::get('/forgot-password', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLink'])->name('password.email');
Route::get('/reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');

// Google OAuth routes
Route::get('/auth/google/redirect', [GoogleController::class, 'redirect']);
Route::get('/auth/google/callback', [GoogleController::class, 'callback']);

// Debug route
Route::get('/test-callback', function () {
    \Illuminate\Support\Facades\Log::info('Test callback route accessed');
    return response()->json(['message' => 'callback route works']);
});

// Cart routes
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add/{id}', [CartController::class, 'add'])->name('cart.add');
Route::post('/cart/buy-now/{id}', [CartController::class, 'buyNow'])->name('cart.buy-now');
Route::post('/cart/increment/{id}', [CartController::class, 'increment'])->name('cart.increment');
Route::post('/cart/decrement/{id}', [CartController::class, 'decrement'])->name('cart.decrement');
Route::get('/cart/remove/{id}', [CartController::class, 'remove'])->name('cart.remove');
// Checkout routes (requires auth)
Route::middleware('auth')->group(function () {
    Route::get('/checkout', [CartController::class, 'checkout'])->name('checkout');
    Route::post('/checkout/place', [CartController::class, 'placeOrder'])->name('checkout.place');
    
    // Mini Game routes
    Route::get('/minigame', [\App\Http\Controllers\MiniGameController::class, 'index'])->name('minigame.index');
    Route::post('/minigame/spin', [\App\Http\Controllers\MiniGameController::class, 'spin'])->name('minigame.spin');
    
    // Coupon routes
    Route::post('/api/coupons/apply', [CartController::class, 'applyCoupon'])->name('coupons.apply');
    Route::post('/api/coupons/remove', [CartController::class, 'removeCoupon'])->name('coupons.remove');
});

// User Account routes (requires auth)
Route::middleware('auth')->group(function () {
    Route::get('/account', [UserController::class, 'account'])->name('user.account');
    Route::put('/account', [UserController::class, 'updateAccount'])->name('user.account.update');
    Route::put('/account/password', [UserController::class, 'updatePassword'])->name('user.password.update');
    Route::get('/orders', [UserController::class, 'orders'])->name('user.orders');
    Route::get('/orders/{order}', [UserController::class, 'orderDetail'])->name('user.orders.detail');
});

// Chat routes (requires auth)
Route::middleware('auth')->prefix('chat')->group(function () {
    Route::get('/', [ChatController::class, 'showChat'])->name('chat.index');
    Route::get('/messages', [ChatController::class, 'index'])->name('chat.messages');
    Route::post('/send', [ChatController::class, 'store'])->middleware('throttle:60,1')->name('chat.send');
    Route::get('/new', [ChatController::class, 'getNewMessages'])->name('chat.new');
    Route::get('/unread-count', [ChatController::class, 'unreadCount'])->name('chat.unread-count');
    Route::post('/mark-read', [ChatController::class, 'markRead'])->name('chat.mark-read');
});

// Admin Chat routes
Route::middleware(['auth', 'admin', 'admin.pin'])->prefix('admin/chat')->group(function () {
    Route::get('/', [ChatController::class, 'adminIndex'])->name('admin.chat.index');
    Route::get('/unread-count', [ChatController::class, 'adminUnreadCount'])->name('admin.chat.unread-count');
    Route::get('/messages/{userId}', [ChatController::class, 'adminMessages'])->name('admin.chat.messages');
    Route::post('/reply/{userId}', [ChatController::class, 'adminReply'])->name('admin.chat.reply');
});

// Card Exchange routes
Route::middleware('auth')->group(function () {
    Route::get('/card-exchange', [CardExchangeController::class, 'index'])->name('card-exchange.index');
    Route::post('/card-exchange', [CardExchangeController::class, 'store'])->name('card-exchange.store');
});

// Admin routes (requires auth and admin role)
Route::middleware(['auth', 'admin', 'admin.pin', 'admin.lock'])->prefix('admin')->group(function () {
    Route::get('/', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    
    // PIN Verification
    Route::get('/verify-pin', [AdminController::class, 'showVerifyPin'])->name('admin.verify-pin');
    Route::post('/verify-pin', [AdminController::class, 'verifyPin'])->name('admin.verify-pin.post');
    Route::get('/lock', [AdminController::class, 'lockAdmin'])->name('admin.lock');
    
    // Order Management
    Route::get('/orders', [AdminController::class, 'orders'])->name('admin.orders');
    Route::get('/orders/{order}', [AdminController::class, 'showOrder'])->name('admin.orders.show');
    Route::put('/orders/{order}/status', [AdminController::class, 'updateOrderStatus'])->name('admin.orders.update-status');
    Route::post('/orders/{order}/deliver', [AdminController::class, 'deliverOrder'])->name('admin.orders.deliver');
    Route::delete('/orders/{order}', [AdminController::class, 'deleteOrder'])->name('admin.orders.delete');
    
    // User Management
    Route::get('/users', [AdminController::class, 'users'])->name('admin.users');
    Route::get('/users/{user}/history', [AdminController::class, 'userHistory'])->name('admin.users.history');
    Route::put('/users/{user}/role', [AdminController::class, 'updateUserRole'])->name('admin.users.update-role');
    Route::post('/users/{user}/award-tickets', [AdminController::class, 'awardSpinTickets'])->name('admin.users.award-tickets');
    Route::post('/coupons/generate', [AdminController::class, 'generateCoupon'])->name('admin.coupons.generate');
    
    // Online Users Management (Khách hàng đang xem)
    Route::get('/online-users', [\App\Http\Controllers\Admin\AdminOnlineUserController::class, 'index'])->name('admin.online-users.index');
    Route::get('/online-users/export', [\App\Http\Controllers\Admin\AdminOnlineUserController::class, 'exportExcel'])->name('admin.online-users.export');
    Route::post('/online-users/{id}/kick', [\App\Http\Controllers\Admin\AdminOnlineUserController::class, 'kick'])->name('admin.online-users.kick');
    Route::match(['POST', 'DELETE'], '/online-users/clear-history', [\App\Http\Controllers\Admin\AdminOnlineUserController::class, 'clearHistory'])->name('admin.online-users.clear-history');
    Route::delete('/online-users/{id}', [\App\Http\Controllers\Admin\AdminOnlineUserController::class, 'destroy'])->name('admin.online-users.delete');

    // Banned IPs Management (Khóa IP)
    Route::get('/banned-ips', [\App\Http\Controllers\Admin\BannedIpController::class, 'index'])->name('admin.banned-ips.index');
    Route::post('/banned-ips', [\App\Http\Controllers\Admin\BannedIpController::class, 'store'])->name('admin.banned-ips.store');
    Route::delete('/banned-ips/{id}', [\App\Http\Controllers\Admin\BannedIpController::class, 'destroy'])->name('admin.banned-ips.destroy');

    // Suspicious IP Security Logs Management (IP Nghi Ngờ & Bảo Mật)
    Route::get('/suspicious-ips', [\App\Http\Controllers\Admin\SuspiciousIpController::class, 'index'])->name('admin.suspicious-ips.index');
    Route::post('/suspicious-ips/{id}/status', [\App\Http\Controllers\Admin\SuspiciousIpController::class, 'updateStatus'])->name('admin.suspicious-ips.update-status');
    Route::match(['POST', 'DELETE'], '/suspicious-ips/clear', [\App\Http\Controllers\Admin\SuspiciousIpController::class, 'clear'])->name('admin.suspicious-ips.clear');
    Route::delete('/suspicious-ips/{id}', [\App\Http\Controllers\Admin\SuspiciousIpController::class, 'destroy'])->name('admin.suspicious-ips.destroy');
    
    // Telegram Bot Integration Routes
    Route::get('/telegram/set-webhook', [\App\Http\Controllers\TelegramWebhookController::class, 'setWebhook'])->name('admin.telegram.set-webhook');
    Route::get('/telegram/webhook-info', [\App\Http\Controllers\TelegramWebhookController::class, 'getWebhookInfo'])->name('admin.telegram.webhook-info');

    // Product Management
    Route::get('/products', [AdminController::class, 'products'])->name('admin.products');
    Route::get('/products/create/{category?}', [AdminController::class, 'createProduct'])->name('admin.products.create');
    Route::post('/products', [AdminController::class, 'storeProduct'])->name('admin.products.store');
    Route::get('/products/{product}/edit', [AdminController::class, 'editProduct'])->name('admin.products.edit');
    Route::put('/products/{product}', [AdminController::class, 'updateProduct'])->name('admin.products.update');
    Route::delete('/products/{product}', [AdminController::class, 'deleteProduct'])->name('admin.products.delete');
    Route::post('/products/{product}/clone', [AdminController::class, 'cloneProduct'])->name('admin.products.clone');
    Route::post('/products/{product}/flash-sale', [AdminController::class, 'toggleProductFlashSale'])->name('admin.products.toggle-flash-sale');
    Route::post('/products/{product}/featured', [AdminController::class, 'toggleProductFeatured'])->name('admin.products.toggle-featured');
    Route::post('/products/{product}/exclusive', [AdminController::class, 'toggleProductExclusive'])->name('admin.products.toggle-exclusive');
    Route::post('/products/{product}/combo-ai', [AdminController::class, 'toggleProductComboAi'])->name('admin.products.toggle-combo-ai');
    Route::post('/products/{product}/active', [AdminController::class, 'toggleProductActive'])->name('admin.products.toggle-active');
    Route::post('/flash-sale/toggle', [AdminController::class, 'toggleFlashSaleGlobal'])->name('admin.flash-sale.toggle');

    // Proxies Management
    Route::get('/proxies', [\App\Http\Controllers\Admin\ProxyController::class, 'index'])->name('admin.proxies');
    Route::get('/proxies/create', [\App\Http\Controllers\Admin\ProxyController::class, 'create'])->name('admin.proxies.create');
    Route::post('/proxies', [\App\Http\Controllers\Admin\ProxyController::class, 'store'])->name('admin.proxies.store');
    Route::get('/proxies/{proxy}/edit', [\App\Http\Controllers\Admin\ProxyController::class, 'edit'])->name('admin.proxies.edit');
    Route::put('/proxies/{proxy}', [\App\Http\Controllers\Admin\ProxyController::class, 'update'])->name('admin.proxies.update');
    Route::delete('/proxies/{proxy}', [\App\Http\Controllers\Admin\ProxyController::class, 'destroy'])->name('admin.proxies.destroy');

    // Product Categories Management
    Route::get('/categories', [AdminController::class, 'categories'])->name('admin.categories');
    Route::get('/categories/create', [AdminController::class, 'createCategory'])->name('admin.categories.create');
    Route::post('/categories', [AdminController::class, 'storeCategory'])->name('admin.categories.store');
    Route::get('/categories/{category}/edit', [AdminController::class, 'editCategory'])->name('admin.categories.edit');
    Route::put('/categories/{category}', [AdminController::class, 'updateCategory'])->name('admin.categories.update');
    Route::delete('/categories/{category}', [AdminController::class, 'deleteCategory'])->name('admin.categories.delete');
    
    // Features Management
    Route::get('/features', [AdminController::class, 'features'])->name('admin.features');
    Route::get('/features/create', [AdminController::class, 'createFeature'])->name('admin.features.create');
    Route::post('/features', [AdminController::class, 'storeFeature'])->name('admin.features.store');
    Route::get('/features/{feature}/edit', [AdminController::class, 'editFeature'])->name('admin.features.edit');
    Route::put('/features/{feature}', [AdminController::class, 'updateFeature'])->name('admin.features.update');
    Route::delete('/features/{feature}', [AdminController::class, 'deleteFeature'])->name('admin.features.delete');
    
    // Blog Management
    Route::get('/blogs', [AdminController::class, 'blogs'])->name('admin.blogs');
    Route::get('/blogs/create', [AdminController::class, 'createBlog'])->name('admin.blogs.create');
    Route::post('/blogs', [AdminController::class, 'storeBlog'])->name('admin.blogs.store');
    Route::get('/blogs/{blog}/edit', [AdminController::class, 'editBlog'])->name('admin.blogs.edit');
    Route::put('/blogs/{blog}', [AdminController::class, 'updateBlog'])->name('admin.blogs.update');
    Route::delete('/blogs/{blog}', [AdminController::class, 'deleteBlog'])->name('admin.blogs.delete');
    Route::match(['get', 'post'], '/google-indexing/blogs/submit-all', [GoogleIndexingController::class, 'submitAllBlogs'])->name('admin.google-indexing.submit-all');
    Route::match(['get', 'post'], '/google-indexing/products/submit-all', [GoogleIndexingController::class, 'submitAllProducts'])->name('admin.google-indexing.submit-all-products');
    Route::post('/google-indexing/categories/submit-all', [GoogleIndexingController::class, 'submitAllCategories'])->name('admin.google-indexing.submit-all-categories');
    Route::post('/google-indexing/proxies/submit-all', [GoogleIndexingController::class, 'submitAllProxies'])->name('admin.google-indexing.submit-all-proxies');
    Route::post('/google-indexing/submit-url', [GoogleIndexingController::class, 'submitUrl'])->name('admin.google-indexing.submit-url');
    Route::get('/google-indexing/recent', [GoogleIndexingController::class, 'recent'])->name('admin.google-indexing.recent');
    Route::get('/google-indexing/status', [GoogleIndexingController::class, 'status'])->name('admin.google-indexing.status');
    Route::get('/google-indexing', [GoogleIndexingController::class, 'index'])->name('admin.google-indexing.index');
    
    // Tiktok Deals Management
    // Route::get('/tiktok-deals', [TiktokDealController::class, 'index'])->name('admin.tiktok-deals.index');
    // Route::get('/tiktok-deals/create', [TiktokDealController::class, 'create'])->name('admin.tiktok-deals.create');
    // Route::post('/tiktok-deals', [TiktokDealController::class, 'store'])->name('admin.tiktok-deals.store');
    // Route::get('/tiktok-deals/{tiktokDeal}/edit', [TiktokDealController::class, 'edit'])->name('admin.tiktok-deals.edit');
    // Route::put('/tiktok-deals/{tiktokDeal}', [TiktokDealController::class, 'update'])->name('admin.tiktok-deals.update');
    // Route::delete('/tiktok-deals/{tiktokDeal}', [TiktokDealController::class, 'destroy'])->name('admin.tiktok-deals.destroy');
    // Route::post('/tiktok-deals/{tiktokDeal}/toggle', [TiktokDealController::class, 'toggleActive'])->name('admin.tiktok-deals.toggle');

    // Buff Management
    Route::get('/buff-dashboard', [AdminBuffController::class, 'dashboard'])->name('admin.buff.dashboard');
    
    // Buff Servers Management
    Route::get('/buff-servers', [AdminBuffController::class, 'serversIndex'])->name('admin.buff.servers.index');
    Route::get('/buff-servers/create', [AdminBuffController::class, 'serversCreate'])->name('admin.buff.servers.create');
    Route::post('/buff-servers', [AdminBuffController::class, 'serversStore'])->name('admin.buff.servers.store');
    Route::get('/buff-servers/{buffServer}/edit', [AdminBuffController::class, 'serversEdit'])->name('admin.buff.servers.edit');
    Route::put('/buff-servers/{buffServer}', [AdminBuffController::class, 'serversUpdate'])->name('admin.buff.servers.update');
    Route::delete('/buff-servers/{buffServer}', [AdminBuffController::class, 'serversDestroy'])->name('admin.buff.servers.destroy');
    
    // Buff Services Management
    Route::get('/buff-services', [AdminBuffController::class, 'servicesIndex'])->name('admin.buff.services.index');
    Route::get('/buff-services/create', [AdminBuffController::class, 'servicesCreate'])->name('admin.buff.services.create');
    Route::post('/buff-services', [AdminBuffController::class, 'servicesStore'])->name('admin.buff.services.store');
    Route::get('/buff-services/{buffService}/edit', [AdminBuffController::class, 'servicesEdit'])->name('admin.buff.services.edit');
    Route::put('/buff-services/{buffService}', [AdminBuffController::class, 'servicesUpdate'])->name('admin.buff.services.update');
    Route::delete('/buff-services/{buffService}', [AdminBuffController::class, 'servicesDestroy'])->name('admin.buff.services.destroy');
    
    // Buff Server Prices Management
    Route::get('/buff-prices', [AdminBuffController::class, 'pricesIndex'])->name('admin.buff.prices.index');
    Route::get('/buff-prices/create', [AdminBuffController::class, 'pricesCreate'])->name('admin.buff.prices.create');
    Route::post('/buff-prices', [AdminBuffController::class, 'pricesStore'])->name('admin.buff.prices.store');
    Route::get('/buff-prices/{buffServerPrice}/edit', [AdminBuffController::class, 'pricesEdit'])->name('admin.buff.prices.edit');
    Route::put('/buff-prices/{buffServerPrice}', [AdminBuffController::class, 'pricesUpdate'])->name('admin.buff.prices.update');
    Route::delete('/buff-prices/{buffServerPrice}', [AdminBuffController::class, 'pricesDestroy'])->name('admin.buff.prices.destroy');
    
    // Buff Orders Management
    Route::get('/buff-orders', [AdminBuffController::class, 'ordersIndex'])->name('admin.buff.orders.index');
    Route::get('/buff-orders/{buffOrder}', [AdminBuffController::class, 'ordersShow'])->name('admin.buff.orders.show');
    Route::get('/buff-orders/{buffOrder}/edit', [AdminBuffController::class, 'ordersEdit'])->name('admin.buff.orders.edit');
    Route::put('/buff-orders/{buffOrder}', [AdminBuffController::class, 'ordersUpdate'])->name('admin.buff.orders.update');

    Route::get('/abandoned-carts', [AdminController::class, 'abandonedCarts'])->name('admin.abandoned-carts');
    Route::post('/abandoned-carts/send', [AdminController::class, 'sendAbandonedCartReminders'])->name('admin.abandoned-carts.send');

    // System Notifications
    Route::get('/system-notifications', [AdminController::class, 'systemNotifications'])->name('admin.system-notifications');
    Route::post('/system-notifications/send', [AdminController::class, 'sendSystemNotifications'])->name('admin.system-notifications.send');
    
    // Card Exchange Management
    Route::get('/card-exchanges', [AdminController::class, 'cardExchanges'])->name('admin.card-exchanges');
    Route::put('/card-exchanges/{cardExchange}/status', [AdminController::class, 'updateCardExchangeStatus'])->name('admin.card-exchanges.update-status');

    // Menu Settings Management
    Route::get('/menu-settings', [AdminController::class, 'menuSettings'])->name('admin.menu-settings');
    Route::put('/menu-settings', [AdminController::class, 'updateMenuSettings'])->name('admin.menu-settings.update');

    // Pre-orders Management
    Route::get('/preorders', [AdminController::class, 'preorders'])->name('admin.preorders');
    Route::delete('/preorders/{id}', [AdminController::class, 'deletePreorder'])->name('admin.preorders.delete');
    Route::post('/preorders/{id}/notify', [AdminController::class, 'notifyPreorder'])->name('admin.preorders.notify');
    Route::post('/preorders/notify-keyword', [AdminController::class, 'notifyPreordersByKeyword'])->name('admin.preorders.notify-keyword');

    // Sidebar Counters
    Route::get('/sidebar-counters', [AdminController::class, 'sidebarCounters'])->name('admin.sidebar-counters');


    // SEO Keywords Management
    Route::get('/seo-keywords', [AdminController::class, 'seoKeywords'])->name('admin.seo-keywords');
    Route::post('/seo-keywords/submit-all', [AdminController::class, 'submitAllKeywords'])->name('admin.seo-keywords.submit-all');
    Route::get('/seo-keywords/create', [AdminController::class, 'createSeoKeyword'])->name('admin.seo-keywords.create');
    Route::post('/seo-keywords', [AdminController::class, 'storeSeoKeyword'])->name('admin.seo-keywords.store');
    Route::get('/seo-keywords/{id}/edit', [AdminController::class, 'editSeoKeyword'])->name('admin.seo-keywords.edit');
    Route::put('/seo-keywords/{id}', [AdminController::class, 'updateSeoKeyword'])->name('admin.seo-keywords.update');
    Route::delete('/seo-keywords/{id}', [AdminController::class, 'deleteSeoKeyword'])->name('admin.seo-keywords.delete');
    Route::post('/seo-keywords/{id}/submit-index', [AdminController::class, 'submitKeywordIndex'])->name('admin.seo-keywords.submit-index');

    // Blog Topics Management
    Route::get('/blog-topics', [AdminController::class, 'blogTopics'])->name('admin.blog-topics');
    Route::get('/blog-topics/create', [AdminController::class, 'createBlogTopic'])->name('admin.blog-topics.create');
    Route::post('/blog-topics', [AdminController::class, 'storeBlogTopic'])->name('admin.blog-topics.store');
    Route::get('/blog-topics/{id}/edit', [AdminController::class, 'editBlogTopic'])->name('admin.blog-topics.edit');
    Route::put('/blog-topics/{id}', [AdminController::class, 'updateBlogTopic'])->name('admin.blog-topics.update');
    Route::delete('/blog-topics/{id}', [AdminController::class, 'deleteBlogTopic'])->name('admin.blog-topics.delete');

    // Affiliate Management
    Route::prefix('affiliates')->group(function () {
        Route::get('/', [AdminAffiliateController::class, 'index'])->name('admin.affiliates.index');
        Route::post('/store', [AdminAffiliateController::class, 'store'])->name('admin.affiliates.store');
        Route::get('/{affiliate}', [AdminAffiliateController::class, 'show'])->name('admin.affiliates.show');
        Route::post('/{affiliate}/approve', [AdminAffiliateController::class, 'approve'])->name('admin.affiliates.approve');
        Route::post('/{affiliate}/reject', [AdminAffiliateController::class, 'reject'])->name('admin.affiliates.reject');
        Route::post('/{affiliate}/reset-password', [AdminAffiliateController::class, 'resetPassword'])->name('admin.affiliates.reset-password');

        // Invoice management
        Route::get('/invoices/list', [AdminAffiliateController::class, 'invoices'])->name('admin.affiliates.invoices');
        Route::post('/invoices/{invoice}/approve', [AdminAffiliateController::class, 'approveInvoice'])->name('admin.affiliates.invoices.approve');
        Route::post('/invoices/{invoice}/reject', [AdminAffiliateController::class, 'rejectInvoice'])->name('admin.affiliates.invoices.reject');

        // Withdrawal management
        Route::get('/withdrawals/list', [AdminAffiliateController::class, 'withdrawals'])->name('admin.affiliates.withdrawals');
        Route::post('/withdrawals/{withdrawal}/approve', [AdminAffiliateController::class, 'approveWithdrawal'])->name('admin.affiliates.withdrawals.approve');
        Route::post('/withdrawals/{withdrawal}/reject', [AdminAffiliateController::class, 'rejectWithdrawal'])->name('admin.affiliates.withdrawals.reject');
    });

    // Customer Durations Management
    Route::get('/customer-durations', [CustomerDurationController::class, 'index'])->name('admin.customer-durations');
    Route::get('/customer-durations/create', [CustomerDurationController::class, 'create'])->name('admin.customer-durations.create');
    Route::post('/customer-durations', [CustomerDurationController::class, 'store'])->name('admin.customer-durations.store');
    Route::post('/customer-durations/bulk-action', [CustomerDurationController::class, 'bulkAction'])->name('admin.customer-durations.bulk-action');
    Route::patch('/customer-durations/{customerDuration}/toggle-hide', [CustomerDurationController::class, 'toggleHide'])->name('admin.customer-durations.toggle-hide');
    Route::get('/customer-durations/{customerDuration}/edit', [CustomerDurationController::class, 'edit'])->name('admin.customer-durations.edit');
    Route::put('/customer-durations/{customerDuration}', [CustomerDurationController::class, 'update'])->name('admin.customer-durations.update');
    Route::delete('/customer-durations/{customerDuration}', [CustomerDurationController::class, 'destroy'])->name('admin.customer-durations.destroy');
});

// ─── Affiliate (Cộng Tác Viên) Public Routes ─────────────────────────────────
Route::prefix('cong-tac-vien')->group(function () {
    Route::get('/dang-nhap', [AffiliateAuthController::class, 'showLogin'])->name('affiliate.login');
    Route::post('/dang-nhap', [AffiliateAuthController::class, 'login'])->middleware('throttle:10,1')->name('affiliate.login.post');
    Route::get('/dang-ky', [AffiliateAuthController::class, 'showRegister'])->name('affiliate.register');
    Route::post('/dang-ky', [AffiliateAuthController::class, 'register'])->middleware('throttle:5,1')->name('affiliate.register.post');
    Route::post('/dang-xuat', [AffiliateAuthController::class, 'logout'])->name('affiliate.logout');

    // Status pages (accessible when logged in but not approved)
    Route::middleware('affiliate.auth')->group(function () {
        Route::get('/cho-duyet', [AffiliateDashboardController::class, 'pending'])->name('affiliate.pending');
        Route::get('/tu-choi', [AffiliateDashboardController::class, 'rejected'])->name('affiliate.rejected');
    });

    // Protected routes (approved affiliates only)
    Route::middleware('affiliate.approved')->group(function () {
        Route::get('/dashboard', [AffiliateDashboardController::class, 'dashboard'])->name('affiliate.dashboard');

        // Invoices
        Route::get('/hoa-don', [AffiliateDashboardController::class, 'invoices'])->name('affiliate.invoices');
        Route::get('/hoa-don/gui', [AffiliateDashboardController::class, 'createInvoice'])->name('affiliate.invoices.create');
        Route::post('/hoa-don/gui', [AffiliateDashboardController::class, 'storeInvoice'])->name('affiliate.invoices.store');

        // Withdrawals
        Route::get('/rut-tien', [AffiliateDashboardController::class, 'withdrawals'])->name('affiliate.withdrawals');
        Route::get('/rut-tien/tao', [AffiliateDashboardController::class, 'createWithdrawal'])->name('affiliate.withdrawals.create');
        Route::post('/rut-tien/tao', [AffiliateDashboardController::class, 'storeWithdrawal'])->name('affiliate.withdrawals.store');

        // Chat routes for affiliate
        Route::get('/chat/messages', [\App\Http\Controllers\Affiliate\AffiliateChatController::class, 'index'])->name('affiliate.chat.messages');
        Route::post('/chat/send', [\App\Http\Controllers\Affiliate\AffiliateChatController::class, 'store'])->name('affiliate.chat.send');
        Route::get('/chat/new', [\App\Http\Controllers\Affiliate\AffiliateChatController::class, 'getNewMessages'])->name('affiliate.chat.new');
        Route::get('/chat/unread-count', [\App\Http\Controllers\Affiliate\AffiliateChatController::class, 'unreadCount'])->name('affiliate.chat.unread-count');
        Route::post('/chat/mark-read', [\App\Http\Controllers\Affiliate\AffiliateChatController::class, 'markRead'])->name('affiliate.chat.mark-read');

        // Account
        Route::get('/tai-khoan', [AffiliateDashboardController::class, 'account'])->name('affiliate.account');
        Route::put('/tai-khoan', [AffiliateDashboardController::class, 'updateAccount'])->name('affiliate.account.update');
        Route::put('/tai-khoan/mat-khau', [AffiliateDashboardController::class, 'updatePassword'])->name('affiliate.account.password');
    });
});

// ─── Admin Affiliate Routes ───────────────────────────────────────────────────
Route::post('/newsletter/subscribe', [NewsletterController::class, 'subscribe'])->name('newsletter.subscribe');

// Test email route
Route::get('/test-email', function() {
    $order = \App\Models\Order::first();
    if (!$order) {
        return 'Không tìm thấy đơn hàng nào để test';
    }
    
    try {
        \Illuminate\Support\Facades\Mail::to($order->customer_email)->send(
            new \App\Mail\OrderCompletedMail($order, 'testuser_demo_' . $order->id, 'Cudanmangorg_1')
        );
        return 'Email đã được gửi đến: ' . $order->customer_email;
    } catch (\Exception $e) {
        return 'Lỗi: ' . $e->getMessage();
    }
});

// Auto-Matching Dynamic SEO Router
Route::get('/go/{slug}', [\App\Http\Controllers\SeoRouterController::class, 'handle'])->name('seo.router');
Route::post('/go/{slug}/subscribe', [\App\Http\Controllers\SeoRouterController::class, 'subscribe'])->name('seo.router.subscribe');

// SePay Webhook & Auto-Payment check routes
Route::post('/webhook/sepay', [WebhookController::class, 'handleSepayWebhook'])->name('payment.webhook.sepay');
Route::get('/api/payment/check-status/{orderCode}', [WebhookController::class, 'checkStatus'])->name('payment.check-status');
Route::post('/api/payment/check-webhook/{orderCode}', [WebhookController::class, 'checkWebhook'])->middleware('throttle:10,1')->name('payment.check-webhook');
