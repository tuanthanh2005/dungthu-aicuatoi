@extends('layouts.app')

@section('title', $product->name . ' - AICuaToi.com')
@section('meta_description', Str::limit(strip_tags($product->description), 160))
@section('og_image', asset($product->image))
@section('canonical', route('product.show', $product->slug))

@push('head')
    <script type="application/ld+json">
        {!! json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => $product->name,
            'description' => Str::limit(strip_tags($product->description), 300),
            'image' => asset($product->image),
            'url' => route('product.show', $product->slug),
            'brand' => [
                '@type' => 'Brand',
                'name' => 'AICuaToi.com',
            ],
            'offers' => [
                '@type' => 'Offer',
                'url' => route('product.show', $product->slug),
                'priceCurrency' => 'VND',
                'price' => (float) $product->effective_price,
                'availability' => $product->isInStock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}
    </script>
@endpush

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
    <style>
        .product-detail-image {
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .description-content {
            font-size: 1rem;
        }
        .product-detail-image:hover {
            transform: scale(1.02);
        }
        .info-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }
        .info-badge i {
            font-size: 1.5rem;
            margin-right: 15px;
        }
        .nav-tabs .nav-link {
            border: none;
            background: white;
            margin: 0 5px;
            border-radius: 12px;
            padding: 15px 30px;
            color: #6c757d;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
        }
        .nav-tabs .nav-link:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102,126,234,0.3);
        }
        .nav-tabs .nav-link.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 5px 20px rgba(102,126,234,0.4);
        }
        .rating-input {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-end;
            gap: 5px;
        }
        .rating-input input {
            display: none;
        }
        .rating-input label {
            cursor: pointer;
            font-size: 28px;
            color: #ddd;
            transition: color 0.2s;
        }
        .rating-input label:hover,
        .rating-input label:hover ~ label,
        .rating-input input:checked ~ label {
            color: #ffc107;
        }

        /* --- MOBILE RESPONSIVE TWEAKS --- */
        @media (max-width: 768px) {
            .container {
                padding-left: 15px;
                padding-right: 15px;
                margin-top: 60px !important;
            }
            .product-detail-image {
                border-radius: 12px;
            }
            h1.fw-bold {
                font-size: 1.4rem;
                line-height: 1.4;
            }
            .lead.text-muted {
                font-size: 0.95rem;
                margin-bottom: 1.2rem !important;
            }
            h2.text-primary {
                font-size: 1.6rem;
            }
            
            /* Buttons layout */
            .d-flex.gap-3.mb-3 {
                gap: 10px !important;
                flex-direction: column;
            }
            .btn-lg {
                padding: 12px 15px !important;
                font-size: 1rem;
                width: 100%;
                border-radius: 12px !important;
            }
            
            /* Badges */
            .info-badge {
                padding: 12px 15px;
                border-radius: 10px;
                flex-direction: row;
                text-align: left;
                gap: 10px;
            }
            .info-badge i {
                margin-right: 0;
                font-size: 1.4rem;
            }
            
            /* Tabs responsive */
            .nav-tabs.nav-fill {
                flex-wrap: nowrap;
                overflow-x: auto;
                padding-bottom: 5px;
                -webkit-overflow-scrolling: touch;
            }
            .nav-tabs.nav-fill::-webkit-scrollbar {
                display: none;
            }
            .nav-tabs .nav-link {
                padding: 10px 15px;
                margin: 0 4px;
                font-size: 0.85rem;
                white-space: nowrap;
                min-width: 120px;
            }
            
            /* Typography & Spacing inside cards */
            .card-body {
                padding: 1.2rem !important;
            }
            .description-content {
                font-size: 0.95rem;
            }
            .display-4 {
                font-size: 2.2rem;
            }
            .rating-input label {
                font-size: 24px;
            }
        }
    </style>
@endpush

@section('content')
<div class="container py-2" style="margin-top: 50px;">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4" data-aos="fade-down">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Trang chủ') }}</a></li>
            <li class="breadcrumb-item"><a href="{{ route('shop') }}">{{ __('Cửa hàng') }}</a></li>
            <li class="breadcrumb-item active">{{ $product->name }}</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-6 mb-4" data-aos="fade-right">
            <img src="{{ $product->image ?? 'https://via.placeholder.com/600' }}" 
                 class="img-fluid product-detail-image w-100" 
                 alt="{{ $product->name }}">
            @include('products.partials.desktop_banners')
        </div>
        
        <div class="col-lg-6" data-aos="fade-left">
            <span class="badge bg-primary mb-2">{{ strtoupper($product->category) }}</span>
            <h1 class="fw-bold mb-3">{{ $product->name }}</h1>
            <p class="lead text-muted mb-4">{{ Str::limit($product->description, 150, '......') }}</p>
            
            <div class="mb-4">
                <div class="d-flex align-items-end gap-3 flex-wrap">
                    <h2 class="text-primary fw-bold mb-0">{{ $product->formatted_price }}</h2>
                    @if($product->is_on_sale)
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <span class="text-muted text-decoration-line-through">{{ $product->formatted_original_price }}</span>
                            <span class="badge bg-danger">-{{ $product->discount_percent }}%</span>
                        </div>
                    @endif
                </div>
                <small class="text-muted">{{ __('Giá đã bao gồm VAT') }}</small>
            </div>
            
            @if($product->stock > 0)
                <div class="d-flex align-items-center flex-wrap gap-2">
                    <div class="alert alert-success d-inline-flex align-items-center mb-0">
                        <i class="fas fa-check-circle"></i> {{ __('Còn hàng') }} ({{ $product->stock }} {{ __('sản phẩm') }})
                    </div>
                    <small class="text-muted">{{ __('Gia hạn theo tháng 3/6/12 tháng: liên hệ admin hoặc box chat') }}</small>
                </div>
                @else
                <div class="alert alert-danger d-inline-block">
                    <i class="fas fa-times-circle"></i> {{ __('Hết hàng') }}
                </div>
            @endif
            
            @if($product->stock > 0)
            <form action="{{ route('cart.add', $product->id) }}" method="POST" class="mt-4">
                @csrf
                <div class="d-flex gap-3 mb-3 flex-wrap">
                    <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 shadow">
                        <i class="fas fa-shopping-cart me-2"></i> {{ __('Thêm vào giỏ') }}
                    </button>
                    @if($product->delivery_type === 'digital')
                    <button type="submit" formaction="{{ route('cart.buy-now', $product->id) }}" class="btn btn-warning btn-lg rounded-pill px-4 shadow">
                        <i class="fas fa-bolt me-2"></i> {{ __('Mua ngay') }}
                    </button>
                    @endif
                    <a href="{{ route('shop') }}" class="btn btn-outline-secondary btn-lg rounded-pill px-4">
                        <i class="fas fa-arrow-left me-2"></i> {{ __('Tiếp tục mua') }}
                    </a>
                </div>
            </form>
            @else
            <div class="d-flex gap-3 mb-3 mt-4 flex-wrap">
                <button type="button" class="btn btn-secondary btn-lg rounded-pill px-5" disabled>
                    <i class="fas fa-ban me-2"></i> {{ __('Hết hàng') }}
                </button>
                <a href="{{ route('shop') }}" class="btn btn-outline-secondary btn-lg rounded-pill px-4">
                    <i class="fas fa-arrow-left me-2"></i> {{ __('Tiếp tục mua') }}
                </a>
            </div>
            @endif

            <div class="mt-5">
                <h5 class="fw-bold mb-3"><i class="fas fa-star text-warning"></i> {{ __('Ưu điểm nổi bật') }}</h5>
                <div class="row g-2">
                    <div class="col-md-6">
                        <div class="info-badge">
                            <i class="fas fa-shield-alt"></i>
                            <div>
                                <strong>{{ __('Chính hãng 100%') }}</strong><br>
                                <small>{{ __('Cam kết hàng thật') }}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-badge" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                            <i class="fas fa-tools"></i>
                            <div>
                                <strong>{{ __('Bảo hành 12 tháng') }}</strong><br>
                                <small>{{ __('Đổi trả miễn phí') }}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-badge" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                            <i class="fas fa-shipping-fast"></i>
                            <div>
                                <strong>{{ __('Giao hàng nhanh') }}</strong><br>
                                <small>{{ __('Toàn quốc 24h') }}</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="info-badge" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                            <i class="fas fa-headset"></i>
                            <div>
                                <strong>{{ __('Hỗ trợ 24/7') }}</strong><br>
                                <small>{{ __('Tư vấn miễn phí') }}</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tabs Section -->
    <div class="row mt-5">
        <div class="col-12">
            <ul class="nav nav-tabs nav-fill border-0" id="productTabs" role="tablist" data-aos="fade-up">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold" id="features-tab" data-bs-toggle="tab" 
                            data-bs-target="#features" type="button" role="tab">
                        <i class="fas fa-star me-2"></i>{{ __('Tính Năng Nổi Bật') }}
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" id="description-tab" data-bs-toggle="tab" 
                            data-bs-target="#description" type="button" role="tab">
                        <i class="fas fa-align-left me-2"></i>{{ __('Mô Tả Chi Tiết') }}
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fw-bold" id="reviews-tab" data-bs-toggle="tab" 
                            data-bs-target="#reviews" type="button" role="tab">
                        <i class="fas fa-comments me-2"></i>{{ __('Đánh Giá Sản Phẩm') }}
                    </button>
                </li>
            </ul>

            <div class="tab-content mt-4" id="productTabsContent">
                <!-- Features Tab -->
                <div class="tab-pane fade show active" id="features" role="tabpanel" data-aos="fade-up">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h4 class="fw-bold mb-4">
                                <i class="fas fa-star text-warning me-2"></i>{{ __('Tính Năng Nổi Bật') }}
                            </h4>
                            @if($product->features && $product->features->count() > 0)
                                <div class="row g-3">
                                    @foreach($product->features as $feature)
                                        <div class="col-md-6">
                                            <div class="d-flex align-items-start mb-3">
                                                <div class="me-3">
                                                    <i class="{{ $feature->icon }} fs-4" style="color: {{ $feature->color }}"></i>
                                                </div>
                                                <div>
                                                    <h6 class="fw-bold mb-1">{{ $feature->name }}</h6>
                                                    @if($feature->description)
                                                        <p class="text-muted mb-0">{{ $feature->description }}</p>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="alert alert-info mb-0">
                                    <i class="fas fa-info-circle me-2"></i>
                                    {{ __('Chưa có thông tin tính năng cho sản phẩm này.') }}
                                </div>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Description Tab -->
                <div class="tab-pane fade" id="description" role="tabpanel" data-aos="fade-up">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h4 class="fw-bold mb-4">
                                <i class="fas fa-align-left text-primary me-2"></i>{{ __('Mô Tả Chi Tiết') }}
                            </h4>
                            <div class="text-muted mb-4 description-content" style="line-height: 1.8;" >{{ $product->description }}</div>
                            
                            <div class="border-top pt-4 mt-4">
                                <h5 class="fw-bold text-primary mb-4">
                                    <i class="fas fa-cube me-2"></i>{{ __('Thông Số Kỹ Thuật') }}
                                </h5>
                                <div class="row g-4">
                                    <div class="col-lg-6">
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-list-ul text-primary me-2"></i><strong>{{ __('Danh mục:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">{{ strtoupper($product->category) }}</p>
                                        </div>
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-barcode text-primary me-2"></i><strong>SKU:</strong>
                                            <p class="ms-4 mb-0 text-muted">#{{ $product->id }}</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-check-circle text-success me-2"></i><strong>{{ __('Tình trạng:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">{{ $product->stock > 0 ? __('Còn hàng') : __('Hết hàng') }}</p>
                                        </div>
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-globe text-primary me-2"></i><strong>{{ __('Xuất xứ:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">{{ __('Chính hãng') }}</p>
                                        </div>
                                    </div>
                                </div>

                                @if($product->specs)
                                    <div class="row g-4 mt-2">
                                        @foreach($product->specs as $key => $value)
                                            <div class="col-lg-6">
                                                <div class="p-3 bg-light rounded-3 mb-3">
                                                    <i class="fas fa-info-circle text-primary me-2"></i><strong>{{ ucfirst(str_replace('_', ' ', $key)) }}:</strong>
                                                    <p class="ms-4 mb-0 text-muted">{{ is_array($value) ? implode(', ', $value) : $value }}</p>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            </div>

                            <div class="border-top pt-4 mt-4">
                                <h5 class="fw-bold text-primary mb-4">
                                    <i class="fas fa-box-open me-2"></i>{{ __('Thông Tin Thêm') }}
                                </h5>
                                <div class="row g-4">
                                    <div class="col-lg-6">
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-shield-alt text-primary me-2"></i><strong>{{ __('Bảo hành:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">{{ __('12 tháng') }}</p>
                                        </div>
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-credit-card text-primary me-2"></i><strong>{{ __('Thanh toán:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">COD, Banking, Transfer</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-shipping-fast text-primary me-2"></i><strong>{{ __('Giao hàng:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">{{ __('Toàn quốc (24-48h)') }}</p>
                                        </div>
                                        <div class="p-3 bg-light rounded-3 mb-3">
                                            <i class="fas fa-undo text-primary me-2"></i><strong>{{ __('Đổi trả:') }}</strong>
                                            <p class="ms-4 mb-0 text-muted">{{ __('7 ngày từ ngày mua') }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="alert alert-info mt-4 rounded-4">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>{{ __('Lưu ý:') }}</strong> {{ __('Sản phẩm được đóng gói cẩn thận, kiểm tra kỹ càng trước khi giao hàng. Quý khách vui lòng kiểm tra sản phẩm trước khi thanh toán.') }}
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Reviews Tab -->
                <div class="tab-pane fade" id="reviews" role="tabpanel" data-aos="fade-up">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h4 class="fw-bold mb-4">
                                <i class="fas fa-comments text-warning me-2"></i>{{ __('Đánh Giá Sản Phẩm') }}
                            </h4>
                            
                            <!-- Overall Rating -->
                            <div class="text-center mb-5 p-4 bg-light rounded-4">
                                <div class="display-4 fw-bold text-primary mb-2">{{ number_format($averageRating, 1) }}</div>
                                <div class="mb-2">
                                    @for($i = 1; $i <= 5; $i++)
                                        @if($i <= floor($averageRating))
                                            <i class="fas fa-star text-warning"></i>
                                        @elseif($i - $averageRating < 1)
                                            <i class="fas fa-star-half-alt text-warning"></i>
                                        @else
                                            <i class="far fa-star text-warning"></i>
                                        @endif
                                    @endfor
                                </div>
                                <p class="text-muted mb-0">{{ __('Dựa trên') }} <strong>{{ $totalReviews }}</strong> {{ __('đánh giá') }}</p>
                            </div>

                            <!-- Comment Form (Only for logged in users) -->
                            @auth
                            <div class="card bg-light border-0 mb-4 rounded-4">
                                <div class="card-body p-4">
                                    <h5 class="fw-bold mb-3">
                                        <i class="fas fa-edit text-primary me-2"></i>{{ __('Viết đánh giá của bạn') }}
                                    </h5>
                                    <form action="{{ route('product.comment', $product->id) }}" method="POST">
                                        @csrf
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">{{ __('Đánh giá của bạn') }} <span class="text-danger">*</span></label>
                                            <div class="rating-input mb-2">
                                                <input type="radio" name="rating" value="5" id="star5" required>
                                                <label for="star5" title="5 sao"><i class="fas fa-star"></i></label>
                                                <input type="radio" name="rating" value="4" id="star4">
                                                <label for="star4" title="4 sao"><i class="fas fa-star"></i></label>
                                                <input type="radio" name="rating" value="3" id="star3">
                                                <label for="star3" title="3 sao"><i class="fas fa-star"></i></label>
                                                <input type="radio" name="rating" value="2" id="star2">
                                                <label for="star2" title="2 sao"><i class="fas fa-star"></i></label>
                                                <input type="radio" name="rating" value="1" id="star1">
                                                <label for="star1" title="1 sao"><i class="fas fa-star"></i></label>
                                            </div>
                                            @error('rating')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">{{ __('Nhận xét') }} <span class="text-danger">*</span></label>
                                            <textarea name="comment" class="form-control rounded-3" rows="4" 
                                                      placeholder="{{ __('Chia sẻ trải nghiệm của bạn về sản phẩm...') }}" required>{{ old('comment') }}</textarea>
                                            @error('comment')
                                                <small class="text-danger">{{ $message }}</small>
                                            @enderror
                                        </div>
                                        <button type="submit" class="btn btn-primary rounded-pill px-4">
                                            <i class="fas fa-paper-plane me-2"></i>{{ __('Gửi đánh giá') }}
                                        </button>
                                    </form>
                                </div>
                            </div>
                            @else
                            <div class="alert alert-info rounded-4 mb-4">
                                <i class="fas fa-info-circle me-2"></i>
                                {!! __('Bạn cần :login để viết đánh giá.', ['login' => '<a href="'.route('login').'" class="alert-link fw-bold">'.__('đăng nhập').'</a>']) !!}
                            </div>
                            @endauth

                            <!-- Individual Reviews -->
                            @forelse($product->comments as $comment)
                            <div class="review-item mb-4 pb-4 border-bottom">
                                <div class="d-flex align-items-start">
                                    <div class="avatar me-3">
                                        <div class="bg-{{ ['primary', 'success', 'info', 'warning', 'danger'][rand(0, 4)] }} text-white rounded-circle d-flex align-items-center justify-content-center" 
                                             style="width: 50px; height: 50px; font-weight: bold;">
                                            {{ strtoupper(substr($comment->user->name, 0, 2)) }}
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="fw-bold mb-0">{{ $comment->user->name }}</h6>
                                            <small class="text-muted">{{ $comment->created_at->format('d/m/Y H:i') }}</small>
                                        </div>
                                        <div class="mb-2">
                                            @for($i = 1; $i <= 5; $i++)
                                                @if($i <= $comment->rating)
                                                    <i class="fas fa-star text-warning"></i>
                                                @else
                                                    <i class="far fa-star text-warning"></i>
                                                @endif
                                            @endfor
                                        </div>
                                        <p class="text-muted mb-0">{{ $comment->comment }}</p>
                                    </div>
                                </div>
                            </div>
                            @empty
                            <div class="text-center py-5">
                                <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                                <p class="text-muted">{{ __('Chưa có đánh giá nào cho sản phẩm này. Hãy là người đầu tiên!') }}</p>
                            </div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
    <script>
        AOS.init({ duration: 800, once: true });
    </script>
@endpush

