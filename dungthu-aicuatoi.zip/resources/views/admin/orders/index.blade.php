@extends('layouts.admin')

@section('title', 'Quản lý Đơn hàng - Admin')

@section('page_title', 'Đơn hàng')

@push('styles')
<style>

    .admin-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }

    .filter-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 30px;
        flex-wrap: wrap;
    }

    .filter-tab {
        padding: 10px 20px;
        border-radius: 25px;
        border: 2px solid #e2e8f0;
        background: white;
        color: #4a5568;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .filter-tab:hover {
        border-color: #667eea;
        color: #667eea;
        transform: translateY(-2px);
    }

    .filter-tab.active {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-color: #667eea;
        color: white;
    }

    .order-card {
        background: white;
        border: 2px solid #e2e8f0;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
        transition: all 0.3s ease;
    }

    .order-card:hover {
        border-color: #667eea;
        box-shadow: 0 5px 20px rgba(102,126,234,0.2);
        transform: translateY(-2px);
    }

    .order-type-badge {
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .type-qr {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
    }

    .type-document {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        color: white;
    }

    .type-shipping {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        color: white;
    }

    .type-digital {
        background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        color: white;
    }

    /* Compact Search Form */
    .compact-search-form {
        display: flex;
        align-items: center;
        background: #f1f2f6;
        border-radius: 30px;
        padding: 5px 15px;
        border: 1px solid transparent;
        transition: all 0.3s ease;
        width: 250px;
    }
    .compact-search-form:focus-within {
        background: #fff;
        border-color: #667eea;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
        width: 320px;
    }
    .compact-search-input {
        border: none;
        outline: none;
        background: transparent;
        font-size: 0.9rem;
        color: #2d3436;
        width: 100%;
        font-weight: 500;
    }
    .compact-search-icon {
        color: #667eea;
        font-size: 0.85rem;
        margin-right: 10px;
    }
</style>
@endpush

@section('content')
<div class="container-fluid px-0">
        <div class="admin-card" data-aos="fade-up">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <h3 class="fw-bold mb-0">
                        <i class="fas fa-shopping-cart text-primary me-3"></i>Quản lý Đơn hàng
                    </h3>

                    <form action="{{ route('admin.orders') }}" method="GET" class="compact-search-form">
                        <i class="fas fa-search compact-search-icon"></i>
                        <input type="text" name="search" class="compact-search-input" placeholder="Mã đơn, tên, email, SĐT..." value="{{ request('search') }}">
                        <button type="submit" class="d-none"></button>
                    </form>
                </div>
            </div>

            <!-- Success Message -->
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <!-- Filter Tabs by Order Type -->
            <div class="filter-tabs">
                <a href="{{ route('admin.orders') }}" class="filter-tab {{ !request('type') || request('type') == 'all' ? 'active' : '' }}">
                    <i class="fas fa-th-list me-2"></i>Tất cả
                </a>
                <a href="{{ route('admin.orders', ['type' => 'digital']) }}" class="filter-tab {{ request('type') == 'digital' ? 'active' : '' }}">
                    <i class="fas fa-download me-2"></i>Sản phẩm số (Digital)
                </a>
            </div>

            <!-- Filter by Status -->
            <div class="filter-tabs">
                <a href="{{ route('admin.orders', array_merge(request()->all(), ['status' => 'all'])) }}" class="filter-tab {{ !request('status') || request('status') == 'all' ? 'active' : '' }}">
                    Tất cả trạng thái
                </a>
                <a href="{{ route('admin.orders', array_merge(request()->all(), ['status' => 'pending'])) }}" class="filter-tab {{ request('status') == 'pending' ? 'active' : '' }}">
                    Chờ xử lý
                </a>
                <a href="{{ route('admin.orders', array_merge(request()->all(), ['status' => 'processing'])) }}" class="filter-tab {{ request('status') == 'processing' ? 'active' : '' }}">
                    Đang xử lý
                </a>
                <a href="{{ route('admin.orders', array_merge(request()->all(), ['status' => 'completed'])) }}" class="filter-tab {{ request('status') == 'completed' ? 'active' : '' }}">
                    Hoàn thành
                </a>
            </div>

            <!-- Orders List -->
            @forelse($orders as $order)
                <div class="order-card">
                    <div class="row align-items-center">
                        <div class="col-md-2">
                            <div class="mb-2">
                                <strong>#{{ $order->id }}</strong>
                            </div>
                            <span class="order-type-badge type-{{ $order->order_type }}">
                                @if($order->order_type == 'qr')
                                    <i class="fas fa-qrcode me-1"></i>QR
                                @elseif($order->order_type == 'document')
                                    <i class="fas fa-file-pdf me-1"></i>Tài liệu
                                @elseif($order->order_type == 'shipping')
                                    <i class="fas fa-shipping-fast me-1"></i>Ship
                                @else
                                    <i class="fas fa-download me-1"></i>Digital
                                @endif
                            </span>
                        </div>
                        <div class="col-md-3">
                            <div><i class="fas fa-user me-2 text-primary"></i>{{ $order->customer_name }}</div>
                            <small class="text-muted"><i class="fas fa-phone me-2"></i>{{ $order->customer_phone }}</small>
                        </div>
                        <div class="col-md-2">
                            <div class="fw-bold text-primary">{{ $order->formatted_total }}</div>
                            <small class="text-muted">{{ $order->orderItems->count() }} sản phẩm</small>
                        </div>
                        <div class="col-md-2">
                            <span class="badge bg-{{ $order->status_color }} px-3 py-2">
                                {{ $order->status_label }}
                            </span>
                            @if($order->status_note)
                                <div class="mt-1">
                                    <small class="text-muted" style="font-size: 11px;"><i class="fas fa-sticky-note text-warning me-1"></i>{{ \Illuminate\Support\Str::limit($order->status_note, 35) }}</small>
                                </div>
                            @elseif($order->status == 'completed')
                                <div class="mt-1">
                                    <small class="badge bg-success" style="font-size: 10px;">✅ Đã xác nhận</small>
                                </div>
                            @endif
                        </div>
                        <div class="col-md-2">
                            <small class="text-muted">{{ $order->created_at->format('d/m/Y H:i') }}</small>
                        </div>
                        <div class="col-md-1 text-end">
                            <a href="{{ route('admin.orders.show', $order) }}" class="btn btn-sm btn-outline-primary rounded-pill">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </div>
                </div>
            @empty
                <div class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <p class="text-muted">Không có đơn hàng nào</p>
                </div>
            @endforelse

            <!-- Pagination -->
            <div class="mt-4">
                {{ $orders->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    AOS.init({ duration: 800, once: true });
</script>
@endpush
