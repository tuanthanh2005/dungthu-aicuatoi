@extends('layouts.admin')

@section('title', 'Chỉnh sửa Sản phẩm - Admin')

@section('page_title', 'Sửa sản phẩm')

@push('styles')
<style>

    .admin-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        max-width: 800px;
        margin: 0 auto;
    }

    .form-label {
        font-weight: 600;
        color: #2d3748;
        margin-bottom: 8px;
    }

    .form-control, .form-select {
        border-radius: 10px;
        border: 2px solid #e2e8f0;
        padding: 12px 16px;
        transition: all 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
    }

    .category-hint {
        font-size: 0.9rem;
        color: #6b7280;
        margin-top: 6px;
    }

    .btn-submit {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        padding: 14px 40px;
        border-radius: 25px;
        color: white;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-submit:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(102,126,234,0.4);
    }

    .image-preview {
        max-width: 200px;
        border-radius: 15px;
        margin-top: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
</style>
@endpush

@section('content')
<div class="container-fluid px-0">
        <div class="admin-card" data-aos="fade-up">
            <div class="mb-4">
                <a href="{{ route('admin.products', request()->only(['page', 'search', 'category', 'flash_sale'])) }}" class="btn btn-outline-secondary rounded-pill mb-3">
                    <i class="fas fa-arrow-left me-2"></i>Quay lại
                </a>
                <h3 class="fw-bold mb-0">
                    <i class="fas fa-edit text-primary me-3"></i>Chỉnh sửa Sản phẩm
                </h3>
            </div>

            <!-- Success Message -->
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <!-- Error Messages -->
            @if($errors->any())
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h6 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Có lỗi xảy ra!</h6>
                    <ul class="mb-0">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <form action="{{ route('admin.products.update', array_merge(['product' => $product->id], request()->only(['page', 'search', 'category', 'flash_sale']))) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- Product Name -->
                <div class="mb-4">
                    <label for="name" class="form-label">
                        <i class="fas fa-tag me-2 text-primary"></i>Tên sản phẩm <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control @error('name') is-invalid @enderror" 
                           id="name" 
                           name="name" 
                           value="{{ old('name', $product->name) }}"
                           placeholder="Nhập tên sản phẩm..."
                           required>
                    @error('name')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Product Name (English) -->
                <div class="mb-4">
                    <label for="name_en" class="form-label text-success">
                        <i class="fas fa-tag me-2"></i>Tên sản phẩm (Tiếng Anh)
                    </label>
                    <input type="text" 
                           class="form-control @error('name_en') is-invalid @enderror" 
                           id="name_en" 
                           name="name_en" 
                           value="{{ old('name_en', $product->name_en) }}"
                           placeholder="Enter product name in English...">
                    @error('name_en')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <label for="description" class="form-label">
                        <i class="fas fa-align-left me-2 text-primary"></i>Mô tả <span class="text-danger">*</span>
                    </label>
                    <textarea class="form-control @error('description') is-invalid @enderror" 
                              id="description" 
                              name="description" 
                              rows="4"
                              placeholder="Nhập mô tả chi tiết sản phẩm..."
                              required>{{ old('description', $product->description) }}</textarea>
                    @error('description')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Description (English) -->
                <div class="mb-4">
                    <label for="description_en" class="form-label text-success">
                        <i class="fas fa-align-left me-2"></i>Mô tả (Tiếng Anh)
                    </label>
                    <textarea class="form-control @error('description_en') is-invalid @enderror" 
                              id="description_en" 
                              name="description_en" 
                              rows="4"
                              placeholder="Enter detailed description in English...">{{ old('description_en', $product->description_en) }}</textarea>
                    @error('description_en')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <!-- Category -->
                <div class="mb-4">
                    <label for="category_id" class="form-label">
                        <i class="fas fa-list me-2 text-primary"></i>Danh mục <span class="text-danger">*</span>
                    </label>
                    <select class="form-select @error('category_id') is-invalid @enderror" name="category_id" id="category_id" required>
                        <option value="">-- Chọn danh mục --</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->id }}"
                                    data-type="{{ $cat->type }}"
                                    {{ (string) old('category_id', $product->category_id) === (string) $cat->id ? 'selected' : '' }}>
                                {{ $cat->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('category_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    @if($categories->isEmpty())
                        <div class="text-danger mt-2">Chưa có danh mục phù hợp. Vui lòng thêm danh mục trước.</div>
                    @else
                        <div class="category-hint">Danh mục quyết định loại sản phẩm (ebooks / tài liệu).</div>
                    @endif
                </div>

                <!-- Price and Stock -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <label for="price" class="form-label">
                            <i class="fas fa-dollar-sign me-2 text-primary"></i>Giá (VNĐ) <span class="text-danger">*</span>
                        </label>
                        <input type="number" 
                               class="form-control @error('price') is-invalid @enderror" 
                               id="price" 
                               name="price" 
                               value="{{ old('price', $product->price) }}"
                               min="0"
                               step="1000"
                               placeholder="0"
                               required>
                        @error('price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-4">
                        <label for="price_usd" class="form-label text-success">
                            <i class="fas fa-dollar-sign me-2"></i>Giá (USD)
                        </label>
                        <input type="number" 
                               class="form-control @error('price_usd') is-invalid @enderror" 
                               id="price_usd" 
                               name="price_usd" 
                               value="{{ old('price_usd', $product->price_usd) }}"
                               min="0"
                               step="0.01"
                               placeholder="Tự động tính nếu trống">
                        @error('price_usd')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-4">
                        <label for="stock" class="form-label">
                            <i class="fas fa-warehouse me-2 text-primary"></i>Tồn kho <span class="text-danger">*</span>
                        </label>
                        <input type="number" 
                               class="form-control @error('stock') is-invalid @enderror" 
                               id="stock" 
                               name="stock" 
                               value="{{ old('stock', $product->stock) }}"
                               min="0"
                               placeholder="0"
                               required>
                        @error('stock')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <input type="hidden" name="fake_sold" value="{{ old('fake_sold', $product->fake_sold ?? 0) }}">
                </div>

                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="form-check form-switch mb-2" style="padding-left: 2.5rem;">
                            <input class="form-check-input"
                                   type="checkbox"
                                   role="switch"
                                   id="is_on_sale"
                                   name="is_on_sale"
                                   value="1"
                                   {{ old('is_on_sale', (bool) $product->sale_price) ? 'checked' : '' }}
                                   style="width: 46px; height: 22px; cursor: pointer;">
                            <label class="form-check-label fw-bold" for="is_on_sale" style="margin-left: 8px; cursor: pointer;">
                                <i class="fas fa-tags text-danger me-1"></i>Bật giảm giá
                            </label>
                        </div>
                        <label for="sale_price" class="form-label">
                            <i class="fas fa-tags me-2 text-danger"></i>Giá giảm (VNĐ)
                        </label>
                        <input type="number" 
                               class="form-control @error('sale_price') is-invalid @enderror" 
                               id="sale_price" 
                               name="sale_price" 
                               value="{{ old('sale_price', $product->sale_price) }}"
                               min="0"
                               step="1000"
                               placeholder="Để trống nếu không giảm">
                        @error('sale_price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="text-muted">Giá giảm phải nhỏ hơn giá gốc</small>
                    </div>
                    <div class="col-md-6">
                        <div style="height: 30px;"></div> <!-- spacer -->
                        <label for="sale_price_usd" class="form-label text-success">
                            <i class="fas fa-tags me-2"></i>Giá giảm (USD)
                        </label>
                        <input type="number" 
                               class="form-control @error('sale_price_usd') is-invalid @enderror" 
                               id="sale_price_usd" 
                               name="sale_price_usd" 
                               value="{{ old('sale_price_usd', $product->sale_price_usd) }}"
                               min="0"
                               step="0.01"
                               placeholder="Tự động tính nếu trống">
                        @error('sale_price_usd')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input"
                               type="checkbox"
                               role="switch"
                               id="is_active"
                               name="is_active"
                               value="1"
                               {{ old('is_active', $product->is_active ?? true) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_active" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-eye text-success me-2"></i>Trạng thái hiển thị sản phẩm (Hiển thị / Ẩn)
                            <small class="text-muted d-block">Bật để hiển thị sản phẩm ra ngoài trang chủ & cửa hàng, tắt để ẩn</small>
                        </label>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input"
                               type="checkbox"
                               role="switch"
                               id="is_flash_sale"
                               name="is_flash_sale"
                               value="1"
                               {{ old('is_flash_sale', $product->is_flash_sale ?? false) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_flash_sale" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-bolt text-danger me-2"></i>Uu tien Flash Sale
                            <small class="text-muted d-block">Dua len 4 o giam gia tren trang chu</small>
                        </label>
                    </div>
                </div>

                <!-- Sản phẩm VPN -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input"
                               type="checkbox"
                               role="switch"
                               id="is_vpn"
                               name="is_vpn"
                               value="1"
                               {{ old('is_vpn', $product->is_vpn ?? false) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_vpn" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-network-wired text-info me-2"></i>Sản phẩm VPN
                            <small class="text-muted d-block">Hiển thị trong trang VPN</small>
                        </label>
                    </div>
                </div>
                <!-- Featured Product -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="is_featured" 
                               name="is_featured" 
                               value="1"
                               {{ old('is_featured', $product->is_featured) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_featured" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-star text-warning me-2"></i>Sản phẩm nổi bật
                            <small class="text-muted d-block">Hiển thị trên trang chủ - Hàng đầu tiên</small>
                        </label>
                    </div>
                </div>

                <!-- Exclusive Product -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="is_exclusive" 
                               name="is_exclusive" 
                               value="1"
                               {{ old('is_exclusive', $product->is_exclusive ?? false) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_exclusive" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-gem text-success me-2"></i>Sản phẩm độc quyền
                            <small class="text-muted d-block">Hiển thị trên trang chủ - Hàng thứ 2</small>
                        </label>
                    </div>
                </div>

                <!-- Banner Hero Product (4 ô trang chủ) -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="show_on_banner" 
                               name="show_on_banner" 
                               value="1"
                               {{ old('show_on_banner', $product->show_on_banner ?? false) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="show_on_banner" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-desktop text-primary me-2"></i>Nổi bật Banner Hero (4 ô đầu trang chủ)
                            <small class="text-muted d-block">Hiển thị trong 4 thẻ sản phẩm vừa cập nhật mới ở Banner chính</small>
                        </label>
                    </div>
                </div>

                <!-- Combo AI Giá Rẻ -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="is_combo_ai" 
                               name="is_combo_ai" 
                               value="1"
                               {{ old('is_combo_ai', $product->is_combo_ai ?? false) ? 'checked' : '' }}
                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_combo_ai" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-robot text-primary me-2"></i>Combo AI giá rẻ
                            <small class="text-muted d-block">Hiển thị ở trang chủ - mục Combo AI giá rẻ</small>
                        </label>
                    </div>
                </div>

                <!-- Delivery Type (Default: Digital) -->
                <input type="hidden" name="delivery_type" value="digital">

                <!-- Thời hạn sản phẩm -->
                <div class="mb-4">
                    <label class="form-label">
                        <i class="fas fa-clock me-2 text-primary"></i>Thời hạn sản phẩm
                    </label>
                    <div class="input-group">
                        <input type="number" 
                               class="form-control @error('duration_value') is-invalid @enderror" 
                               id="duration_value" 
                               name="duration_value" 
                               value="{{ old('duration_value', $product->duration_value) }}" 
                               min="1" 
                               placeholder="Ví dụ: 1, 7, 30...">
                        <select class="form-select @error('duration_type') is-invalid @enderror" 
                                id="duration_type" 
                                name="duration_type" 
                                style="max-width: 150px;">
                            <option value="">Không giới hạn</option>
                            <option value="days" {{ old('duration_type', $product->duration_type) == 'days' ? 'selected' : '' }}>Ngày</option>
                            <option value="months" {{ old('duration_type', $product->duration_type) == 'months' ? 'selected' : '' }}>Tháng</option>
                        </select>
                    </div>
                    <small class="text-muted">Nhập số lượng và chọn đơn vị (Ngày/Tháng). Ví dụ: 30 ngày, 3 tháng. Để trống hoặc chọn "Không giới hạn" nếu dùng vĩnh viễn.</small>
                    @error('duration_value')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                    @error('duration_type')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                </div>


                <!-- Image Upload -->
                <div class="mb-4">
                    <label for="image" class="form-label">
                        <i class="fas fa-image me-2 text-primary"></i>Hình ảnh sản phẩm
                    </label>
                    
                    @if($product->image)
                        <div class="mb-3">
                            <label class="form-label">Hình ảnh hiện tại:</label><br>
                            <img src="{{ $product->image }}" alt="{{ $product->name }}" id="currentImage" class="image-preview">
                        </div>
                    @endif
                    
                    <input type="file" 
                           class="form-control @error('image') is-invalid @enderror" 
                           id="image" 
                           name="image"
                           accept="image/*"
                           onchange="previewImage(event)">
                    <small class="text-muted">Chọn file ảnh mới (JPEG, PNG, JPG, GIF - tối đa 2MB). Ảnh sẽ tự động crop về 500x334 pixels. Để trống nếu không muốn thay đổi.</small>
                    @error('image')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                    
                    <!-- New Image Preview -->
                    <div id="imagePreview" class="mt-3" style="display: none;">
                        <div class="card" style="max-width: 300px;">
                            <div class="card-body p-2">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small class="text-muted">Ảnh mới (Preview):</small>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="removeImage()">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <img id="preview" src="" alt="Preview" class="img-fluid rounded" style="width: 100%; height: auto;">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- File Upload Section for Ebooks -->
                <div id="fileUploadSection" class="mb-4" style="display: none;">
                    <label class="form-label">
                        <i class="fas fa-file-upload me-2"></i>File tải về
                    </label>
                    
                    @if($product->file_path)
                        <div class="mb-3">
                            <label class="form-label">File hiện tại:</label><br>
                            <div class="alert alert-info">
                                <i class="fas fa-file-{{ $product->file_type }} me-2"></i>
                                <strong>{{ basename($product->file_path) }}</strong>
                                <span class="badge bg-primary ms-2">{{ $product->formatted_file_size }}</span>
                            </div>
                        </div>
                    @endif
                    
                    <input type="file" 
                           class="form-control @error('file') is-invalid @enderror" 
                           id="file" 
                           name="file"
                           accept=".pdf,.doc,.docx,.txt,.zip,.rar"
                           onchange="previewFile(event)">
                    <small class="text-muted">Chọn file PDF, DOC, DOCX, TXT, ZIP, hoặc RAR (tối đa 50MB). Để trống nếu không muốn thay đổi.</small>
                    @error('file')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                    
                    <!-- File Preview -->
                    <div id="filePreview" class="mt-3" style="display: none;">
                        <div class="alert alert-success">
                            <strong>File mới:</strong> <span id="fileName"></span>
                            <span class="badge bg-dark ms-2" id="fileSize"></span>
                        </div>
                    </div>
                </div>

                <!-- Technical Specifications -->
                <div class="mb-4">
                    <label class="form-label">
                        <i class="fas fa-cogs me-2 text-primary"></i>Thông Số Kỹ Thuật
                    </label>
                    <div id="specRows">
                        @php
                            if (old('spec_keys') !== null) {
                                $oldKeys = old('spec_keys', []);
                                $oldValues = old('spec_values', []);
                                $currentSpecs = [];
                                foreach ($oldKeys as $oldIndex => $oldKey) {
                                    $currentSpecs[$oldKey] = $oldValues[$oldIndex] ?? '';
                                }
                            } else {
                                $currentSpecs = $product->specs ?? [];
                            }
                            $currentSpecs = count(array_filter($currentSpecs ?? [])) > 0 ? $currentSpecs : ['' => ''];
                        @endphp
                        @foreach($currentSpecs as $specKey => $specValue)
                            <div class="d-flex align-items-center gap-2 mb-2 spec-row-input">
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_keys[]" value="{{ $specKey }}" placeholder="Tên thông số (ví dụ: RAM, CPU, Bảo hành...)">
                                </div>
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_values[]" value="{{ is_array($specValue) ? implode(', ', $specValue) : $specValue }}" placeholder="Giá trị (ví dụ: 16GB, M3, 12 tháng...)">
                                </div>
                                <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRow(this)" title="Xóa dòng này">
                                    <i class="fas fa-trash-alt"></i> <span>Xóa</span>
                                </button>
                            </div>
                        @endforeach
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm mt-2 rounded-pill px-3" onclick="addSpecRow()">
                        <i class="fas fa-plus me-1"></i>Thêm thông số
                    </button>
                </div>

                <!-- Technical Specifications (English) -->
                <div class="mb-4">
                    <label class="form-label text-success">
                        <i class="fas fa-cogs me-2"></i>Thông Số Kỹ Thuật (Tiếng Anh)
                    </label>
                    <div id="specRowsEn">
                        @php
                            if (old('spec_keys_en') !== null) {
                                $oldKeysEn = old('spec_keys_en', []);
                                $oldValuesEn = old('spec_values_en', []);
                                $currentSpecsEn = [];
                                foreach ($oldKeysEn as $oldIndex => $oldKey) {
                                    $currentSpecsEn[$oldKey] = $oldValuesEn[$oldIndex] ?? '';
                                }
                            } else {
                                $currentSpecsEn = $product->specs_en ?? [];
                            }
                            $currentSpecsEn = count(array_filter($currentSpecsEn ?? [])) > 0 ? $currentSpecsEn : ['' => ''];
                        @endphp
                        @foreach($currentSpecsEn as $specKey => $specValue)
                            <div class="d-flex align-items-center gap-2 mb-2 spec-row-input-en">
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_keys_en[]" value="{{ $specKey }}" placeholder="Spec name (e.g. RAM, CPU...)">
                                </div>
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_values_en[]" value="{{ is_array($specValue) ? implode(', ', $specValue) : $specValue }}" placeholder="Value (e.g. 16GB, M3...)">
                                </div>
                                <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRowEn(this)" title="Xóa dòng này">
                                    <i class="fas fa-trash-alt"></i> <span>Xóa</span>
                                </button>
                            </div>
                        @endforeach
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm mt-2 rounded-pill px-3" onclick="addSpecRowEn()">
                        <i class="fas fa-plus me-1"></i>Thêm thông số (EN)
                    </button>
                </div>

                <!-- Product Features -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="form-label mb-0">
                            <i class="fas fa-star me-2 text-warning"></i>Tính Năng
                        </label>
                        <a href="{{ route('admin.features') }}" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                            <i class="fas fa-plus me-1"></i>Tạo tính năng
                        </a>
                    </div>
                    @if(isset($features) && $features->count() > 0)
                        @php
                            $selectedFeatures = old('features', $product->features->pluck('id')->toArray());
                        @endphp
                        <div class="row g-2">
                            @foreach($features as $feature)
                                <div class="col-md-6">
                                    <div class="form-check border rounded-3 p-3 h-100" style="padding-left: 2.5rem !important;">
                                        <input class="form-check-input" type="checkbox" name="features[]" value="{{ $feature->id }}" id="feature_{{ $feature->id }}" {{ in_array($feature->id, $selectedFeatures) ? 'checked' : '' }}>
                                        <label class="form-check-label" for="feature_{{ $feature->id }}">
                                            <i class="{{ $feature->icon }} me-2" style="color: {{ $feature->color }}"></i>
                                            <strong>{{ $feature->name }}</strong>
                                            @if($feature->description)
                                                <small class="text-muted d-block">{{ $feature->description }}</small>
                                            @endif
                                        </label>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <div class="alert alert-info mb-0 d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-info-circle me-2"></i>Chưa có tính năng nào cho loại sản phẩm này.
                            </div>
                            <a href="{{ route('admin.features') }}" target="_blank" class="btn btn-sm btn-primary rounded-pill px-3 text-white">
                                <i class="fas fa-plus me-1"></i>Tạo tính năng ngay
                            </a>
                        </div>
                    @endif
                </div>

                <!-- Submit Buttons -->
                <div class="d-flex gap-3 justify-content-end mt-5">
                    <a href="{{ route('admin.products') }}" class="btn btn-outline-secondary rounded-pill px-4">
                        <i class="fas fa-times me-2"></i>Hủy
                    </a>
                    <button type="submit" class="btn btn-submit">
                        <i class="fas fa-save me-2"></i>Cập nhật sản phẩm
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    AOS.init({ duration: 800, once: true });

    document.addEventListener('DOMContentLoaded', function() {
        const categorySelect = document.getElementById('category_id');
        const fileUploadSection = document.getElementById('fileUploadSection');

        function syncFileSection() {
            const selected = categorySelect.options[categorySelect.selectedIndex];
            const type = selected ? selected.dataset.type : null;
            if (type === 'ebooks') {
                fileUploadSection.style.display = 'block';
            } else {
                fileUploadSection.style.display = 'none';
            }
        }

        categorySelect.addEventListener('change', syncFileSection);
        syncFileSection();
    });

    function previewImage(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('preview').src = e.target.result;
                document.getElementById('imagePreview').style.display = 'block';
                // Hide current image when new one is selected
                const currentImg = document.getElementById('currentImage');
                if (currentImg) {
                    currentImg.style.opacity = '0.5';
                }
            }
            reader.readAsDataURL(file);
        }
    }

    function removeImage() {
        document.getElementById('image').value = '';
        document.getElementById('imagePreview').style.display = 'none';
        document.getElementById('preview').src = '';
        // Restore current image opacity
        const currentImg = document.getElementById('currentImage');
        if (currentImg) {
            currentImg.style.opacity = '1';
        }
    }

    function previewFile(event) {
        const file = event.target.files[0];
        if (file) {
            document.getElementById('fileName').textContent = file.name;
            document.getElementById('fileSize').textContent = formatFileSize(file.size);
            document.getElementById('filePreview').style.display = 'block';
        }
    }

    function formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' bytes';
        else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        else return (bytes / 1048576).toFixed(1) + ' MB';
    }

    function addSpecRow() {
        const wrapper = document.getElementById('specRows');
        const row = document.createElement('div');
        row.className = 'd-flex align-items-center gap-2 mb-2 spec-row-input';
        row.innerHTML = `
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_keys[]" placeholder="Tên thông số (ví dụ: RAM, CPU, Bảo hành...)">
            </div>
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_values[]" placeholder="Giá trị (ví dụ: 16GB, M3, 12 tháng...)">
            </div>
            <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRow(this)" title="Xóa dòng này">
                <i class="fas fa-trash-alt"></i> <span>Xóa</span>
            </button>
        `;
        wrapper.appendChild(row);
    }

    function removeSpecRow(button) {
        const row = button.closest('.spec-row-input');
        if (row) row.remove();
    }

    function addSpecRowEn() {
        const wrapper = document.getElementById('specRowsEn');
        const row = document.createElement('div');
        row.className = 'd-flex align-items-center gap-2 mb-2 spec-row-input-en';
        row.innerHTML = `
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_keys_en[]" placeholder="Spec name (e.g. RAM, CPU...)">
            </div>
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_values_en[]" placeholder="Value (e.g. 16GB, M3...)">
            </div>
            <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRowEn(this)" title="Xóa dòng này">
                <i class="fas fa-trash-alt"></i> <span>Xóa</span>
            </button>
        `;
        wrapper.appendChild(row);
    }

    function removeSpecRowEn(button) {
        const row = button.closest('.spec-row-input-en');
        if (row) row.remove();
    }

    // Toggle discount validation & auto-switch
    const salePriceInput = document.getElementById('sale_price');
    const isOnSaleToggle = document.getElementById('is_on_sale');

    if (salePriceInput && isOnSaleToggle) {
        salePriceInput.addEventListener('input', function() {
            const val = parseFloat(this.value);
            if (val > 0) {
                isOnSaleToggle.checked = true;
                hideSaleError();
            }
        });

        isOnSaleToggle.addEventListener('change', function() {
            if (!this.checked) {
                const val = parseFloat(salePriceInput.value);
                if (val > 0) {
                    showSaleError('Bạn đang nhập giá giảm, vui lòng bật công tắc "Bật giảm giá" hoặc xóa giá giảm!');
                }
            } else {
                hideSaleError();
            }
        });

        const formElem = document.querySelector('form');
        if (formElem) {
            formElem.addEventListener('submit', function(e) {
                const val = parseFloat(salePriceInput.value);
                if (val > 0 && !isOnSaleToggle.checked) {
                    e.preventDefault();
                    showSaleError('Bạn đã nhập giá giảm, bắt buộc phải gạt công tắc "Bật giảm giá"!');
                    salePriceInput.focus();
                    return false;
                }
            });
        }
    }

    function showSaleError(msg) {
        let errBox = document.getElementById('sale_price_custom_error');
        if (!errBox && salePriceInput) {
            errBox = document.createElement('div');
            errBox.id = 'sale_price_custom_error';
            errBox.className = 'text-danger mt-1 fw-bold';
            errBox.style.fontSize = '12.5px';
            salePriceInput.parentNode.appendChild(errBox);
        }
        if (errBox) {
            errBox.innerHTML = '<i class="fas fa-exclamation-triangle me-1"></i>' + msg;
            salePriceInput.classList.add('is-invalid');
        }
    }

    function hideSaleError() {
        const errBox = document.getElementById('sale_price_custom_error');
        if (errBox) errBox.remove();
        if (salePriceInput) salePriceInput.classList.remove('is-invalid');
    }
</script>
@endpush
