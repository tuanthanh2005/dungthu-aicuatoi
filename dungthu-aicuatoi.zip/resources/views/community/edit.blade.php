@extends('layouts.app')

@section('title', __('Chỉnh Sửa Bài Viết'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
@endpush

@section('content')
<div class="container py-2" style="margin-top: 50px; max-width: 900px;">
    <h2 class="fw-bold mb-4">{{ __('Chỉnh sửa bài viết') }}</h2>

    <form method="POST" action="{{ route('community.update', $post) }}">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label class="form-label fw-bold">{{ __('Tiêu đề') }}</label>
            <input type="text" name="title" class="form-control" value="{{ old('title', $post->title) }}" required>
            @error('title')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">{{ __('Nội dung') }}</label>
            <textarea id="community-editor" name="content" rows="10" class="form-control">{{ old('content', html_entity_decode($post->content, ENT_QUOTES, 'UTF-8')) }}</textarea>
            @error('content')<small class="text-danger">{{ $message }}</small>@enderror
        </div>

        <div class="d-flex gap-2">
            <a href="{{ route('community.show', $post) }}" class="btn btn-light">{{ __('Hủy') }}</a>
            <button type="submit" class="btn btn-primary">{{ __('Lưu') }}</button>
        </div>
    </form>
</div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js"></script>
    <script>
        tinymce.init({
            selector: '#community-editor',
            height: 500,
            menubar: true,
            convert_urls: false,
            relative_urls: false,
            remove_script_host: false,
            document_base_url: '{{ rtrim(config('app.url'), '/') }}/',
            plugins: [
                'advlist', 'autolink', 'lists', 'link', 'image', 'charmap',
                'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
                'insertdatetime', 'media', 'table', 'help', 'wordcount'
            ],
            toolbar: 'undo redo | blocks | bold italic forecolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | table | link image | code fullscreen | help',
            content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif; font-size: 16px; line-height: 1.6; }',
            branding: false,
            images_upload_handler: function (blobInfo) {
                return new Promise(function (resolve, reject) {
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '{{ route('community.images.upload') }}');
                    xhr.setRequestHeader('X-CSRF-TOKEN', '{{ csrf_token() }}');
                    xhr.onload = function () {
                        if (xhr.status < 200 || xhr.status >= 300) {
                            reject('Upload failed: ' + xhr.status);
                            return;
                        }
                        try {
                            var json = JSON.parse(xhr.responseText);
                            if (!json.location) {
                                reject('Invalid response');
                                return;
                            }
                            resolve(json.location);
                        } catch (e) {
                            reject('Invalid JSON response');
                        }
                    };
                    xhr.onerror = function () {
                        reject('Upload failed');
                    };

                    var formData = new FormData();
                    formData.append('file', blobInfo.blob(), blobInfo.filename());
                    xhr.send(formData);
                });
            }
        });

        document.querySelector('form').addEventListener('submit', function (e) {
            tinymce.triggerSave();
            const content = tinymce.get('community-editor').getContent();
            if (!content || content.trim() === '') {
                e.preventDefault();
                alert(@json(__('Vui lòng nhập nội dung bài viết!')));
                tinymce.get('community-editor').focus();
                return false;
            }
        });
    </script>
@endpush
