<?php
    if (!function_exists('maskRealCustomerNameModal')) {
        function maskRealCustomerNameModal($name) {
            $name = trim($name);
            if ($name === '' || strtolower($name) === 'guest') {
                return 'Khách hàng';
            }
            $parts = preg_split('/\s+/u', $name) ?: [];
            $parts = array_values(array_filter($parts, fn ($p) => $p !== ''));
            
            if (count($parts) === 0) return 'Khách hàng';
            
            $lastName = $parts[0];
            $firstName = $parts[count($parts) - 1];
            
            if (count($parts) === 1) {
                return mb_substr($lastName, 0, 1) . '***';
            }
            
            return $lastName . ' ' . mb_substr($firstName, 0, 1) . '***';
        }
    }

    // Lấy 2 đơn hàng mới nhất thực tế từ CSDL hệ thống
    $realOrders = \App\Models\Order::query()
        ->with(['orderItems.product'])
        ->whereNotIn('status', ['cancelled'])
        ->latest()
        ->take(2)
        ->get();

    $displayItems = [];

    foreach ($realOrders as $order) {
        $firstItem = $order->orderItems->first();
        $product = $firstItem?->product;
        if ($product && ($product->is_active ?? true)) {
            $displayItems[] = [
                'product_name' => $product->name,
                'price' => $firstItem->price ?? ($product->sale_price ?: $product->price),
                'buyer' => maskRealCustomerNameModal($order->customer_name),
                'img_src' => $product->image ? (str_starts_with($product->image, 'http') ? $product->image : asset('storage/' . $product->image)) : asset('images/default-product.png'),
            ];
        }
    }

    // Nếu CSDL chưa có đủ 2 đơn hàng -> Bổ sung từ Sản phẩm CSDL
    if (count($displayItems) < 2) {
        $needed = 2 - count($displayItems);
        $fallbackProducts = \App\Models\Product::query()
            ->where('is_active', true)
            ->inRandomOrder()
            ->take($needed)
            ->get();

        $fallbackBuyers = ['Nguyễn V***', 'Trần T***', 'Lê M***', 'Phạm H***'];
        foreach ($fallbackProducts as $idx => $prod) {
            $displayItems[] = [
                'product_name' => $prod->name,
                'price' => $prod->sale_price ?: $prod->price,
                'buyer' => $fallbackBuyers[$idx % count($fallbackBuyers)],
                'img_src' => $prod->image ? (str_starts_with($prod->image, 'http') ? $prod->image : asset('storage/' . $prod->image)) : asset('images/default-product.png'),
            ];
        }
    }
?>

<!-- Modal 2 Sản Phẩm Vừa Được Mua Gần Đây -->
<div class="modal fade" id="recentOrdersWelcomeModal" tabindex="-1" aria-labelledby="recentOrdersWelcomeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 480px;">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden; background: #ffffff;">
            
            <div class="modal-header border-0 text-white px-4 py-3 position-relative d-flex align-items-center justify-content-between" 
                 style="background: linear-gradient(135deg, #8b5cf6 0%, #c084fc 100%);">
                <div>
                    <h5 class="modal-title fw-bold d-flex align-items-center gap-2 mb-1" id="recentOrdersWelcomeModalLabel" style="font-size: 17px;">
                        <i class="fa-solid fa-fire text-warning"></i>
                        <?php echo e(__('GIAO DỊCH VỪA HOÀN THÀNH')); ?>

                    </h5>
                    <div class="d-flex align-items-center gap-1 text-white-50" style="font-size: 11px;">
                        <span style="width: 7px; height: 7px; background-color: #22c55e; border-radius: 50%; display: inline-block; animation: pulseDotLive 1.5s infinite;"></span>
                        <span class="text-white fw-medium"><?php echo e(__('Hệ thống bàn giao tự động 24/7 - Từ 8h sáng đến 00h Tối')); ?></span>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-white close-recent-modal-btn" data-bs-dismiss="modal" aria-label="Close" style="opacity: 0.9; filter: invert(1) grayscale(1) brightness(2);"></button>
            </div>

            
            <div class="modal-body p-3 p-sm-4" style="background-color: #f8f9fa;">
                <p class="text-muted small mb-3 text-center" style="font-size: 12.5px;">
                    <i class="fa-solid fa-circle-check text-success me-1"></i><?php echo e(__('Các đơn hàng vừa được xử lý và kích hoạt thành công cho khách hàng:')); ?>

                </p>

                <div class="d-flex flex-column gap-3">
                    <?php $__currentLoopData = $displayItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $buyer = $item['buyer'];
                            $price = $item['price'];
                            $imgSrc = $item['img_src'];
                            $productName = $item['product_name'];
                        ?>
                        <div class="p-3 bg-white rounded-3 shadow-sm border border-light text-start">
                            <div class="d-flex align-items-start gap-3">
                                <!-- Thumbnail -->
                                <img src="<?php echo e($imgSrc); ?>" 
                                     alt="<?php echo e($productName); ?>" 
                                     style="width: 52px; height: 52px; object-fit: cover; border-radius: 10px; border: 1px solid #f1f5f9; flex-shrink: 0;">
                                
                                <!-- Details -->
                                <div class="flex-grow-1 min-w-0">
                                    <div class="d-flex align-items-start justify-content-between gap-2 mb-1">
                                        <h6 class="fw-bold text-dark mb-0" style="font-size: 13px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" title="<?php echo e($productName); ?>">
                                            <?php echo e($productName); ?>

                                        </h6>
                                        <span class="fw-bold text-danger flex-shrink-0 ms-1" style="font-size: 13.5px;">
                                            <?php echo e(number_format($price, 0, ',', '.')); ?>đ
                                        </span>
                                    </div>

                                    <div class="d-flex align-items-center justify-content-between gap-2 mt-2">
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 py-1 px-2" style="font-size: 10.5px; font-weight: 600;">
                                            <i class="fa-solid fa-bolt me-1"></i><?php echo e(__('Đã giao tự động')); ?>

                                        </span>
                                        <span class="text-muted" style="font-size: 11px; font-weight: 500;">
                                            <i class="fa-solid fa-user me-1 text-secondary"></i><?php echo e($buyer); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div class="modal-footer border-0 p-3 bg-white justify-content-between">
                <button type="button" class="btn btn-sm btn-light border text-muted px-3 close-recent-modal-btn" data-bs-dismiss="modal" style="border-radius: 20px; font-size: 12px;">
                    <i class="fa-solid fa-xmark me-1"></i><?php echo e(__('Đóng (Tắt 1h)')); ?>

                </button>
                <a href="<?php echo e(route('shop')); ?>" class="btn btn-sm text-white px-4 fw-bold shadow-sm shop-now-modal-btn" style="background: linear-gradient(135deg, #8b5cf6 0%, #c084fc 100%); border-radius: 20px; font-size: 12.5px;">
                    <i class="fa-solid fa-cart-shopping me-1"></i><?php echo e(__('Mua sắm ngay')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<script>
    window.showRecentOrdersModal = function() {
        const modalEl = document.getElementById('recentOrdersWelcomeModal');
        if (!modalEl) return;

        const STORAGE_KEY = 'recent_orders_modal_closed_until';
        const closedUntil = localStorage.getItem(STORAGE_KEY);
        const now = Date.now();

        // Nếu chưa đóng hoặc đã hết thời hạn 1 tiếng -> Hiển thị Modal giao dịch
        if (!closedUntil || now >= parseInt(closedUntil, 10)) {
            const bsModal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
            bsModal.show();
        }
    };

    document.addEventListener('DOMContentLoaded', function() {
        const modalEl = document.getElementById('recentOrdersWelcomeModal');
        if (!modalEl) return;

        const STORAGE_KEY = 'recent_orders_modal_closed_until';

        // Khi người dùng nhấn nút Đóng, X, hoặc Mua sắm ngay -> Lưu mốc thời gian ẩn 1 tiếng (3,600,000 ms)
        const actionElements = modalEl.querySelectorAll('.close-recent-modal-btn, .shop-now-modal-btn');
        actionElements.forEach(el => {
            el.addEventListener('click', function() {
                const oneHourLater = Date.now() + 3600000;
                localStorage.setItem(STORAGE_KEY, oneHourLater.toString());
            });
        });

        // Nếu người dùng đóng Modal bằng cách click backdrop hoặc phím ESC
        modalEl.addEventListener('hidden.bs.modal', function () {
            const oneHourLater = Date.now() + 3600000;
            localStorage.setItem(STORAGE_KEY, oneHourLater.toString());
        });
    });
</script>

<?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/partials/recent-orders-modal.blade.php ENDPATH**/ ?>