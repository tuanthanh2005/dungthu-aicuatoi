<?php if($paginator->hasPages()): ?>
<?php
    $current   = $paginator->currentPage();
    $last      = $paginator->lastPage();

    // Build the set of page numbers to always show:
    // always: 1, last, current, current-1, current+1
    $window = collect(range(max(1, $current - 1), min($last, $current + 1)));
    $always = $window->merge([1, $last])->unique()->sort()->values();

    // Build final list with '...' gaps
    $pages = collect();
    $prev  = null;
    foreach ($always as $p) {
        if ($prev !== null && $p - $prev > 1) {
            $pages->push('...');
        }
        $pages->push($p);
        $prev = $p;
    }

    // Get URL map from $elements
    $urlMap = [];
    foreach ($elements as $element) {
        if (is_array($element)) {
            foreach ($element as $page => $url) {
                $urlMap[$page] = $url;
            }
        }
    }
?>
    <nav>
        <ul class="pagination">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true">
                    <span class="page-link" aria-hidden="true">&lsaquo;</span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="Previous">&lsaquo;</a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($p === '...'): ?>
                    <li class="page-item disabled" aria-disabled="true"><span class="page-link">&hellip;</span></li>
                <?php elseif($p == $current): ?>
                    <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($p); ?></span></li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($urlMap[$p] ?? $paginator->url($p)); ?>"><?php echo e($p); ?></a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="Next">&rsaquo;</a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true">
                    <span class="page-link" aria-hidden="true">&rsaquo;</span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/vendor/pagination/bootstrap-5.blade.php ENDPATH**/ ?>