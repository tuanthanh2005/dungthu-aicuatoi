<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> — AI Của Tôi</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/AI Của Tôi.png')); ?>">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- AOS Library -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">

    <!-- Admin CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="admin-body">

<!-- ========================
     Sidebar
     ======================== -->
<aside class="admin-sidebar" id="adminSidebar">

    <!-- Logo -->
    <a href="<?php echo e(auth()->user()->role === 'blog_editor' ? route('admin.blogs') : route('admin.dashboard')); ?>" class="sidebar-logo d-flex align-items-center gap-2">
        <img src="<?php echo e(asset('images/aicuatoi-logo.png')); ?>" alt="AICuaToi Logo" 
             style="width: 36px; height: 36px; object-fit: contain; flex-shrink: 0; filter: drop-shadow(0 2px 8px rgba(139, 92, 246, 0.4));">
        <span class="sidebar-logo-text">AICuaToi Admin</span>
    </a>

    <!-- Navigation -->
    <nav class="sidebar-nav">

        <?php if(auth()->user()->role === 'blog_editor'): ?>
        <div class="sidebar-section-label">Nội dung</div>
        <a href="<?php echo e(route('admin.blogs')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.blogs*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-blog"></i></span>
            <span class="nav-text">Blog</span>
        </a>
        <?php else: ?>

        <!-- Tổng quan -->
        <div class="sidebar-section-label">Tổng quan</div>
        <a href="<?php echo e(route('admin.dashboard')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-th-large"></i></span>
            <span class="nav-text">Dashboard</span>
        </a>

        <div class="sidebar-divider"></div>

        <!-- Sản phẩm -->
        <div class="sidebar-section-label">Sản phẩm</div>
        <a href="<?php echo e(route('admin.products')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.products*') && !request('flash_sale') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-box"></i></span>
            <span class="nav-text">Sản phẩm</span>
        </a>
        <a href="<?php echo e(route('admin.categories')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.categories*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-layer-group"></i></span>
            <span class="nav-text">Danh mục</span>
        </a>
        <a href="<?php echo e(route('admin.features')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.features*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-star"></i></span>
            <span class="nav-text">Tính năng SP</span>
        </a>
        <a href="<?php echo e(route('admin.products', ['flash_sale' => 1])); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.products*') && request('flash_sale') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-bolt"></i></span>
            <span class="nav-text">Flash Sale</span>
        </a>

        <div class="sidebar-divider"></div>

        <!-- Đơn hàng & Giao dịch -->
        <div class="sidebar-section-label">Đơn hàng & Giao dịch</div>
        <a href="<?php echo e(route('admin.orders')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.orders*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-shopping-cart"></i></span>
            <span class="nav-text">Đơn hàng</span>
            <span class="nav-badge" id="sidebarOrderBadge" style="display: none;">0</span>
        </a>
        <a href="<?php echo e(route('admin.customer-durations')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.customer-durations*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-user-clock"></i></span>
            <span class="nav-text">Thời hạn khách</span>
        </a>

        <div class="sidebar-divider"></div>

        <!-- Người dùng -->
        <div class="sidebar-section-label">Người dùng</div>
        <a href="<?php echo e(route('admin.users')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.users*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-users"></i></span>
            <span class="nav-text">Danh sách User</span>
        </a>

        <div class="sidebar-divider"></div>

        <!-- Nội dung -->
        <div class="sidebar-section-label">Nội dung</div>
        <a href="<?php echo e(route('admin.blogs')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.blogs*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-blog"></i></span>
            <span class="nav-text">Blog</span>
        </a>
        <a href="<?php echo e(route('admin.blog-topics')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.blog-topics*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-tags"></i></span>
            <span class="nav-text">Chủ đề Blog</span>
        </a>

        <div class="sidebar-divider"></div>

        <!-- Hệ thống -->
        <div class="sidebar-section-label">Hệ thống</div>
        <a href="<?php echo e(route('admin.chat.index')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.chat*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-comments"></i></span>
            <span class="nav-text">Chat</span>
            <span class="nav-badge" id="sidebarChatBadge" style="display: none;">0</span>
        </a>

        <?php if(auth()->user()->role === 'sieusuperadmin'): ?>
        <a href="<?php echo e(route('admin.menu-settings')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.menu-settings*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-sliders-h"></i></span>
            <span class="nav-text">Menu Settings</span>
        </a>
        <a href="<?php echo e(route('admin.system-notifications')); ?>"
           class="sidebar-nav-item <?php echo e(request()->routeIs('admin.system-notifications*') ? 'active' : ''); ?>">
            <span class="nav-icon"><i class="fas fa-bullhorn"></i></span>
            <span class="nav-text">Thông báo HT</span>
        </a>
        <?php endif; ?>

        <?php endif; ?> 

    </nav>

    <!-- Sidebar Footer -->
    <?php if(auth()->user()->role !== 'blog_editor'): ?>
    <div class="sidebar-footer">
        <a href="<?php echo e(url('/')); ?>" class="sidebar-nav-item" target="_blank">
            <span class="nav-icon"><i class="fas fa-external-link-alt"></i></span>
            <span class="nav-text">Xem trang web</span>
        </a>
    </div>
    <?php endif; ?>

</aside>

<!-- Sidebar Overlay (Mobile) -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- ========================
     Topbar
     ======================== -->
<header class="admin-topbar" id="adminTopbar">

    <!-- Toggle Button -->
    <button class="sidebar-toggle-btn" id="sidebarToggle" title="Thu/mở sidebar">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Breadcrumb / Page Title -->
    <div class="topbar-breadcrumb">
        <span><i class="fas fa-home" style="font-size:12px"></i></span>
        <span class="separator">/</span>
        <span>Admin</span>
        <?php if (! empty(trim($__env->yieldContent('breadcrumb')))): ?>
            <span class="separator">/</span>
            <?php echo $__env->yieldContent('breadcrumb'); ?>
        <?php endif; ?>
        <span class="separator">&nbsp;—&nbsp;</span>
        <span class="page-title"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></span>
    </div>

    <!-- Actions -->
    <div class="topbar-actions">
        <!-- View Site -->
        <a href="<?php echo e(url('/')); ?>" class="topbar-icon-btn d-none d-sm-flex" target="_blank" title="Xem trang web">
            <i class="fas fa-globe"></i>
        </a>

        <!-- User -->
        <div class="topbar-user">
            <div class="topbar-user-avatar">
                <?php echo e(strtoupper(substr(auth()->user()->name ?? 'A', 0, 1))); ?>

            </div>
            <span class="topbar-user-name"><?php echo e(auth()->user()->name ?? 'Admin'); ?></span>
        </div>
    </div>

</header>

<!-- ========================
     Main Content
     ======================== -->
<main class="admin-main" id="adminMain">

    <!-- Flash Messages -->
    <?php if(session('success')): ?>
        <div class="admin-alert success mb-4">
            <i class="fas fa-check-circle fa-lg"></i>
            <span><?php echo e(session('success')); ?></span>
            <button type="button" class="ms-auto btn-close btn-close-sm" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="admin-alert error mb-4">
            <i class="fas fa-exclamation-circle fa-lg"></i>
            <span><?php echo e(session('error')); ?></span>
            <button type="button" class="ms-auto btn-close btn-close-sm" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="admin-alert info mb-4">
            <i class="fas fa-info-circle fa-lg"></i>
            <span><?php echo e(session('info')); ?></span>
            <button type="button" class="ms-auto btn-close btn-close-sm" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="admin-alert warning mb-4">
            <i class="fas fa-exclamation-triangle fa-lg"></i>
            <span><?php echo e(session('warning')); ?></span>
            <button type="button" class="ms-auto btn-close btn-close-sm" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

</main>

<!-- ========================
     Scripts
     ======================== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>

<script>
// ========================
// Sidebar Toggle Logic
// ========================
const sidebar = document.getElementById('adminSidebar');
const topbar = document.getElementById('adminTopbar');
const mainContent = document.getElementById('adminMain');
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebarOverlay = document.getElementById('sidebarOverlay');

function isMobile() {
    return window.innerWidth < 992;
}

// Load saved state
const sidebarCollapsed = localStorage.getItem('adminSidebarCollapsed') === 'true';
if (!isMobile() && sidebarCollapsed) {
    sidebar.classList.add('collapsed');
    topbar.classList.add('collapsed');
    mainContent.classList.add('collapsed');
}

sidebarToggle.addEventListener('click', function() {
    if (isMobile()) {
        // Mobile: show/hide overlay
        sidebar.classList.toggle('mobile-open');
        sidebarOverlay.classList.toggle('active');
    } else {
        // Desktop: collapse/expand
        const isCollapsed = sidebar.classList.toggle('collapsed');
        topbar.classList.toggle('collapsed', isCollapsed);
        mainContent.classList.toggle('collapsed', isCollapsed);
        localStorage.setItem('adminSidebarCollapsed', isCollapsed);
    }
});

sidebarOverlay.addEventListener('click', function() {
    sidebar.classList.remove('mobile-open');
    sidebarOverlay.classList.remove('active');
});

// Resize handler
window.addEventListener('resize', function() {
    if (!isMobile()) {
        sidebar.classList.remove('mobile-open');
        sidebarOverlay.classList.remove('active');
    }
});

// ========================
// Flash message auto-dismiss
// ========================
document.querySelectorAll('.admin-alert').forEach(function(el) {
    const closeBtn = el.querySelector('.btn-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            el.style.opacity = '0';
            el.style.transform = 'translateY(-8px)';
            el.style.transition = 'all 0.3s ease';
            setTimeout(() => el.remove(), 300);
        });
    }
    // Auto-dismiss after 5s
    setTimeout(function() {
        if (el.parentNode) {
            el.style.opacity = '0';
            el.style.transition = 'opacity 0.5s ease';
            setTimeout(() => el.remove(), 500);
        }
    }, 5000);
});
</script>

<style>
    /* Prevent double-tap to zoom on admin devices */
    html, body {
        touch-action: manipulation;
    }
</style>

<script>
    // Fetch and update admin sidebar badges/counters
    document.addEventListener('DOMContentLoaded', function() {
        function updateAdminSidebarCounters() {
            fetch('<?php echo e(route('admin.sidebar-counters')); ?>')
                .then(res => {
                    if (!res.ok) throw new Error('Network response was not ok');
                    return res.json();
                })
                .then(data => {
                    function updateBadge(id, count) {
                        const badge = document.getElementById(id);
                        if (badge) {
                            if (count > 0) {
                                badge.textContent = count;
                                badge.style.display = 'inline-block';
                            } else {
                                badge.style.display = 'none';
                            }
                        }
                    }
                    
                    updateBadge('sidebarChatBadge', data.unread_chats);
                    updateBadge('sidebarOrderBadge', data.pending_orders);
                })
                .catch(err => console.error('Error fetching sidebar counters:', err));
        }
        
        updateAdminSidebarCounters();
        setInterval(updateAdminSidebarCounters, 15000);
    });
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>




<?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/layouts/admin.blade.php ENDPATH**/ ?>