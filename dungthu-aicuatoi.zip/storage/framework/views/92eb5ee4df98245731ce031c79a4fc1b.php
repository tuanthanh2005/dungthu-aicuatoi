<?php $__env->startSection('title', 'Thêm Sản phẩm - Admin'); ?>

<?php $__env->startSection('page_title', 'Thêm sản phẩm'); ?>

<?php $__env->startPush('styles'); ?>
<style>

    .admin-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        max-width: 800px;
        margin: 0 auto;
    }

    .form-label {
        font-weight: 600;
        color: #2d3748;
        margin-bottom: 8px;
    }

    .form-control, .form-select {
        border-radius: 10px;
        border: 2px solid #e2e8f0;
        padding: 12px 16px;
        transition: all 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
    }

    .category-hint {
        font-size: 0.9rem;
        color: #6b7280;
        margin-top: 6px;
    }

    .btn-submit {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        padding: 14px 40px;
        border-radius: 25px;
        color: white;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-submit:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(102,126,234,0.4);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">
        <div class="admin-card" data-aos="fade-up">
            <div class="mb-4">
                <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-outline-secondary rounded-pill mb-3">
                    <i class="fas fa-arrow-left me-2"></i>Quay lại
                </a>
                <h3 class="fw-bold mb-0">
                    <i class="fas fa-plus-circle text-primary me-3"></i>Thêm Sản phẩm Mới
                </h3>
            </div>

            <!-- Success Message -->
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Error Messages -->
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <h6 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Có lỗi xảy ra!</h6>
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Product Name -->
                <div class="mb-4">
                    <label for="name" class="form-label">
                        <i class="fas fa-tag me-2 text-primary"></i>Tên sản phẩm <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="name" 
                           name="name" 
                           value="<?php echo e(old('name')); ?>"
                           placeholder="Nhập tên sản phẩm..."
                           required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Product Name (English) -->
                <div class="mb-4">
                    <label for="name_en" class="form-label text-success">
                        <i class="fas fa-tag me-2"></i>Tên sản phẩm (Tiếng Anh)
                    </label>
                    <input type="text" 
                           class="form-control <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="name_en" 
                           name="name_en" 
                           value="<?php echo e(old('name_en')); ?>"
                           placeholder="Enter product name in English...">
                    <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <label for="description" class="form-label">
                        <i class="fas fa-align-left me-2 text-primary"></i>Mô tả <span class="text-danger">*</span>
                    </label>
                    <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              id="description" 
                              name="description" 
                              rows="4"
                              placeholder="Nhập mô tả chi tiết sản phẩm..."
                              required><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Description (English) -->
                <div class="mb-4">
                    <label for="description_en" class="form-label text-success">
                        <i class="fas fa-align-left me-2"></i>Mô tả (Tiếng Anh)
                    </label>
                    <textarea class="form-control <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              id="description_en" 
                              name="description_en" 
                              rows="4"
                              placeholder="Enter detailed description in English..."><?php echo e(old('description_en')); ?></textarea>
                    <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Category -->
                <div class="mb-4">
                    <label for="category_id" class="form-label">
                        <i class="fas fa-list me-2 text-primary"></i>Danh mục <span class="text-danger">*</span>
                    </label>
                    <select class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="category_id" id="category_id" required>
                        <option value="">-- Chọn danh mục --</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"
                                    data-type="<?php echo e($cat->type); ?>"
                                    <?php echo e(old('category_id') == $cat->id ? 'selected' : ''); ?>>
                                <?php echo e($cat->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($categories->isEmpty()): ?>
                        <div class="text-danger mt-2">Chưa có danh mục phù hợp. Vui lòng thêm danh mục trước.</div>
                    <?php else: ?>
                        <div class="category-hint">Danh mục quyết định loại sản phẩm (ebooks / tài liệu).</div>
                    <?php endif; ?>
                </div>

                <!-- Price and Stock -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <label for="price" class="form-label">
                            <i class="fas fa-dollar-sign me-2 text-primary"></i>Giá (VNĐ) <span class="text-danger">*</span>
                        </label>
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="price" 
                               name="price" 
                               value="<?php echo e(old('price')); ?>"
                               min="0"
                               step="1000"
                               placeholder="0"
                               required>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <label for="price_usd" class="form-label text-success">
                            <i class="fas fa-dollar-sign me-2"></i>Giá (USD)
                        </label>
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['price_usd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="price_usd" 
                               name="price_usd" 
                               value="<?php echo e(old('price_usd')); ?>"
                               min="0"
                               step="0.01"
                               placeholder="Tự động tính nếu trống">
                        <?php $__errorArgs = ['price_usd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4">
                        <label for="stock" class="form-label">
                            <i class="fas fa-warehouse me-2 text-primary"></i>Tồn kho <span class="text-danger">*</span>
                        </label>
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="stock" 
                               name="stock" 
                               value="<?php echo e(old('stock')); ?>"
                               min="0"
                               placeholder="0"
                               required>
                        <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="hidden" name="fake_sold" value="<?php echo e(old('fake_sold', 0)); ?>">
                </div>

                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="form-check form-switch mb-2" style="padding-left: 2.5rem;">
                            <input class="form-check-input"
                                   type="checkbox"
                                   role="switch"
                                   id="is_on_sale"
                                   name="is_on_sale"
                                   value="1"
                                   <?php echo e(old('is_on_sale') ? 'checked' : ''); ?>

                                   style="width: 46px; height: 22px; cursor: pointer;">
                            <label class="form-check-label fw-bold" for="is_on_sale" style="margin-left: 8px; cursor: pointer;">
                                <i class="fas fa-tags text-danger me-1"></i>Bật giảm giá
                            </label>
                        </div>
                        <label for="sale_price" class="form-label">
                            <i class="fas fa-tags me-2 text-danger"></i>Giá giảm (VNĐ)
                        </label>
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="sale_price" 
                               name="sale_price" 
                               value="<?php echo e(old('sale_price')); ?>"
                               min="0"
                               step="1000"
                               placeholder="Để trống nếu không giảm">
                        <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <small class="text-muted">Giá giảm phải nhỏ hơn giá gốc</small>
                    </div>
                    <div class="col-md-6">
                        <div style="height: 30px;"></div> <!-- spacer -->
                        <label for="sale_price_usd" class="form-label text-success">
                            <i class="fas fa-tags me-2"></i>Giá giảm (USD)
                        </label>
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['sale_price_usd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="sale_price_usd" 
                               name="sale_price_usd" 
                               value="<?php echo e(old('sale_price_usd')); ?>"
                               min="0"
                               step="0.01"
                               placeholder="Tự động tính nếu trống">
                        <?php $__errorArgs = ['sale_price_usd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input"
                               type="checkbox"
                               role="switch"
                               id="is_active"
                               name="is_active"
                               value="1"
                               <?php echo e(old('is_active', '1') === '1' ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_active" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-eye text-success me-2"></i>Trạng thái hiển thị sản phẩm (Hiển thị / Ẩn)
                            <small class="text-muted d-block">Bật để hiển thị sản phẩm ra ngoài trang chủ & cửa hàng, tắt để ẩn</small>
                        </label>
                    </div>
                </div>

                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input"
                               type="checkbox"
                               role="switch"
                               id="is_flash_sale"
                               name="is_flash_sale"
                               value="1"
                               <?php echo e(old('is_flash_sale') ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_flash_sale" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-bolt text-danger me-2"></i>Uu tien Flash Sale
                            <small class="text-muted d-block">Dua len 4 o giam gia tren trang chu</small>
                        </label>
                    </div>
                </div>

                <!-- Sản phẩm VPN -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input"
                               type="checkbox"
                               role="switch"
                               id="is_vpn"
                               name="is_vpn"
                               value="1"
                               <?php echo e(old('is_vpn') ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_vpn" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-network-wired text-info me-2"></i>VPN
                             <small class="text-muted d-block">Hiển thị trong trang VPN</small>
                        </label>
                    </div>
                </div>
                <!-- Featured Product -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="is_featured" 
                               name="is_featured" 
                               value="1"
                               <?php echo e(old('is_featured') ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_featured" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-star text-warning me-2"></i>Sản phẩm nổi bật
                            <small class="text-muted d-block">Hiển thị trên trang chủ - Hàng đầu tiên</small>
                        </label>
                    </div>
                </div>

                <!-- Exclusive Product -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="is_exclusive" 
                               name="is_exclusive" 
                               value="1"
                               <?php echo e(old('is_exclusive') ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_exclusive" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-gem text-success me-2"></i>Sản phẩm độc quyền
                            <small class="text-muted d-block">Hiển thị trên trang chủ - Hàng thứ 2</small>
                        </label>
                    </div>
                </div>

                <!-- Banner Hero Product (4 ô trang chủ) -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="show_on_banner" 
                               name="show_on_banner" 
                               value="1"
                               <?php echo e(old('show_on_banner') ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="show_on_banner" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-desktop text-primary me-2"></i>Nổi bật Banner Hero (4 ô đầu trang chủ)
                            <small class="text-muted d-block">Hiển thị trong 4 thẻ sản phẩm vừa cập nhật mới ở Banner chính</small>
                        </label>
                    </div>
                </div>

                <!-- Combo AI Giá Rẻ -->
                <div class="mb-4">
                    <div class="form-check form-switch" style="padding-left: 2.5rem;">
                        <input class="form-check-input" 
                               type="checkbox" 
                               role="switch" 
                               id="is_combo_ai" 
                               name="is_combo_ai" 
                               value="1"
                               <?php echo e(old('is_combo_ai') ? 'checked' : ''); ?>

                               style="width: 50px; height: 25px; cursor: pointer;">
                        <label class="form-check-label fw-bold" for="is_combo_ai" style="margin-left: 10px; cursor: pointer;">
                            <i class="fas fa-robot text-primary me-2"></i>Combo AI giá rẻ
                            <small class="text-muted d-block">Hiển thị ở trang chủ - mục Combo AI giá rẻ</small>
                        </label>
                    </div>
                </div>

                <!-- Delivery Type (Default: Digital) -->
                <input type="hidden" name="delivery_type" value="digital">

                <!-- Thời hạn sản phẩm -->
                <div class="mb-4">
                    <label class="form-label">
                        <i class="fas fa-clock me-2 text-primary"></i>Thời hạn sản phẩm
                    </label>
                    <div class="input-group">
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['duration_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="duration_value" 
                               name="duration_value" 
                               value="<?php echo e(old('duration_value')); ?>" 
                               min="1" 
                               placeholder="Ví dụ: 1, 7, 30...">
                        <select class="form-select <?php $__errorArgs = ['duration_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="duration_type" 
                                name="duration_type" 
                                style="max-width: 150px;">
                            <option value="">Không giới hạn</option>
                            <option value="days" <?php echo e(old('duration_type') == 'days' ? 'selected' : ''); ?>>Ngày</option>
                            <option value="months" <?php echo e(old('duration_type') == 'months' ? 'selected' : ''); ?>>Tháng</option>
                        </select>
                    </div>
                    <small class="text-muted">Nhập số lượng và chọn đơn vị (Ngày/Tháng). Ví dụ: 30 ngày, 3 tháng. Để trống hoặc chọn "Không giới hạn" nếu dùng vĩnh viễn.</small>
                    <?php $__errorArgs = ['duration_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['duration_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <!-- Image Upload -->
                <div class="mb-4">
                    <label for="image" class="form-label">
                        <i class="fas fa-image me-2 text-primary"></i>Hình ảnh sản phẩm
                    </label>
                    <input type="file" 
                           class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="image" 
                           name="image"
                           accept="image/*"
                           onchange="previewImage(event)">
                    <small class="text-muted">Chọn file ảnh (JPEG, PNG, JPG, GIF - tối đa 2MB). Ảnh sẽ tự động crop về 500x334 pixels.</small>
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <!-- Image Preview -->
                    <div id="imagePreview" class="mt-3" style="display: none;">
                        <div class="card" style="max-width: 300px;">
                            <div class="card-body p-2">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small class="text-muted">Preview:</small>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="removeImage()">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <img id="preview" src="" alt="Preview" class="img-fluid rounded" style="width: 100%; height: auto;">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- File Upload (for ebooks category) -->
                <div class="mb-4" id="fileUploadSection" style="display: none;">
                    <label for="file" class="form-label">
                        <i class="fas fa-file-upload me-2 text-primary"></i>File tải về (PDF, DOCX, TXT, ZIP)
                    </label>
                    <input type="file" 
                           class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="file" 
                           name="file"
                           accept=".pdf,.doc,.docx,.txt,.zip,.rar"
                           onchange="previewFile(event)">
                    <small class="text-muted">File tài liệu để khách hàng tải về sau khi mua (tối đa 50MB)</small>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <!-- File Preview -->
                    <div id="filePreview" class="mt-3" style="display: none;">
                        <div class="alert alert-info">
                            <i class="fas fa-file me-2"></i>
                            <strong>File đã chọn:</strong> <span id="fileName"></span>
                            <span class="badge bg-primary ms-2" id="fileSize"></span>
                        </div>
                    </div>
                </div>

                <!-- Technical Specifications -->
                <div class="mb-4">
                    <label class="form-label">
                        <i class="fas fa-cogs me-2 text-primary"></i>Thông Số Kỹ Thuật
                    </label>
                    <div id="specRows">
                        <?php
                            $oldSpecKeys = old('spec_keys', ['']);
                            $oldSpecValues = old('spec_values', ['']);
                        ?>
                        <?php $__currentLoopData = $oldSpecKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $oldSpecKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center gap-2 mb-2 spec-row-input">
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_keys[]" value="<?php echo e($oldSpecKey); ?>" placeholder="Tên thông số (ví dụ: RAM, CPU, Bảo hành...)">
                                </div>
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_values[]" value="<?php echo e($oldSpecValues[$index] ?? ''); ?>" placeholder="Giá trị (ví dụ: 16GB, M3, 12 tháng...)">
                                </div>
                                <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRow(this)" title="Xóa dòng này">
                                    <i class="fas fa-trash-alt"></i> <span>Xóa</span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm mt-2 rounded-pill px-3" onclick="addSpecRow()">
                        <i class="fas fa-plus me-1"></i>Thêm thông số
                    </button>
                </div>

                <!-- Technical Specifications (English) -->
                <div class="mb-4">
                    <label class="form-label text-success">
                        <i class="fas fa-cogs me-2"></i>Thông Số Kỹ Thuật (Tiếng Anh)
                    </label>
                    <div id="specRowsEn">
                        <?php
                            $oldSpecKeysEn = old('spec_keys_en', ['']);
                            $oldSpecValuesEn = old('spec_values_en', ['']);
                        ?>
                        <?php $__currentLoopData = $oldSpecKeysEn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $oldSpecKeyEn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex align-items-center gap-2 mb-2 spec-row-input-en">
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_keys_en[]" value="<?php echo e($oldSpecKeyEn); ?>" placeholder="Spec name (e.g. RAM, CPU...)">
                                </div>
                                <div style="flex: 1;">
                                    <input type="text" class="form-control" name="spec_values_en[]" value="<?php echo e($oldSpecValuesEn[$index] ?? ''); ?>" placeholder="Value (e.g. 16GB, M3...)">
                                </div>
                                <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRowEn(this)" title="Xóa dòng này">
                                    <i class="fas fa-trash-alt"></i> <span>Xóa</span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm mt-2 rounded-pill px-3" onclick="addSpecRowEn()">
                        <i class="fas fa-plus me-1"></i>Thêm thông số (EN)
                    </button>
                </div>

                <!-- Product Features -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="form-label mb-0">
                            <i class="fas fa-star me-2 text-warning"></i>Tính Năng
                        </label>
                        <a href="<?php echo e(route('admin.features')); ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                            <i class="fas fa-plus me-1"></i>Tạo tính năng
                        </a>
                    </div>
                    <?php if(isset($features) && $features->count() > 0): ?>
                        <div class="row g-2">
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <div class="form-check border rounded-3 p-3 h-100" style="padding-left: 2.5rem !important;">
                                        <input class="form-check-input" type="checkbox" name="features[]" value="<?php echo e($feature->id); ?>" id="feature_<?php echo e($feature->id); ?>" <?php echo e(in_array($feature->id, old('features', [])) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="feature_<?php echo e($feature->id); ?>">
                                            <i class="<?php echo e($feature->icon); ?> me-2" style="color: <?php echo e($feature->color); ?>"></i>
                                            <strong><?php echo e($feature->name); ?></strong>
                                            <?php if($feature->description): ?>
                                                <small class="text-muted d-block"><?php echo e($feature->description); ?></small>
                                            <?php endif; ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info mb-0 d-flex justify-content-between align-items-center">
                            <div>
                                <i class="fas fa-info-circle me-2"></i>Chưa có tính năng nào cho loại sản phẩm này.
                            </div>
                            <a href="<?php echo e(route('admin.features')); ?>" target="_blank" class="btn btn-sm btn-primary rounded-pill px-3 text-white">
                                <i class="fas fa-plus me-1"></i>Tạo tính năng ngay
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Submit Buttons -->
                <div class="d-flex gap-3 justify-content-end mt-5">
                    <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-outline-secondary rounded-pill px-4">
                        <i class="fas fa-times me-2"></i>Hủy
                    </a>
                    <button type="submit" class="btn btn-submit">
                        <i class="fas fa-save me-2"></i>Lưu sản phẩm
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    AOS.init({ duration: 800, once: true });

    const categorySelect = document.getElementById('category_id');
    function syncFileSection() {
        const selected = categorySelect.options[categorySelect.selectedIndex];
        const type = selected ? selected.dataset.type : null;
        const fileSection = document.getElementById('fileUploadSection');
        if (type === 'ebooks') {
            fileSection.style.display = 'block';
        } else {
            fileSection.style.display = 'none';
            document.getElementById('file').value = '';
            document.getElementById('filePreview').style.display = 'none';
        }
    }

    categorySelect.addEventListener('change', syncFileSection);
    syncFileSection();

    function previewImage(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('preview').src = e.target.result;
                document.getElementById('imagePreview').style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    }

    function removeImage() {
        document.getElementById('image').value = '';
        document.getElementById('imagePreview').style.display = 'none';
        document.getElementById('preview').src = '';
    }

    function previewFile(event) {
        const file = event.target.files[0];
        if (file) {
            document.getElementById('fileName').textContent = file.name;
            document.getElementById('fileSize').textContent = formatFileSize(file.size);
            document.getElementById('filePreview').style.display = 'block';
        }
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

    function addSpecRow() {
        const wrapper = document.getElementById('specRows');
        const row = document.createElement('div');
        row.className = 'd-flex align-items-center gap-2 mb-2 spec-row-input';
        row.innerHTML = `
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_keys[]" placeholder="Tên thông số (ví dụ: RAM, CPU, Bảo hành...)">
            </div>
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_values[]" placeholder="Giá trị (ví dụ: 16GB, M3, 12 tháng...)">
            </div>
            <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRow(this)" title="Xóa dòng này">
                <i class="fas fa-trash-alt"></i> <span>Xóa</span>
            </button>
        `;
        wrapper.appendChild(row);
    }

    function removeSpecRow(button) {
        const row = button.closest('.spec-row-input');
        if (row) row.remove();
    }

    function addSpecRowEn() {
        const wrapper = document.getElementById('specRowsEn');
        const row = document.createElement('div');
        row.className = 'd-flex align-items-center gap-2 mb-2 spec-row-input-en';
        row.innerHTML = `
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_keys_en[]" placeholder="Spec name (e.g. RAM, CPU...)">
            </div>
            <div style="flex: 1;">
                <input type="text" class="form-control" name="spec_values_en[]" placeholder="Value (e.g. 16GB, M3...)">
            </div>
            <button type="button" class="btn btn-danger d-flex align-items-center justify-content-center gap-1 shadow-sm" style="height: 48px; min-width: 85px; border-radius: 10px; flex-shrink: 0;" onclick="removeSpecRowEn(this)" title="Xóa dòng này">
                <i class="fas fa-trash-alt"></i> <span>Xóa</span>
            </button>
        `;
        wrapper.appendChild(row);
    }

    function removeSpecRowEn(button) {
        const row = button.closest('.spec-row-input-en');
        if (row) row.remove();
    }

    // Toggle discount validation & auto-switch
    const salePriceInput = document.getElementById('sale_price');
    const isOnSaleToggle = document.getElementById('is_on_sale');

    if (salePriceInput && isOnSaleToggle) {
        salePriceInput.addEventListener('input', function() {
            const val = parseFloat(this.value);
            if (val > 0) {
                isOnSaleToggle.checked = true;
                hideSaleError();
            }
        });

        isOnSaleToggle.addEventListener('change', function() {
            if (!this.checked) {
                const val = parseFloat(salePriceInput.value);
                if (val > 0) {
                    showSaleError('Bạn đang nhập giá giảm, vui lòng bật công tắc "Bật giảm giá" hoặc xóa giá giảm!');
                }
            } else {
                hideSaleError();
            }
        });

        const formElem = document.querySelector('form');
        if (formElem) {
            formElem.addEventListener('submit', function(e) {
                const val = parseFloat(salePriceInput.value);
                if (val > 0 && !isOnSaleToggle.checked) {
                    e.preventDefault();
                    showSaleError('Bạn đã nhập giá giảm, bắt buộc phải gạt công tắc "Bật giảm giá"!');
                    salePriceInput.focus();
                    return false;
                }
            });
        }
    }

    function showSaleError(msg) {
        let errBox = document.getElementById('sale_price_custom_error');
        if (!errBox && salePriceInput) {
            errBox = document.createElement('div');
            errBox.id = 'sale_price_custom_error';
            errBox.className = 'text-danger mt-1 fw-bold';
            errBox.style.fontSize = '12.5px';
            salePriceInput.parentNode.appendChild(errBox);
        }
        if (errBox) {
            errBox.innerHTML = '<i class="fas fa-exclamation-triangle me-1"></i>' + msg;
            salePriceInput.classList.add('is-invalid');
        }
    }

    function hideSaleError() {
        const errBox = document.getElementById('sale_price_custom_error');
        if (errBox) errBox.remove();
        if (salePriceInput) salePriceInput.classList.remove('is-invalid');
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/admin/products/create.blade.php ENDPATH**/ ?>