<?php
    $menuHome        = \App\Models\SiteSetting::getValue('menu_home', '1') === '1';
    $menuShop        = \App\Models\SiteSetting::getValue('menu_shop', '1') === '1';
    $menuBlog        = \App\Models\SiteSetting::getValue('menu_blog', '1') === '1';
    $menuCart        = \App\Models\SiteSetting::getValue('menu_cart', '1') === '1';
    $menuWebdesign   = \App\Models\SiteSetting::getValue('menu_webdesign', '1') === '1';
    $menuBuff        = \App\Models\SiteSetting::getValue('menu_buff', '1') === '1';
    $menuCommunity   = \App\Models\SiteSetting::getValue('menu_community', '1') === '1';
    $menuCardExchange = \App\Models\SiteSetting::getValue('menu_card_exchange', '1') === '1';
    $menuChat        = \App\Models\SiteSetting::getValue('menu_chat', '1') === '1';
    $menuMinigame    = \App\Models\SiteSetting::getValue('menu_minigame', '1') === '1';
    $menuZaloGroup   = \App\Models\SiteSetting::getValue('menu_zalo_group', '1') === '1';
?>

<nav class="navbar navbar-expand-xl navbar-techfeed sticky-top" id="mainNavbar">
    <div class="container-fluid px-3">
        
        <a class="navbar-brand d-flex align-items-center gap-2 me-0 me-sm-2" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/aicuatoi-logo.png')); ?>" alt="AICuaToi Logo" 
                 style="width: 38px; height: 38px; object-fit: contain; flex-shrink: 0; filter: drop-shadow(0 2px 8px rgba(139, 92, 246, 0.4));">
            <span style="font-weight: 800; font-size: 1.3rem; letter-spacing: -0.5px;">AICuaToi<span style="color: #a855f7; font-weight: 800;">.com</span></span>
        </a>

        
        <div class="mobile-live-online-float live-online-interactive-pill d-flex d-md-none align-items-center shadow-sm" 
             title="<?php echo e(__('Nhấn để xem chi tiết')); ?>"
             style="cursor: pointer; user-select: none;">
            <span class="live-dot-pulse" style="width: 6px; height: 6px; background-color: #dc2626; border-radius: 50%; display: inline-block; margin-right: 4px;"></span>
            <i class="fa-solid fa-eye me-1" style="color: #dc2626; font-size: 10px;"></i>
            <span class="online-count-val" style="font-size: 11px; font-weight: 800; color: #dc2626;">--</span>
            <span class="online-extra-text text-danger fw-bold" style="font-size: 10px;">người đang xem</span>
        </div>

        
        <div class="d-none d-xl-flex align-items-center gap-1 gap-xxl-2 mx-auto desktop-nav-links" style="font-size: 13.5px;">
            <?php if($menuHome): ?>
            <a href="<?php echo e(route('home')); ?>" class="nav-text-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                <i class="fa-solid fa-house me-1"></i><?php echo e(__('Trang chủ')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuShop): ?>
            <a href="<?php echo e(route('shop')); ?>" class="nav-text-link <?php echo e(request()->routeIs('shop') ? 'active' : ''); ?>">
                <i class="fa-solid fa-shop me-1"></i><?php echo e(__('Cửa hàng')); ?>

            </a>
            <?php endif; ?>
            <a href="<?php echo e(route('vpn.index')); ?>" class="nav-text-link <?php echo e(request()->routeIs('vpn.*') ? 'active' : ''); ?>" style="color: #00bcd4; font-weight: 700;">
                <i class="fa-solid fa-network-wired me-1"></i><?php echo e(__('VPN')); ?>

            </a>
            <?php if($menuBuff): ?>
            <a href="<?php echo e(route('buff.index')); ?>" class="nav-text-link <?php echo e(request()->routeIs('buff.*') ? 'active' : ''); ?>" style="color: #ff5e00; font-weight: 700;">
                <i class="fa-solid fa-rocket me-1"></i><?php echo e(__('Buff MXH')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuWebdesign): ?>
            <a href="<?php echo e(route('web-design')); ?>" class="nav-text-link <?php echo e(request()->routeIs('web-design') ? 'active' : ''); ?>">
                <i class="fa-solid fa-code me-1"></i><?php echo e(__('Thiết kế Web')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuCardExchange): ?>
            <a href="<?php echo e(route('card-exchange.index')); ?>" class="nav-text-link <?php echo e(request()->routeIs('card-exchange.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-credit-card me-1"></i><?php echo e(__('Đổi thẻ')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuBlog): ?>
            <a href="<?php echo e(route('blog.index')); ?>" class="nav-text-link <?php echo e(request()->routeIs('blog.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-newspaper me-1"></i><?php echo e(__('Blog')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuCommunity): ?>
            <a href="<?php echo e(route('community.index')); ?>" class="nav-text-link <?php echo e(request()->routeIs('community.*') ? 'active' : ''); ?>">
                <i class="fa-solid fa-users me-1"></i><?php echo e(__('Cộng đồng')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuMinigame): ?>
            <a href="<?php echo e(route('minigame.index')); ?>" class="nav-text-link <?php echo e(request()->routeIs('minigame.*') ? 'active' : ''); ?>" style="color: #e11d48; font-weight: 700;">
                <i class="fa-solid fa-gamepad me-1"></i><?php echo e(__('Mini Game')); ?>

            </a>
            <?php endif; ?>
            <?php if($menuZaloGroup): ?>
            <a href="<?php echo e(\App\Models\SiteSetting::getValue('zalo_group_link', 'https://zalo.me/g/ptarfhnomeuotiyk7cot')); ?>" target="_blank" class="nav-text-link fw-bold" style="color: #0068ff;">
                <i class="fa-solid fa-comment-dots me-1"></i><?php echo e(__('Nhóm Zalo')); ?>

            </a>
            <?php endif; ?>
            <a href="javascript:void(0)" class="nav-text-link" data-bs-toggle="modal" data-bs-target="#quickContactModal">
                <i class="fa-solid fa-headset me-1"></i><?php echo e(__('Liên hệ')); ?>

            </a>
            <a href="javascript:void(0)" class="btn btn-sm text-white fw-bold rounded-pill px-3 ms-2 me-2 shadow-sm d-inline-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#appDownloadModal" style="background: linear-gradient(135deg, #ff5e00 0%, #ff8e43 100%); font-size: 13px; flex-shrink: 0;">
                <i class="fa-solid fa-cloud-arrow-down"></i> <?php echo e(__('Tải App')); ?>

            </a>
        </div>

        
        <div class="dropdown d-none d-lg-block d-xl-none ms-auto me-2">
            <button class="nav-icon-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="<?php echo e(__('Mở menu')); ?>">
                <i class="fa-solid fa-bars"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-techfeed">
                <?php if($menuHome): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-house me-2 text-primary"></i><?php echo e(__('Trang chủ')); ?></a></li>
                <?php endif; ?>
                <?php if($menuShop): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('shop')); ?>"><i class="fa-solid fa-store me-2 text-primary"></i><?php echo e(__('Cửa hàng')); ?></a></li>
                <?php endif; ?>
                <li><a class="dropdown-item fw-bold" href="<?php echo e(route('vpn.index')); ?>" style="color: #00bcd4;"><i class="fa-solid fa-network-wired me-2"></i><?php echo e(__('VPN')); ?></a></li>
                <?php if($menuBuff): ?>
                    <li><a class="dropdown-item fw-bold" href="<?php echo e(route('buff.index')); ?>" style="color: #ff5e00;"><i class="fa-solid fa-rocket me-2"></i><?php echo e(__('Dịch Vụ MXH')); ?></a></li>
                <?php endif; ?>
                <?php if($menuWebdesign): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('web-design')); ?>"><i class="fa-solid fa-code me-2 text-primary"></i><?php echo e(__('Thiết Kế Website')); ?></a></li>
                <?php endif; ?>
                <?php if($menuCardExchange): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('card-exchange.index')); ?>"><i class="fa-solid fa-credit-card me-2 text-warning"></i><?php echo e(__('Đổi Thẻ Cào')); ?></a></li>
                <?php endif; ?>
                <?php if($menuBlog): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('blog.index')); ?>"><i class="fa-solid fa-newspaper me-2 text-primary"></i><?php echo e(__('Blog')); ?></a></li>
                <?php endif; ?>
                <?php if($menuCommunity): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('community.index')); ?>"><i class="fa-solid fa-users me-2 text-success"></i><?php echo e(__('Cộng đồng')); ?></a></li>
                <?php endif; ?>
                <?php if($menuMinigame): ?>
                    <li><a class="dropdown-item fw-bold" href="<?php echo e(route('minigame.index')); ?>" style="color: #e11d48;"><i class="fa-solid fa-gamepad me-2"></i><?php echo e(__('Mini Game')); ?></a></li>
                <?php endif; ?>
                <li><hr class="dropdown-divider"></li>
                <?php if($menuZaloGroup): ?>
                <li><a class="dropdown-item fw-bold" href="<?php echo e(\App\Models\SiteSetting::getValue('zalo_group_link', 'https://zalo.me/g/ptarfhnomeuotiyk7cot')); ?>" target="_blank" style="color: #0068ff;"><i class="fa-solid fa-users me-2"></i><?php echo e(__('Nhóm Zalo')); ?></a></li>
                <?php endif; ?>
                <li><a class="dropdown-item" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#quickContactModal"><i class="fa-solid fa-headset me-2 text-primary"></i><?php echo e(__('Liên hệ')); ?></a></li>
                <li><a class="dropdown-item fw-bold" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#appDownloadModal" style="color: #ff5e00;"><i class="fa-solid fa-cloud-arrow-down me-2"></i><?php echo e(__('Tải App')); ?></a></li>
            </ul>
        </div>

        
        <button class="nav-icon-btn d-none d-xl-flex ms-3 me-3" type="button" data-bs-toggle="modal" data-bs-target="#searchProductsModal" aria-label="<?php echo e(__('Tìm kiếm')); ?>">
            <i class="fa-solid fa-magnifying-glass"></i>
        </button>

        
        <div class="d-flex align-items-center gap-2 gap-sm-3">
            
            <div class="dropdown">
                <button class="nav-icon-btn d-flex align-items-center justify-content-center" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="<?php echo e(__('Ngôn ngữ')); ?>" style="width: 40px; height: 40px; border-radius: 50%; padding: 0;">
                    <?php if(app()->getLocale() === 'en'): ?>
                        <img src="https://flagcdn.com/w40/us.png" width="20" alt="US" style="border-radius: 2px; border: 1px solid rgba(0,0,0,0.15); display: inline-block;">
                    <?php else: ?>
                        <img src="https://flagcdn.com/w40/vn.png" width="20" alt="VN" style="border-radius: 2px; border: 1px solid rgba(0,0,0,0.15); display: inline-block;">
                    <?php endif; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-techfeed" style="min-width: 140px; border: none; border-radius: 12px;">
                    <li>
                        <a class="dropdown-item d-flex align-items-center gap-2 <?php echo e(app()->getLocale() === 'vi' ? 'active' : ''); ?>" href="<?php echo e(route('change-language', 'vi')); ?>" style="font-size: 13.5px;">
                            <img src="https://flagcdn.com/w40/vn.png" width="20" alt="VN" style="border-radius: 2px; border: 1px solid rgba(0,0,0,0.15);">
                            <?php echo e(__('Tiếng Việt')); ?>

                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item d-flex align-items-center gap-2 <?php echo e(app()->getLocale() === 'en' ? 'active' : ''); ?>" href="<?php echo e(route('change-language', 'en')); ?>" style="font-size: 13.5px;">
                            <img src="https://flagcdn.com/w40/us.png" width="20" alt="US" style="border-radius: 2px; border: 1px solid rgba(0,0,0,0.15);">
                            English
                        </a>
                    </li>
                </ul>
            </div>

            
            <?php if($menuCart): ?>
            <a href="<?php echo e(route('cart.index')); ?>" class="nav-icon-btn position-relative" aria-label="<?php echo e(__('Giỏ hàng')); ?>">
                <i class="fa-solid fa-cart-shopping"></i>
                <?php $cartCount = count(session('cart', [])); ?>
                <?php if($cartCount > 0): ?>
                    <span class="nav-badge"><?php echo e($cartCount); ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            
            <button class="nav-icon-btn d-xl-none" type="button" data-bs-toggle="collapse" data-bs-target="#mobileSearchBar" aria-label="<?php echo e(__('Tìm kiếm')); ?>">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>

            
            <?php if(auth()->guard()->check()): ?>
                <div class="dropdown">
                    <button class="user-avatar-btn" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="user-initial"><?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-techfeed">
                        <li class="px-3 py-2 border-bottom">
                            <div class="fw-bold text-sm"><?php echo e(Auth::user()->name); ?></div>
                            <div class="text-muted" style="font-size:0.78rem;"><?php echo e(Auth::user()->email); ?></div>
                        </li>
                        <?php if(in_array(Auth::user()->role, ['superadmin_1', 'sieusuperadmin', 'blog_editor'], true)): ?>
                            <li><a class="dropdown-item" href="/admin"><i class="fas fa-tachometer-alt me-2 text-primary"></i><?php echo e(__('Dashboard Admin')); ?></a></li>
                            <?php if(Auth::user()->role === 'sieusuperadmin'): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.menu-settings')); ?>"><i class="fas fa-sliders-h me-2 text-warning"></i><?php echo e(__('Quản lý Menu')); ?></a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin.proxies')); ?>"><i class="fas fa-network-wired me-2 text-info"></i><?php echo e(__('Quản lý Proxy')); ?></a></li>
                                
                                
                                <li>
                                    <a class="dropdown-item d-flex justify-content-between align-items-center" data-bs-toggle="collapse" href="#adminBuffCollapse" role="button" aria-expanded="false" aria-controls="adminBuffCollapse" onclick="event.stopPropagation();">
                                        <span><i class="fas fa-chart-line me-2" style="color:#8b5cf6;"></i><?php echo e(__('Quản lý Buff')); ?></span>
                                        <i class="fas fa-chevron-down ms-2" style="font-size: 0.75rem;"></i>
                                    </a>
                                    <div class="collapse px-2" id="adminBuffCollapse" onclick="event.stopPropagation();">
                                        <ul class="list-unstyled ps-3 bg-light rounded py-1 my-1">
                                            <li><a class="dropdown-item py-1" href="<?php echo e(route('admin.buff.dashboard')); ?>" style="font-size: 0.85rem;"><i class="fas fa-chart-line me-2" style="color:#8b5cf6;"></i><?php echo e(__('Buff Dashboard')); ?></a></li>
                                            <li><a class="dropdown-item py-1" href="<?php echo e(route('admin.buff.orders.index')); ?>" style="font-size: 0.85rem;"><i class="fas fa-list-alt me-2" style="color:#ec4899;"></i><?php echo e(__('Đơn Buff')); ?></a></li>
                                            <li><a class="dropdown-item py-1" href="<?php echo e(route('admin.buff.services.index')); ?>" style="font-size: 0.85rem;"><i class="fas fa-cogs me-2" style="color:#06b6d4;"></i><?php echo e(__('Dịch vụ Buff')); ?></a></li>
                                            <li><a class="dropdown-item py-1" href="<?php echo e(route('admin.buff.servers.index')); ?>" style="font-size: 0.85rem;"><i class="fas fa-server me-2" style="color:#10b981;"></i><?php echo e(__('Máy chủ Buff')); ?></a></li>
                                        </ul>
                                    </div>
                                </li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                        <?php endif; ?>
                        <?php if($menuHome): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-house me-2 text-primary"></i><?php echo e(__('Trang chủ')); ?></a></li>
                        <?php endif; ?>
                        <?php if($menuShop): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('shop')); ?>"><i class="fa-solid fa-store me-2 text-primary"></i><?php echo e(__('Cửa hàng')); ?></a></li>
                        <?php endif; ?>
                        <?php if($menuBlog): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('blog.index')); ?>"><i class="fa-solid fa-newspaper me-2 text-primary"></i><?php echo e(__('Blog')); ?></a></li>
                        <?php endif; ?>
                        <?php if(Auth::user()->role === 'sieusuperadmin'): ?>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item d-flex justify-content-between align-items-center" data-bs-toggle="collapse" href="#quickLinksCollapse" role="button" aria-expanded="false" aria-controls="quickLinksCollapse" onclick="event.stopPropagation();">
                                <span><i class="fas fa-link me-2 text-primary"></i><?php echo e(__('Dịch vụ & Tiện ích')); ?></span>
                                <i class="fas fa-chevron-down ms-2" style="font-size: 0.75rem;"></i>
                            </a>
                            <div class="collapse px-2" id="quickLinksCollapse" onclick="event.stopPropagation();">
                                <ul class="list-unstyled ps-3 bg-light rounded py-1 my-1">
                                    <li><a class="dropdown-item py-1" href="<?php echo e(route('buff.index')); ?>" style="color: #8b5cf6; font-size: 0.85rem;"><i class="fas fa-rocket me-2"></i><?php echo e(__('Buff Mạng XH')); ?></a></li>
                                    <li><a class="dropdown-item py-1" href="<?php echo e(route('web-design')); ?>" style="font-size: 0.85rem;"><i class="fa-solid fa-code me-2 text-primary"></i><?php echo e(__('Thiết Kế Website')); ?></a></li>
                                    <li><a class="dropdown-item py-1" href="<?php echo e(route('card-exchange.index')); ?>" style="font-size: 0.85rem;"><i class="fas fa-exchange-alt me-2 text-warning"></i><?php echo e(__('Đổi thẻ cào')); ?></a></li>
                                    <li><a class="dropdown-item py-1" href="<?php echo e(route('community.index')); ?>" style="font-size: 0.85rem;"><i class="fas fa-users me-2 text-success"></i><?php echo e(__('Cộng đồng')); ?></a></li>
                                </ul>
                            </div>
                        </li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <?php if($menuMinigame): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('minigame.index')); ?>"><i class="fas fa-gamepad me-2 text-danger"></i><?php echo e(__('Vòng xoay may mắn')); ?></a></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('user.account')); ?>"><i class="fas fa-user me-2"></i><?php echo e(__('Tài khoản')); ?></a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('user.orders')); ?>"><i class="fas fa-box me-2"></i><?php echo e(__('Đơn hàng')); ?></a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item text-danger"><i class="fas fa-sign-out-alt me-2"></i><?php echo e(__('Đăng xuất')); ?></button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="nav-icon-btn" title="<?php echo e(__('Đăng nhập')); ?>" aria-label="<?php echo e(__('Đăng nhập')); ?>">
                    <i class="fa-solid fa-right-to-bracket"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="collapse w-100" id="mobileSearchBar">
        <div class="px-3 pb-2">
            <form class="search-bar-inner w-100" action="<?php echo e(route('shop')); ?>" method="GET" style="border: 1.5px solid #ff5e00; background-color: #fff;">
                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                <input type="text" name="search" class="search-input" placeholder="<?php echo e(__('Tìm kiếm...')); ?>" value="<?php echo e(request('search')); ?>">
            </form>
        </div>
    </div>
</nav>


<nav class="mobile-bottom-nav d-lg-none">
    <?php if($menuHome): ?>
    <a href="<?php echo e(route('home')); ?>" class="mobile-nav-item <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
        <i class="fa-solid fa-house"></i>
        <span><?php echo e(__('Trang chủ')); ?></span>
    </a>
    <?php endif; ?>
    <?php if($menuShop): ?>
    <a href="<?php echo e(route('shop')); ?>" class="mobile-nav-item <?php echo e(request()->routeIs('shop') ? 'active' : ''); ?>">
        <i class="fa-solid fa-store"></i>
        <span><?php echo e(__('Cửa hàng')); ?></span>
    </a>
    <?php endif; ?>
    <a href="javascript:void(0)" class="mobile-nav-item" data-bs-toggle="modal" data-bs-target="#appDownloadModal">
        <i class="fa-solid fa-cloud-arrow-down" style="color: #ff5e00;"></i>
        <span style="color: #ff5e00; font-weight: bold;"><?php echo e(__('Tải App')); ?></span>
    </a>
    <a href="<?php echo e(\App\Helpers\SupportHelper::getZaloLink()); ?>" target="_blank" class="mobile-nav-item">
        <i class="fa-solid fa-headset"></i>
        <span><?php echo e(__('Hỗ trợ')); ?></span>
    </a>
    <?php if($menuCart): ?>
    <a href="<?php echo e(route('cart.index')); ?>" class="mobile-nav-item position-relative <?php echo e(request()->routeIs('cart.*') ? 'active' : ''); ?>">
        <i class="fa-solid fa-cart-shopping"></i>
        <?php if(isset($cartCount) && $cartCount > 0): ?>
            <span class="nav-badge"><?php echo e($cartCount); ?></span>
        <?php endif; ?>
        <span><?php echo e(__('Giỏ hàng')); ?></span>
    </a>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
    <?php if($menuChat): ?>
    <a href="<?php echo e(route('user.orders')); ?>" class="mobile-nav-item <?php echo e(request()->routeIs('user.orders') ? 'active' : ''); ?>">
        <i class="fa-solid fa-box"></i>
        <span><?php echo e(__('Đơn hàng')); ?></span>
    </a>
    <?php endif; ?>
    <?php endif; ?>
    <a href="<?php echo e(\App\Models\SiteSetting::getValue('zalo_group_link', 'https://zalo.me/g/ptarfhnomeuotiyk7cot')); ?>" target="_blank" class="mobile-nav-item">
        <i class="fa-solid fa-users" style="color: #0068ff;"></i>
        <span style="color: #0068ff; font-weight: bold;"><?php echo e(__('Nhóm')); ?></span>
    </a>
</nav>


<div class="modal fade" id="quickContactModal" tabindex="-1" aria-labelledby="quickContactModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 480px;">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden; background: #ffffff;">
            
            <div class="modal-header border-0 text-white px-4 py-3 position-relative d-flex align-items-center justify-content-between" style="background: linear-gradient(135deg, #ff5e00 0%, #ff8e43 100%);">
                <div>
                    <h5 class="modal-title fw-bold d-flex align-items-center gap-2 mb-0" id="quickContactModalLabel" style="font-size: 18px;">
                        <i class="fa-solid fa-headset"></i>
                        <?php echo e(__('Liên hệ & Nhắn tin nhanh')); ?>

                    </h5>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" style="opacity: 0.8; filter: invert(1) grayscale(1) brightness(2);"></button>
            </div>
            
            
            <div class="modal-body p-4" style="background-color: #f8f9fa;">
                <div class="d-flex flex-column gap-3">
                    
                    
                    <a href="<?php echo e(\App\Models\SiteSetting::getValue('zalo_group_link', 'https://zalo.me/g/ptarfhnomeuotiyk7cot')); ?>" 
                       target="_blank" 
                       class="d-flex align-items-center gap-3 p-3 text-decoration-none bg-white rounded-3 contact-modal-item"
                       style="border: 1px solid #e5e7eb; transition: all 0.2s ease;">
                        <div class="contact-modal-icon-wrap d-flex align-items-center justify-content-center" 
                             style="width: 48px; height: 48px; border-radius: 12px; background: #e6f0ff; color: #0068ff; min-width: 48px; font-size: 18px;">
                            <i class="fa-solid fa-users"></i>
                        </div>
                        <div class="flex-grow-1 text-start">
                            <h6 class="fw-bold mb-1" style="color: #1f2937; font-size: 14px;"><?php echo e(__('GROUP ZALO HỖ TRỢ')); ?></h6>
                            <p class="mb-0 text-muted" style="font-size: 12px;"><?php echo e(__('Tham gia nhóm hỗ trợ thành viên')); ?></p>
                        </div>
                        <div style="color: #9ca3af;"><i class="fa-solid fa-chevron-right"></i></div>
                    </a>

                    
                    <a href="<?php echo e(\App\Helpers\SupportHelper::getTelegramLink()); ?>"
                       target="_blank"
                       rel="noopener noreferrer"
                       class="d-flex align-items-center gap-3 p-3 text-decoration-none bg-white rounded-3 contact-modal-item"
                       style="border: 1px solid #e5e7eb; transition: all 0.2s ease;">
                        <div class="contact-modal-icon-wrap d-flex align-items-center justify-content-center"
                             style="width: 48px; height: 48px; border-radius: 12px; background: #e6f7ff; color: #0088cc; min-width: 48px; font-size: 18px;">
                            <i class="fa-brands fa-telegram-plane"></i>
                        </div>
                        <div class="flex-grow-1 text-start">
                            <h6 class="fw-bold mb-1" style="color: #1f2937; font-size: 14px;"><?php echo e(__('TELEGRAM ADMIN')); ?></h6>
                            <p class="mb-0 text-muted" style="font-size: 12px;"><?php echo e(__('Telegram liên hệ:')); ?> <?php echo e(\App\Helpers\SupportHelper::getTelegramUsername()); ?></p>
                        </div>
                        <div style="color: #9ca3af;"><i class="fa-solid fa-chevron-right"></i></div>
                    </a>

                    
                    <a href="<?php echo e(\App\Helpers\SupportHelper::getZaloLink()); ?>" 
                       target="_blank" 
                       class="d-flex align-items-center gap-3 p-3 text-decoration-none bg-white rounded-3 contact-modal-item"
                       style="border: 1px solid #e5e7eb; transition: all 0.2s ease;">
                        <div class="contact-modal-icon-wrap d-flex align-items-center justify-content-center" 
                             style="width: 48px; height: 48px; border-radius: 12px; background: #e8f8f5; color: #07be9e; min-width: 48px; font-size: 18px;">
                            <i class="fa-solid fa-comment-dots"></i>
                        </div>
                        <div class="flex-grow-1 text-start">
                            <h6 class="fw-bold mb-1" style="color: #1f2937; font-size: 14px;"><?php echo e(__('CHAT ZALO ADMIN')); ?></h6>
                            <p class="mb-0 text-muted" style="font-size: 12px;"><?php echo e(__('Zalo liên hệ:')); ?> <?php echo e(\App\Helpers\SupportHelper::getZaloNumber()); ?></p>
                        </div>
                        <div style="color: #9ca3af;"><i class="fa-solid fa-chevron-right"></i></div>
                    </a>

                </div>
            </div>
            
            
            <div class="modal-footer border-0 justify-content-center py-2" style="background-color: #f1f3f5;">
                <span class="text-muted" style="font-size: 11px; font-weight: 500;"><?php echo e(__('DungThu.com hân hạnh hỗ trợ!')); ?></span>
            </div>
        </div>
    </div>
</div>

<style>
    .contact-modal-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.05);
        border-color: rgba(255, 94, 0, 0.25) !important;
        background-color: #fafbfc !important;
    }
    .contact-modal-item:hover .contact-modal-icon-wrap {
        transform: scale(1.05);
    }
</style>


<div class="modal fade" id="searchProductsModal" tabindex="-1" aria-labelledby="searchProductsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 500px;">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden; background: #ffffff;">
            
            <div class="modal-header border-0 text-white px-4 py-3 position-relative d-flex align-items-center justify-content-between" style="background: linear-gradient(135deg, #ff5e00 0%, #ff8e43 100%);">
                <h5 class="modal-title fw-bold d-flex align-items-center gap-2 mb-0" id="searchProductsModalLabel" style="font-size: 17px;">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <?php echo e(__('Tìm kiếm sản phẩm')); ?>

                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" style="opacity: 0.8; filter: invert(1) grayscale(1) brightness(2);"></button>
            </div>
            
            
            <div class="modal-body p-4" style="background-color: #f8f9fa;">
                <form action="<?php echo e(route('shop')); ?>" method="GET">
                    <div class="input-group mb-3 shadow-sm" style="border-radius: 25px; overflow: hidden; border: 1.5px solid #ff5e00;">
                        <span class="input-group-text bg-white border-0 ps-3" style="color: #9ca3af;">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </span>
                        <input type="text" name="search" class="form-control border-0 py-2" 
                               placeholder="<?php echo e(__('Nhập tên sản phẩm để tìm...')); ?>" 
                               style="font-size: 14.5px; outline: none; box-shadow: none; background-color: #fff;" 
                               required 
                               id="searchModalInput">
                        <button class="btn btn-primary border-0 px-4 fw-bold" type="submit" style="background: linear-gradient(135deg, #ff5e00 0%, #ff8e43 100%);">
                            <?php echo e(__('Tìm kiếm')); ?>

                        </button>
                    </div>
                </form>
                
                
                <div class="ps-2 text-start">
                    <span class="text-muted" style="font-size: 12px; font-weight: 500;"><?php echo e(__('Gợi ý:')); ?></span>
                    <a href="<?php echo e(route('shop', ['search' => 'gpt'])); ?>" class="badge bg-white text-secondary text-decoration-none px-2 py-1.5 ms-1 border" style="font-size: 11px; border-radius: 12px;">gpt</a>
                    <a href="<?php echo e(route('shop', ['search' => 'gemini'])); ?>" class="badge bg-white text-secondary text-decoration-none px-2 py-1.5 ms-1 border" style="font-size: 11px; border-radius: 12px;">gemini</a>
                    <a href="<?php echo e(route('shop', ['search' => 'cursor'])); ?>" class="badge bg-white text-secondary text-decoration-none px-2 py-1.5 ms-1 border" style="font-size: 11px; border-radius: 12px;">cursor</a>
                    <a href="<?php echo e(route('shop', ['search' => 'antigravity'])); ?>" class="badge bg-white text-secondary text-decoration-none px-2 py-1.5 ms-1 border" style="font-size: 11px; border-radius: 12px;">antigravity</a>
                    <a href="<?php echo e(route('shop', ['search' => 'grok'])); ?>" class="badge bg-white text-secondary text-decoration-none px-2 py-1.5 ms-1 border" style="font-size: 11px; border-radius: 12px;">grok</a>
                    <a href="<?php echo e(route('shop', ['search' => 'capcut'])); ?>" class="badge bg-white text-secondary text-decoration-none px-2 py-1.5 ms-1 border" style="font-size: 11px; border-radius: 12px;">capcut</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    @keyframes pulseDotLive {
        0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(220, 38, 38, 0.7); }
        70% { transform: scale(1.1); box-shadow: 0 0 0 5px rgba(220, 38, 38, 0); }
        100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(220, 38, 38, 0); }
    }
    .live-dot-pulse {
        animation: pulseDotLive 1.5s infinite;
    }
    .mobile-live-online-float {
        position: fixed;
        bottom: 245px;
        right: 16px;
        z-index: 9999;
        padding: 4px 10px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.96);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(220, 38, 38, 0.3);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.12);
        pointer-events: auto;
        transition: all 0.35s ease;
    }
    /* Chế độ mặc định (Thu gọn): Ẩn chữ "người đang xem", chỉ hiện Icon Mắt + Số */
    .live-online-interactive-pill .online-extra-text {
        max-width: 0;
        opacity: 0;
        overflow: hidden;
        white-space: nowrap;
        display: inline-block;
        vertical-align: bottom;
        transition: max-width 0.35s ease, opacity 0.25s ease, margin 0.25s ease;
        margin-left: 0 !important;
    }
    /* Khi Click mở rộng: Hiện đầy đủ "X người đang xem" trong 3 giây */
    .live-online-interactive-pill.is-expanded .online-extra-text {
        max-width: 140px;
        opacity: 1;
        margin-left: 4px !important;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchModalEl = document.getElementById('searchProductsModal');
        if (searchModalEl) {
            searchModalEl.addEventListener('shown.bs.modal', function () {
                const searchInput = document.getElementById('searchModalInput');
                if (searchInput) {
                    searchInput.focus();
                }
            });
        }

        // Global Real-time Online Users Count & Heartbeat
        const onlineCountValEls = document.querySelectorAll('.online-count-val');
        const heroTextEls = document.querySelectorAll('.heroOnlineCountText');
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

        function updateGlobalOnlineUsersCount() {
            fetch('<?php echo e(route("online-users.ping")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken || ''
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data && data.success) {
                    onlineCountValEls.forEach(el => {
                        el.textContent = `${data.count}`;
                    });
                    heroTextEls.forEach(el => {
                        el.textContent = `${data.count} đang xem`;
                    });
                }
            })
            .catch(() => {});
        }

        updateGlobalOnlineUsersCount();
        setInterval(updateGlobalOnlineUsersCount, 15000);

        // Cơ chế Click -> Mở rộng chi tiết trong 3s -> Tự động thu gọn lại (Icon Mắt + Số)
        const interactivePills = document.querySelectorAll('.live-online-interactive-pill');
        interactivePills.forEach(pill => {
            let expandTimer = null;
            pill.addEventListener('click', function(e) {
                e.stopPropagation();
                
                // Mở rộng hiển thị chữ "người đang xem"
                this.classList.add('is-expanded');
                
                if (expandTimer) clearTimeout(expandTimer);
                
                // 3 giây sau tự động thu gọn lại chỉ còn Icon Mắt + Số
                expandTimer = setTimeout(() => {
                    pill.classList.remove('is-expanded');
                }, 3000);
            });
        });
    });
</script>
<?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/partials/navbar.blade.php ENDPATH**/ ?>