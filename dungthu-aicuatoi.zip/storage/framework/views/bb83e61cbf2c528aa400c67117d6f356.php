<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-K1EFHMNDGK"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-K1EFHMNDGK');
    </script>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="google-site-verification" content="JXAkwIu8Sp6m3NoBdys1fP9YRH7eeUiiVQ49OEGUSqw" />
    <title><?php echo $__env->yieldContent('title', __('AI Của Tôi | Nền Tảng AI, Tài Khoản AI & Công Nghệ')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', __('AI Của Tôi (aicuatoi.com) - Nền tảng khám phá AI, cung cấp tài khoản AI, công cụ AI bản quyền và kiến thức công nghệ số hàng đầu Việt Nam.')); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', 'ai cua toi, aicuatoi, aicuatoi.com, tai khoan ai, ai hub, chatgpt, cursor pro, gemini advanced, blog ai, cong nghe ai'); ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', __('AI Của Tôi | Nền Tảng AI, Tài Khoản AI & Công Nghệ')); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', __('AI Của Tôi (aicuatoi.com) - Nền tảng khám phá AI, cung cấp tài khoản AI, công cụ AI bản quyền và kiến thức công nghệ số hàng đầu Việt Nam.')); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image', asset('images/dungthu-seo.png')); ?>">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">
    <meta property="twitter:title" content="<?php echo $__env->yieldContent('title', __('AI Của Tôi | Nền Tảng AI, Tài Khoản AI & Công Nghệ')); ?>">
    <meta property="twitter:description" content="<?php echo $__env->yieldContent('meta_description', __('AI Của Tôi (aicuatoi.com) - Nền tảng khám phá AI, cung cấp tài khoản AI, công cụ AI bản quyền và kiến thức công nghệ số hàng đầu Việt Nam.')); ?>">
    <meta property="twitter:image" content="<?php echo $__env->yieldContent('og_image', asset('images/dungthu-seo.png')); ?>">
    
    <!-- Favicon & PWA -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/aicuatoi-logo.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">
    <meta name="theme-color" content="#8b5cf6">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="AI Của Tôi">
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/aicuatoi-logo.png')); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
    
    <!-- Bootstrap & Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- TechFeed Theme -->
    <link rel="stylesheet" href="<?php echo e(asset('css/techfeed.css')); ?>?v=<?php echo e(filemtime(\App\Helpers\PathHelper::publicRootPath('css/techfeed.css'))); ?>">

    <!-- Page-specific CSS -->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <style>
        /* TechFeed global toast overrides */
        .small-toast { font-size: 13px !important; }
        .small-toast-title { font-size: 15px !important; margin-bottom: 5px !important; }
        .small-toast-text { font-size: 13px !important; }
        .swal2-toast .swal2-icon { width: 2em !important; height: 2em !important; margin: 0.5em 0.8em 0.5em 0 !important; }
        .swal2-toast { flex-direction: row !important; align-items: center !important; }

        /* Fix Mobile Zoom & Overflow */
        html, body {
            max-width: 100%;
            overflow-x: hidden;
            position: relative;
        }
        input, select, textarea {
            font-size: 16px !important; /* Prevents auto-zoom on iOS */
        }
    </style>
</head>
<body>
    <?php echo $__env->yieldContent('seo_h1'); ?>


    <!-- Navbar -->
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer -->
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('partials.chat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.recent-orders-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.spam-warning-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('partials.app-download-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Service Worker Registration -->
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then(reg => console.log('PWA Service Worker registered:', reg.scope))
                    .catch(err => console.log('Service Worker registration failed:', err));
            });
        }
    </script>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true,
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Global Laravel Flash Session Notifications (Toast/Alert) -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            });

            <?php if(session('info')): ?>
                Toast.fire({
                    icon: 'info',
                    title: <?php echo json_encode(session('info'), 15, 512) ?>
                });
            <?php endif; ?>

            <?php if(session('success')): ?>
                Toast.fire({
                    icon: 'success',
                    title: <?php echo json_encode(session('success'), 15, 512) ?>
                });
            <?php endif; ?>

            <?php if(session('error')): ?>
                Toast.fire({
                    icon: 'error',
                    title: <?php echo json_encode(session('error'), 15, 512) ?>
                });
            <?php endif; ?>

            <?php if(session('status')): ?>
                Toast.fire({
                    icon: 'success',
                    title: <?php echo json_encode(session('status'), 15, 512) ?>
                });
            <?php endif; ?>
        });
    </script>

    <!-- Admin action PIN: require 3-digit code for /admin POST/PUT/DELETE -->
    <script>
        (function () {
            function isAdminAction(form) {
                try {
                    const action = form.getAttribute('action') || window.location.href;
                    const url = new URL(action, window.location.origin);
                    return url.pathname.startsWith('/admin');
                } catch (e) {
                    return false;
                }
            }

            function getIntendedMethod(form) {
                const method = (form.getAttribute('method') || 'get').toLowerCase();
                const override = form.querySelector('input[name="_method"]');
                return (override ? override.value : method).toUpperCase();
            }

            document.addEventListener('submit', function (e) {
                const form = e.target;
                if (!(form instanceof HTMLFormElement)) return;
                if (!isAdminAction(form)) return;
                if (form.dataset.adminPinSkip === '1') return;

                const intended = getIntendedMethod(form);
                if (['GET', 'HEAD', 'OPTIONS'].includes(intended)) return;
                if (form.dataset.adminPinVerified === '1') return;

                e.preventDefault();

                const pin = window.prompt(<?php echo json_encode(__('Nhập mã xác nhận 8 số để thực hiện thao tác'), 15, 512) ?>);
                if (pin === null) return;
                if (!/^\d{8}$/.test(pin)) {
                    alert(<?php echo json_encode(__('Mã xác nhận phải đúng 8 số.'), 15, 512) ?>);
                    return;
                }

                let input = form.querySelector('input[name="admin_pin"]');
                if (!input) {
                    input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'admin_pin';
                    form.appendChild(input);
                }
                input.value = pin;

                form.dataset.adminPinVerified = '1';
                form.submit();
            }, true);
        })();
    </script>
    
    <!-- Flash Messages -->
    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: <?php echo json_encode(__('Thành công!'), 15, 512) ?>,
            text: '<?php echo e(session()->pull('success')); ?>',
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            showCloseButton: true,
            timer: 4000,
            timerProgressBar: true,
            width: '350px',
            padding: '12px',
            customClass: {
                popup: 'small-toast',
                title: 'small-toast-title',
                htmlContainer: 'small-toast-text',
                closeButton: 'small-close-btn'
            },
            didOpen: (toast) => {
                toast.style.cursor = 'default';
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
    </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: <?php echo json_encode(__('Lỗi!'), 15, 512) ?>,
            text: '<?php echo e(session('error')); ?>',
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            showCloseButton: true,
            timer: 4000,
            timerProgressBar: true,
            width: '350px',
            padding: '12px',
            customClass: {
                popup: 'small-toast',
                title: 'small-toast-title',
                htmlContainer: 'small-toast-text',
                closeButton: 'small-close-btn'
            },
            didOpen: (toast) => {
                toast.style.cursor = 'default';
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
    </script>
    <?php endif; ?>
    
    <style>
        .small-toast {
            font-size: 13px !important;
        }
        .small-toast-title {
            font-size: 15px !important;
            margin-bottom: 5px !important;
        }
        .small-toast-text {
            font-size: 13px !important;
        }
        .swal2-toast .swal2-icon {
            width: 2em !important;
            height: 2em !important;
            margin: 0.5em 0.8em 0.5em 0 !important;
            font-size: 1.5em !important;
        }
        .swal2-toast .swal2-icon .swal2-icon-content {
            font-size: 1.5em !important;
        }
        .swal2-toast .swal2-success-ring {
            width: 2em !important;
            height: 2em !important;
        }
        .small-close-btn {
            font-size: 18px !important;
            width: 24px !important;
            height: 24px !important;
        }
        .swal2-toast {
            flex-direction: row !important;
            align-items: center !important;
        }
        .swal2-toast .swal2-content {
            flex-grow: 1 !important;
        }

        /* Prevent double-tap to zoom on mobile devices */
        html, body {
            touch-action: manipulation;
        }
    </style>
    


<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>


<?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/layouts/app.blade.php ENDPATH**/ ?>