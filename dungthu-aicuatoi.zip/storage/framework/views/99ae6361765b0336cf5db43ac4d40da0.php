<?php $__env->startSection('title', 'Chi tiết Đơn hàng #' . $order->id . ' - Admin'); ?>

<?php $__env->startSection('page_title', 'Chi tiết đơn hàng'); ?>

<?php $__env->startPush('styles'); ?>
<style>

    .admin-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }

    .info-section {
        background: #f7fafc;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
    }

    .product-item {
        border-bottom: 1px solid #e2e8f0;
        padding: 15px 0;
    }

    .product-item:last-child {
        border-bottom: none;
    }

    .status-timeline {
        position: relative;
        padding-left: 40px;
    }

    .status-timeline-item {
        position: relative;
        padding-bottom: 30px;
    }

    .status-timeline-item:before {
        content: '';
        position: absolute;
        left: -29px;
        top: 8px;
        width: 2px;
        height: 100%;
        background: #e2e8f0;
    }

    .status-timeline-item:last-child:before {
        display: none;
    }

    .status-timeline-dot {
        position: absolute;
        left: -35px;
        top: 0;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        background: #667eea;
        border: 3px solid white;
        box-shadow: 0 0 0 2px #667eea;
    }

    .order-type-badge {
        padding: 8px 20px;
        border-radius: 25px;
        font-size: 0.9rem;
        font-weight: 600;
        display: inline-block;
    }

    .type-qr {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
    }

    .type-document {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        color: white;
    }

    .type-shipping {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        color: white;
    }

    .type-digital {
        background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        color: white;
    }

    .action-guide {
        background: #fff7ed;
        border-left: 4px solid #f59e0b;
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">
        <div class="admin-card" data-aos="fade-up">
            <div class="mb-4">
                <a href="<?php echo e(route('admin.orders')); ?>" class="btn btn-outline-secondary rounded-pill mb-3">
                    <i class="fas fa-arrow-left me-2"></i>Quay lại
                </a>
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="fw-bold mb-2">
                            <i class="fas fa-file-invoice text-primary me-3"></i>Đơn hàng #<?php echo e($order->id); ?>

                        </h3>
                        <span class="order-type-badge type-<?php echo e($order->order_type); ?>">
                            <?php if($order->order_type == 'qr'): ?>
                                <i class="fas fa-qrcode me-1"></i>Đơn QR (TikTok Deal)
                            <?php elseif($order->order_type == 'document'): ?>
                                <i class="fas fa-file-pdf me-1"></i>Đơn Tài liệu
                            <?php elseif($order->order_type == 'shipping'): ?>
                                <i class="fas fa-shipping-fast me-1"></i>Đơn Ship
                            <?php else: ?>
                                <i class="fas fa-download me-1"></i>Đơn Digital
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-<?php echo e($order->status_color); ?> fs-5 px-4 py-2">
                            <?php echo e($order->status_label); ?>

                        </span>
                        <?php if($order->status_note): ?>
                            <div class="mt-2 text-muted fs-7 bg-light rounded px-3 py-1 border text-start" style="max-width: 300px;">
                                <i class="fas fa-sticky-note text-warning me-1"></i><strong>Chú thích:</strong> <?php echo e($order->status_note); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Success Message -->
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Order Status Alert -->
            <?php if($order->status == 'completed'): ?>
                <div class="alert alert-success mb-4" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); border: none; color: white;">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-check-circle fs-4 me-3"></i>
                        <div>
                            <h5 class="mb-1 text-white">✅ Đơn hàng đã được xác nhận</h5>
                            <p class="mb-0" style="font-size: 0.95rem;">Admin đã xác nhận đơn hàng và gửi tài khoản demo cho khách hàng</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Order Type Specific Guide -->
            <div class="action-guide">
                <h6 class="fw-bold mb-2">
                    <i class="fas fa-lightbulb me-2"></i>Hướng dẫn xử lý đơn <?php echo e($order->order_type); ?>:
                </h6>
                <?php if($order->order_type == 'qr'): ?>
                    <ul class="mb-0">
                        <li>Xác nhận thanh toán từ khách hàng</li>
                        <li>Gửi mã QR code/voucher TikTok qua email hoặc SMS</li>
                        <li>Đánh dấu "Hoàn thành" sau khi gửi thành công</li>
                    </ul>
                <?php elseif($order->order_type == 'document'): ?>
                    <ul class="mb-0">
                        <li>Kiểm tra thanh toán đã được xác nhận</li>
                        <li>Khách hàng có thể tải file ngay từ trang sản phẩm</li>
                        <li>Không cần giao hàng vật lý - đánh dấu "Hoàn thành" ngay</li>
                    </ul>
                <?php elseif($order->order_type == 'shipping'): ?>
                    <ul class="mb-0">
                        <li>Đóng gói sản phẩm và chuẩn bị giao hàng</li>
                        <li>Cập nhật trạng thái "Đã giao hàng" khi bàn giao cho đơn vị vận chuyển</li>
                        <li>Liên hệ khách hàng xác nhận khi nhận hàng</li>
                        <li>Đánh dấu "Đã nhận hàng" hoặc "Hoàn thành"</li>
                    </ul>
                <?php else: ?>
                    <ul class="mb-0">
                        <li>Xác nhận thanh toán</li>
                        <li>Gửi link download hoặc kích hoạt tài khoản</li>
                        <li>Đánh dấu "Hoàn thành" sau khi giao hàng</li>
                    </ul>
                <?php endif; ?>
            </div>

            <div class="row">
                <!-- Customer Information -->
                <div class="col-md-6">
                    <div class="info-section h-100 mb-0">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-user text-primary me-2"></i>Thông tin khách hàng
                        </h5>
                        <div class="mb-2">
                            <strong>Họ tên:</strong> <?php echo e($order->customer_name); ?>

                        </div>
                        <div class="mb-2">
                            <strong>Email:</strong> <?php echo e($order->customer_email); ?>

                        </div>
                        <div class="mb-2">
                            <strong>Số điện thoại:</strong> <?php echo e($order->customer_phone); ?>

                        </div>
                        
                        <div class="mb-2 mt-3">
                            <strong>
                                <?php if($order->order_type == 'shipping'): ?>
                                    <i class="fas fa-map-marker-alt text-success me-1"></i>Địa chỉ giao hàng:
                                <?php else: ?>
                                    <i class="fas fa-credit-card text-success me-1"></i>Thông tin thanh toán & Liên hệ:
                                <?php endif; ?>
                            </strong>
                            <div class="p-3 bg-white rounded border mt-2 text-dark" style="white-space: pre-line; font-size: 0.92rem; border-left: 4px solid #667eea !important; line-height: 1.6; box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);">
                                <?php echo e($order->customer_address); ?>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Order Information -->
                <div class="col-md-6">
                    <div class="info-section">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-info-circle text-primary me-2"></i>Thông tin đơn hàng
                        </h5>
                        <div class="mb-2">
                            <strong>Mã đơn:</strong> #<?php echo e($order->id); ?>

                        </div>
                        <div class="mb-2">
                            <strong>Ngày đặt:</strong> <?php echo e($order->created_at->format('d/m/Y H:i')); ?>

                        </div>
                        <div class="mb-2">
                            <strong>Tổng tiền:</strong> 
                            <span class="text-primary fw-bold fs-5"><?php echo e($order->formatted_total); ?></span>
                        </div>
                        <div class="mb-2">
                            <strong>Số lượng sản phẩm:</strong> <?php echo e($order->orderItems->sum('quantity')); ?>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Products List -->
            <div class="info-section mt-4">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-box text-primary me-2"></i>Sản phẩm trong đơn
                </h5>
                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-item">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <?php if($item->product->image): ?>
                                    <img src="<?php echo e($item->product->image); ?>" alt="<?php echo e($item->product->name); ?>" class="img-fluid rounded" style="max-height: 80px;">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-5">
                                <div class="fw-bold d-flex align-items-center gap-2">
                                    <?php echo e($item->product->name); ?>

                                    <?php if(!($item->product->is_active ?? true)): ?>
                                        <span class="badge bg-secondary style="font-size: 10px;">Đã ẩn</span>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted">
                                    <?php if($item->product->category == 'ebooks'): ?>
                                        <i class="fas fa-file-pdf text-danger me-1"></i>Tài liệu số
                                    <?php elseif($item->product->category == 'tiktok'): ?>
                                        <i class="fas fa-qrcode text-primary me-1"></i>TikTok Deal
                                    <?php elseif($item->product->delivery_type == 'physical'): ?>
                                        <i class="fas fa-box text-success me-1"></i>Giao hàng vật lý
                                    <?php else: ?>
                                        <i class="fas fa-download text-info me-1"></i>Digital
                                    <?php endif; ?>
                                </small>
                            </div>
                            <div class="col-md-3 text-center">
                                <?php if($item->product): ?>
                                    <form action="<?php echo e(route('admin.products.toggle-active', $item->product)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm <?php echo e($item->product->is_active ? 'btn-outline-success' : 'btn-outline-secondary'); ?> rounded-pill px-3 py-1" style="font-size: 11.5px; font-weight: 500;">
                                            <i class="fas <?php echo e($item->product->is_active ? 'fa-eye text-success' : 'fa-eye-slash text-secondary'); ?> me-1"></i>
                                            <span><?php echo e($item->product->is_active ? 'Hiển thị' : 'Đã ẩn'); ?></span>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-1 text-center">
                                <span class="badge bg-secondary">x<?php echo e($item->quantity); ?></span>
                            </div>
                            <div class="col-md-1 text-end">
                                <div class="fw-bold"><?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <!-- Digital Product Manual Delivery Form -->
            <?php
                $defaultNote = "Chào " . ($order->customer_name ?? 'bạn') . ",\n\nCảm ơn bạn đã ủng hộ AICuaToi.com. Dưới đây là thông tin bàn giao cho đơn hàng của bạn:\n";
                foreach($order->orderItems as $item) {
                    $defaultNote .= "• " . ($item->product->name ?? 'Sản phẩm') . " (SL: " . $item->quantity . ")\n";
                }
                $defaultNote .= "\nNếu có bất kỳ câu hỏi nào, vui lòng liên hệ Zalo hoặc Email hỗ trợ bên dưới nhé!";
            ?>
            <div class="info-section mt-4" style="border: 2.5px dashed #667eea; background: #fafbff; border-radius: 15px; padding: 25px; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.05);">
                <h5 class="fw-bold mb-3 text-primary">
                    <i class="fas fa-paper-plane me-2"></i>🔑 CẤP TÀI KHOẢN &amp; GỬI HÀNG QUA EMAIL
                </h5>
                <p class="text-muted" style="font-size: 0.9rem;">Dành cho đơn hàng digital, tài liệu hoặc tài khoản game. Nhập thông tin bàn giao dưới đây để hệ thống tự động gửi email cho khách và đánh dấu đơn hàng là <strong>Hoàn thành</strong>.</p>
                
                <?php if($order->status == 'completed' && ($order->delivery_account || $order->delivery_key || $order->delivery_note)): ?>
                    <div class="alert alert-info py-2 px-3 mb-3" style="font-size: 0.9rem; border-left: 4px solid #17a2b8;">
                        <i class="fas fa-info-circle me-1"></i> Đơn hàng này đã được bàn giao thông tin trước đó. Bạn có thể cập nhật thông tin mới và gửi lại email bên dưới.
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.orders.deliver', $order)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!-- Tài khoản -->
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Tài khoản / Account:</label>
                            <input type="text" name="delivery_account" class="form-control" 
                                   value="<?php echo e($order->delivery_account); ?>" 
                                   placeholder="Ví dụ: taikhoan@gmail.com | matkhau123">
                            <small class="text-muted">Thông tin đăng nhập tài khoản (nếu có)</small>
                        </div>
                        
                        <!-- KEY / Mã kích hoạt -->
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">KEY / Mã kích hoạt:</label>
                            <input type="text" name="delivery_key" class="form-control" 
                                   value="<?php echo e($order->delivery_key); ?>" 
                                   placeholder="Ví dụ: GPT-XXXX-XXXX-XXXX">
                            <small class="text-muted">Mã kích hoạt, license key hoặc link tải nhanh (nếu có)</small>
                        </div>

                        <!-- Thông báo / Hướng dẫn -->
                        <div class="col-12 mb-3">
                            <label class="form-label fw-bold">Thông báo &amp; Hướng dẫn sử dụng:</label>
                            <textarea name="delivery_note" class="form-control" rows="5" placeholder="Ghi chú thêm cho khách hàng..."><?php echo e($order->delivery_note ?? $defaultNote); ?></textarea>
                            <small class="text-muted">Nội dung này hiển thị trực tiếp trong email bàn giao gửi tới khách hàng.</small>
                        </div>
                    </div>

                    <div class="text-end mt-2">
                        <button type="submit" class="btn btn-primary rounded-pill px-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);">
                            <i class="fas fa-paper-plane me-2"></i>Gửi hàng &amp; Hoàn thành Đơn hàng
                        </button>
                    </div>
                </form>
            </div>

            <!-- Update Status Form -->
            <div class="info-section mt-4">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-tasks text-primary me-2"></i>Cập nhật trạng thái
                </h5>
                <form action="<?php echo e(route('admin.orders.update-status', $order)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row align-items-end mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-bold">Trạng thái mới:</label>
                            <select name="status" class="form-select" required>
                                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Chờ xử lý</option>
                                <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>Đang xử lý</option>
                                <?php if($order->order_type == 'shipping'): ?>
                                    <option value="shipped" <?php echo e($order->status == 'shipped' ? 'selected' : ''); ?>>Đã giao hàng</option>
                                    <option value="delivered" <?php echo e($order->status == 'delivered' ? 'selected' : ''); ?>>Đã nhận hàng</option>
                                <?php endif; ?>
                                <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Hoàn thành</option>
                                <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Đã hủy</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-save me-2"></i>Cập nhật
                            </button>
                        </div>
                    </div>
                    <div>
                        <label class="form-label fw-bold"><i class="fas fa-sticky-note me-1 text-warning"></i>Ghi chú / Chú thích trạng thái (Hiển thị ngay bên dưới trạng thái):</label>
                        <textarea name="status_note" class="form-control" rows="2" placeholder="Nhập ghi chú hoặc chú thích cho trạng thái này..."><?php echo e($order->status_note); ?></textarea>
                    </div>
                </form>
            </div>

            <!-- Delete Order -->
            <div class="mt-4 text-end">
                <form action="<?php echo e(route('admin.orders.delete', $order)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bạn có chắc chắn muốn xóa đơn hàng này?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash me-2"></i>Xóa đơn hàng
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    AOS.init({ duration: 800, once: true });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\trant\OneDrive\Tài liệu\GitHub\dungthu-aicuatoi\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>