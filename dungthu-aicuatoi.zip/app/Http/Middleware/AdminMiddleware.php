<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check() || !in_array(auth()->user()->role, ['superadmin_1', 'sieusuperadmin', 'blog_editor'], true)) {
            return redirect()->route('home')->with('error', 'Bạn không có quyền truy cập!');
        }

        $user = auth()->user();
        $method = strtoupper($request->getMethod());
        $routeName = $request->route() ? $request->route()->getName() : null;

        // Cộng tác viên Blog chỉ được truy cập trang quản lý bài viết.
        if ($user->role === 'blog_editor') {
            if (!$routeName || !\Illuminate\Support\Str::is('admin.blogs*', $routeName)) {
                return redirect()->route('admin.blogs')
                    ->with('error', 'Tài khoản này chỉ được cấp quyền quản lý Blog.');
            }

            return $next($request);
        }



        // 1. Phân quyền truy cập cho SieuSuperAdmin
        if ($user->role === 'sieusuperadmin' && $routeName) {
            $allowedRoutePatterns = [
                'admin.dashboard',
                'admin.verify-pin',
                'admin.verify-pin.post',
                'admin.lock',
                'admin.sidebar-counters',
                'admin.orders*',
                'admin.chat*',
                'admin.products*',
                'admin.categories*',
                'admin.features*',
                'admin.customer-durations*',
                'admin.blogs*',
                'admin.blog-topics*',
                'admin.users*',
                'admin.online-users*',
                'admin.banned-ips*',
                'admin.suspicious-ips*',
                'admin.coupons*',
                'admin.menu-settings*',
                'admin.google-indexing.submit-all',
                'admin.telegram*',
            ];

            $isAllowed = false;
            foreach ($allowedRoutePatterns as $pattern) {
                if (\Illuminate\Support\Str::is($pattern, $routeName)) {
                    $isAllowed = true;
                    break;
                }
            }

            if (!$isAllowed) {
                \Illuminate\Support\Facades\Log::warning("Unauthorized admin access attempt by SieuSuperAdmin (User ID: {$user->id}) to route: {$routeName} from IP: {$request->ip()}");
                abort(403, "Tài khoản của bạn không được cấp quyền truy cập tính năng này.");
            }

            // Ghi nhật ký các hành động thay đổi dữ liệu nhạy cảm
            if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'])) {
                \Illuminate\Support\Facades\Log::info("SieuSuperAdmin Action: User ID {$user->id} performed {$method} on URL {$request->fullUrl()} from IP: {$request->ip()}", [
                    'input' => $request->except(['gate_password', 'password', 'password_confirmation', '_token']),
                ]);
            }
        }

        // 2. Phân quyền chặn Superadmin thường (superadmin_1) truy cập các trang độc quyền của SieuSuperAdmin
        if ($user->role === 'superadmin_1' && $routeName) {
            $restrictedRoutePatterns = [
                'admin.online-users*',
                'admin.coupons*',
                'admin.menu-settings*',
                'admin.buff*',
                'admin.card-exchanges*',
                'admin.abandoned-carts*',
                'admin.preorders*',
                'admin.affiliates*',
                'admin.seo-keywords*',
                'admin.system-notifications*',
                'admin.google-indexing*',
            ];

            foreach ($restrictedRoutePatterns as $pattern) {
                if (\Illuminate\Support\Str::is($pattern, $routeName)) {
                    \Illuminate\Support\Facades\Log::warning("Unauthorized admin access attempt by superadmin_1 (User ID: {$user->id}) to sieusuperadmin route: {$routeName} from IP: {$request->ip()}");
                    abort(403, "Quyền hạn của bạn không đủ để truy cập khu vực này.");
                }
            }
        }

        return $next($request);
    }
}
