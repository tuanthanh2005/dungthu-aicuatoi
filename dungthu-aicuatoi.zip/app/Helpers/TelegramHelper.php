<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TelegramHelper
{
    /**
     * Gửi tin nhắn tùy chỉnh qua Telegram
     */
    public static function sendMessage($text)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        try {
            $response = Http::timeout(3)->post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $text,
                'parse_mode' => 'HTML',
            ]);

            if ($response->successful()) {
                Log::info('Telegram message sent successfully');
                return true;
            } else {
                Log::error('Telegram send failed: ' . $response->body());
                return false;
            }
        } catch (\Exception $e) {
            Log::error('Telegram error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Gửi thông báo đơn hàng mới qua Telegram kèm Nút bấm xử lý trực tiếp
     */
    public static function sendNewOrderNotification($order)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        // Tạo nội dung thông báo
        $message = self::formatOrderMessage($order);

        $replyMarkup = [
            'inline_keyboard' => [
                [
                    ['text' => '✅ Hoàn thành', 'callback_data' => "order:completed:{$order->id}"],
                    ['text' => '🚚 Đang xử lý', 'callback_data' => "order:processing:{$order->id}"],
                ],
                [
                    ['text' => '❌ Hủy đơn', 'callback_data' => "order:cancelled:{$order->id}"],
                    ['text' => '🌐 Xem trên Web', 'url' => url("/admin/orders/{$order->id}")],
                ]
            ]
        ];

        try {
            $response = Http::timeout(3)->post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $message,
                'parse_mode' => 'HTML',
                'reply_markup' => json_encode($replyMarkup),
            ]);

            if ($response->successful()) {
                $data = $response->json();
                $msgId = $data['result']['message_id'] ?? null;
                if ($msgId) {
                    \App\Models\TelegramMessageMapping::create([
                        'telegram_message_id' => (string) $msgId,
                        'telegram_chat_id' => (string) $chatId,
                        'type' => 'order',
                        'related_id' => $order->id,
                    ]);
                }
                Log::info('Telegram notification sent successfully for order #' . $order->id);
                return true;
            } else {
                Log::error('Telegram notification failed: ' . $response->body());
                return false;
            }
        } catch (\Exception $e) {
            Log::error('Telegram notification error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Format thông tin đơn hàng thành message Telegram
     */
    private static function formatOrderMessage($order)
    {
        // Load order items với product
        $order->load('orderItems.product');

        $isUsd = ($order->currency === 'USD');

        if ($isUsd) {
            $message = "🔔 <b>NEW ORDER - CONFIRMED PAYMENT</b>\n";
            $message .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";

            // Thông tin đơn hàng
            $message .= "📦 <b>ORDER DETAILS</b>\n";
            $message .= "• Order ID: <b>#" . $order->id . "</b>\n";
            $message .= "• Order Type: <b>" . self::getOrderTypeLabel($order->order_type) . "</b>\n";
            $message .= "• Time: <b>" . $order->created_at->timezone('Asia/Ho_Chi_Minh')->format('d/m/Y H:i:s') . "</b>\n";
            $message .= "• Status: <b>" . $order->status_label . "</b>\n\n";

            // Thông tin khách hàng
            $message .= "👤 <b>CUSTOMER INFORMATION</b>\n";
            $message .= "• Full Name: <b>" . $order->customer_name . "</b>\n";
            $message .= "• Email: <b>" . $order->customer_email . "</b>\n";
            $message .= "• Phone: <b>" . $order->customer_phone . "</b>\n";
            
            if ($order->customer_address && $order->customer_address !== 'Digital product - no shipping required') {
                $message .= "• Address: <b>" . $order->customer_address . "</b>\n";
            }
            $message .= "\n";

            // Chi tiết sản phẩm
            $message .= "🛒 <b>PRODUCT DETAILS</b>\n";
            foreach ($order->orderItems as $item) {
                $productName = $item->product ? ($item->product->name_en ?? $item->product->name) : 'Product does not exist';
                $message .= "• " . $productName . "\n";
                $message .= "  ├ Quantity: <b>" . $item->quantity . "</b>\n";
                $message .= "  ├ Unit Price: <b>$" . number_format($item->price, 2) . "</b>\n";
                $message .= "  └ Subtotal: <b>$" . number_format($item->price * $item->quantity, 2) . "</b>\n\n";
            }

            // Tổng tiền
            $message .= "━━━━━━━━━━━━━━━━━━━━━━\n";
            if (isset($order->discount_amount) && $order->discount_amount > 0) {
                $message .= "• Discount: <b>-$" . number_format($order->discount_amount, 2) . "</b> (" . $order->coupon_code . ")\n";
            }
            $message .= "💰 <b>TOTAL AMOUNT: $" . number_format($order->total_amount, 2) . "</b>\n";
            $message .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";

            if ($order->status === 'completed') {
                $message .= "✅ <i>Instant digital order processed and completed automatically!</i>";
            } else {
                $message .= "⚠️ <i>Order requires manual processing. Please check and process!</i>";
            }
        } else {
            $message = "🔔 <b>ĐƠN HÀNG MỚI - XÁC NHẬN ĐÃ THANH TOÁN</b>\n";
            $message .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";

            // Thông tin đơn hàng
            $message .= "📦 <b>THÔNG TIN ĐƠN HÀNG</b>\n";
            $message .= "• Mã đơn: <b>#" . $order->id . "</b>\n";
            $message .= "• Loại đơn: <b>" . self::getOrderTypeLabel($order->order_type) . "</b>\n";
            $message .= "• Thời gian: <b>" . $order->created_at->timezone('Asia/Ho_Chi_Minh')->format('d/m/Y H:i:s') . "</b>\n";
            $message .= "• Trạng thái: <b>" . $order->status_label . "</b>\n\n";

            // Thông tin khách hàng
            $message .= "👤 <b>THÔNG TIN KHÁCH HÀNG</b>\n";
            $message .= "• Họ tên: <b>" . $order->customer_name . "</b>\n";
            $message .= "• Email: <b>" . $order->customer_email . "</b>\n";
            $message .= "• SĐT: <b>" . $order->customer_phone . "</b>\n";
            
            if ($order->customer_address && $order->customer_address !== 'Sản phẩm số - không cần giao hàng') {
                $message .= "• Địa chỉ: <b>" . $order->customer_address . "</b>\n";
            }
            $message .= "\n";

            // Chi tiết sản phẩm
            $message .= "🛒 <b>CHI TIẾT SẢN PHẨM</b>\n";
            foreach ($order->orderItems as $item) {
                $productName = $item->product ? $item->product->name : 'Sản phẩm không tồn tại';
                $message .= "• " . $productName . "\n";
                $message .= "  ├ Số lượng: <b>" . $item->quantity . "</b>\n";
                $message .= "  ├ Đơn giá: <b>" . number_format($item->price, 0, ',', '.') . "đ</b>\n";
                $message .= "  └ Thành tiền: <b>" . number_format($item->price * $item->quantity, 0, ',', '.') . "đ</b>\n\n";
            }

            // Tổng tiền
            $message .= "━━━━━━━━━━━━━━━━━━━━━━\n";
            if (isset($order->discount_amount) && $order->discount_amount > 0) {
                $message .= "• Giảm giá: <b>-" . number_format($order->discount_amount, 0, ',', '.') . "đ</b> (" . $order->coupon_code . ")\n";
            }
            $message .= "💰 <b>TỔNG TIỀN: " . number_format($order->total_amount, 0, ',', '.') . "đ</b>\n";
            $message .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";

            if ($order->status === 'completed') {
                $message .= "✅ <i>Đơn hàng có sẵn kho đã được xử lý và hoàn thành tự động!</i>";
            } else {
                $message .= "⚠️ <i>Đơn hàng chưa có sẵn kho. Vui lòng kiểm tra và xử lý đơn hàng!</i>";
            }
        }

        return $message;
    }

    /**
     * Gửi thông báo thanh toán Buff qua Telegram
     */
    public static function sendBuffPaymentNotification($buffOrder)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        try {
            $service = $buffOrder->buffService;
            $server = $buffOrder->buffServer;
            $user = $buffOrder->user;

            $message = "🎯 <b>BUFF PAYMENT COMPLETED</b>\n";
            $message .= "━━━━━━━━━━━━━━━━━━━━━━━━\n\n";

            $message .= "📦 <b>Order Info:</b>\n";
            $message .= "• Code: <b>" . $buffOrder->order_code . "</b>\n";
            $message .= "• Platform: <b>" . ucfirst($service->platform) . "</b>\n";
            $message .= "• Service: <b>" . $service->name . "</b>\n";
            $message .= "• Server: <b>" . $server->name . "</b>\n\n";

            $message .= "👤 <b>User:</b>\n";
            $message .= "• Name: <b>" . $user->name . "</b>\n";
            $message .= "• Email: <b>" . $user->email . "</b>\n\n";

            $message .= "📊 <b>Details:</b>\n";
            $message .= "• Quantity: <b>" . number_format($buffOrder->quantity) . "</b>\n";
            $message .= "• Unit Price: <b>" . number_format($buffOrder->unit_price, 0, ',', '.') . "đ</b>\n";
            $message .= "• Base Price: <b>" . number_format($buffOrder->base_price, 0, ',', '.') . "đ</b>\n";
            $message .= "• Total: <b>" . number_format($buffOrder->total_price, 0, ',', '.') . "đ</b>\n\n";

            $message .= "🔗 Link: <b>" . substr($buffOrder->social_link, 0, 50) . "...</b>\n";
            $message .= "⏰ Time: <b>" . $buffOrder->updated_at->timezone('Asia/Ho_Chi_Minh')->format('d/m/Y H:i:s') . "</b>\n\n";

            $message .= "✅ <i>Payment confirmed! Processing order...</i>";

            $response = Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $message,
                'parse_mode' => 'HTML',
            ]);

            if ($response->successful()) {
                Log::info('Telegram buff payment notification sent for order: ' . $buffOrder->order_code);
                return true;
            } else {
                Log::error('Telegram buff notification failed: ' . $response->body());
                return false;
            }
        } catch (\Exception $e) {
            Log::error('Telegram buff notification error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Gửi thông báo có khách hàng mới đăng ký tài khoản
     */
    public static function sendNewUserNotification($user)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        $text = "👤 <b>KHÁCH HÀNG MỚI ĐĂNG KÝ</b>\n";
        $text .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $text .= "• Họ tên: <b>" . $user->name . "</b>\n";
        $text .= "• Email: <b>" . $user->email . "</b>\n";
        $text .= "• Thời gian: <b>" . now()->timezone('Asia/Ho_Chi_Minh')->format('H:i:s d/m/Y') . "</b>\n\n";
        $text .= "━━━━━━━━━━━━━━━━━━━━━━\n";
        $text .= "🚀 <i>Chào mừng thành viên mới gia nhập hệ thống!</i>";

        try {
            Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $text,
                'parse_mode' => 'HTML',
            ]);
            Log::info('Telegram notification sent for new user: ' . $user->email);
        } catch (\Exception $e) {
            Log::error('Telegram User Notification Error: ' . $e->getMessage());
        }
    }

    /**
     * Gửi thông báo có tin nhắn chat mới từ khách hàng kèm hỗ trợ trả lời 2 chiều
     */
    public static function sendNewChatMessageNotification($message)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        $user = $message->user;
        $userName = $user ? $user->name : 'Khách vãng lai';
        $userEmail = $user ? $user->email : 'N/A';
        $userId = $message->user_id ?: 0;

        $text = "💬 <b>TIN NHẮN CHAT MỚI</b>\n";
        $text .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $text .= "👤 <b>Người gửi:</b> " . htmlspecialchars($userName) . "\n";
        $text .= "📧 <b>Email:</b> " . htmlspecialchars($userEmail) . "\n\n";
        
        if ($message->message) {
            $text .= "📝 <b>Nội dung:</b>\n<i>" . htmlspecialchars($message->message) . "</i>\n\n";
        }
        
        if ($message->image) {
            $text .= "🖼 <b>Có đính kèm hình ảnh:</b> " . url($message->image) . "\n\n";
        }

        $text .= "💡 <i>Bấm <b>Reply (Trả lời)</b> tin nhắn này trên Telegram để phản hồi lại khách hàng!</i>\n\n";
        $text .= "⏰ <i>" . now()->format('H:i:s d/m/Y') . "</i>";

        $replyMarkup = [
            'inline_keyboard' => [
                [
                    ['text' => '🌐 Khung Chat Web', 'url' => url('/admin/chat')],
                ]
            ]
        ];

        try {
            $response = Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $text,
                'parse_mode' => 'HTML',
                'reply_markup' => json_encode($replyMarkup),
            ]);

            if ($response->successful()) {
                $data = $response->json();
                $msgId = $data['result']['message_id'] ?? null;
                if ($msgId) {
                    \App\Models\TelegramMessageMapping::create([
                        'telegram_message_id' => (string) $msgId,
                        'telegram_chat_id' => (string) $chatId,
                        'type' => 'chat',
                        'related_id' => $userId,
                    ]);
                }
            }
        } catch (\Exception $e) {
            Log::error('Telegram Chat Notification Error: ' . $e->getMessage());
        }
    }

    /**
     * Phản hồi callback query (tạo thông báo toast trên Telegram khi bấm nút)
     */
    public static function answerCallbackQuery($callbackQueryId, $text)
    {
        $botToken = config('services.telegram.bot_token');

        try {
            Http::post("https://api.telegram.org/bot{$botToken}/answerCallbackQuery", [
                'callback_query_id' => $callbackQueryId,
                'text' => $text,
                'show_alert' => true,
            ]);
        } catch (\Exception $e) {
            Log::error('Telegram answerCallbackQuery Error: ' . $e->getMessage());
        }
    }

    /**
     * Chỉnh sửa nội dung tin nhắn Telegram sau khi xử lý thành công
     */
    public static function editMessageText($chatId, $messageId, $text, $replyMarkup = null)
    {
        $botToken = config('services.telegram.bot_token');

        $params = [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => 'HTML',
        ];

        if ($replyMarkup) {
            $params['reply_markup'] = json_encode($replyMarkup);
        }

        try {
            Http::post("https://api.telegram.org/bot{$botToken}/editMessageText", $params);
        } catch (\Exception $e) {
            Log::error('Telegram editMessageText Error: ' . $e->getMessage());
        }
    }

    /**
     * Gửi thông báo IP đáng nghi ngờ / bị khóa qua Telegram
     */
    public static function sendSuspiciousIpNotification($ip, $reason, $userAgent = null, $url = null)
    {
        $botToken = config('services.telegram.bot_token');
        $chatId = config('services.telegram.chat_id');

        if (empty($botToken) || empty($chatId)) {
            return false;
        }

        $text = "🚨 <b>CẢNH BÁO IP ĐÁNG NGHI NGỜ / BỊ CHẶN</b>\n";
        $text .= "━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $text .= "🌐 <b>Địa chỉ IP:</b> <code>" . $ip . "</code>\n";
        $text .= "⚠️ <b>Lý do:</b> " . $reason . "\n";

        if ($url) {
            $text .= "🔗 <b>URL truy cập:</b> <code>" . htmlspecialchars($url) . "</code>\n";
        }

        if ($userAgent) {
            $text .= "💻 <b>User-Agent:</b> <code>" . htmlspecialchars(substr($userAgent, 0, 150)) . "</code>\n";
        }

        $text .= "⏰ <b>Thời gian:</b> " . now()->timezone('Asia/Ho_Chi_Minh')->format('H:i:s d/m/Y') . "\n\n";
        $text .= "━━━━━━━━━━━━━━━━━━━━━━\n";
        $text .= "🔒 <i>Hệ thống tự động ngắt kết nối IP này để bảo vệ website!</i>";

        try {
            Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $text,
                'parse_mode' => 'HTML',
            ]);
            Log::info("Telegram alert sent for suspicious IP: {$ip}");
            return true;
        } catch (\Exception $e) {
            Log::error('Telegram Suspicious IP Alert Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Lấy nhãn cho loại đơn hàng
     */
    private static function getOrderTypeLabel($type)
    {
        $labels = [
            'qr' => 'TikTok QR',
            'document' => 'Tài liệu / Ebook',
            'shipping' => 'Giao hàng vật lý',
            'digital' => 'Sản phẩm số',
        ];

        return $labels[$type] ?? 'Mặc định';
    }
}
